import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  height: integer("height"),
  weight: integer("weight"),
  fitnessLevel: text("fitness_level").notNull(),
  fitnessGoals: text("fitness_goals").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Workout table
export const workouts = pgTable("workouts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  difficulty: text("difficulty").notNull(),
  duration: integer("duration").notNull(),
  calories: integer("calories").notNull(),
  targetBodyParts: text("target_body_parts").array().notNull(),
  exercises: json("exercises").notNull(),
  ageGroup: text("age_group").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Exercise table
export const exercises = pgTable("exercises", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  bodyPart: text("body_part").notNull(),
  difficulty: text("difficulty").notNull(),
  sets: integer("sets"),
  reps: integer("reps"),
  restTime: integer("rest_time"),
  instructionsSteps: text("instructions_steps").array(),
  ageGroup: text("age_group").notNull(),
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
});

// Nutrition plan table
export const nutritionPlans = pgTable("nutrition_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  goal: text("goal").notNull(),
  calories: integer("calories").notNull(),
  protein: integer("protein").notNull(),
  carbs: integer("carbs").notNull(),
  fat: integer("fat").notNull(),
  meals: json("meals").notNull(),
  ageGroup: text("age_group").notNull(),
});

// Yoga routine table
export const yogaRoutines = pgTable("yoga_routines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  difficulty: text("difficulty").notNull(),
  duration: integer("duration").notNull(),
  poses: json("poses").notNull(),
  benefits: text("benefits").array().notNull(),
});

// Sleep tracker table
export const sleepData = pgTable("sleep_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").notNull(),
  duration: integer("duration").notNull(),
  quality: integer("quality").notNull(),
  notes: text("notes"),
});

// Step counter table
export const stepData = pgTable("step_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").notNull(),
  steps: integer("steps").notNull(),
});

// Health tips table
export const healthTips = pgTable("health_tips", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(),
  ageGroup: text("age_group").notNull(),
});

// Coaches table
export const coaches = pgTable("coaches", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  specialization: text("specialization").notNull(),
  experience: integer("experience").notNull(),
  bio: text("bio").notNull(),
  availability: json("availability").notNull(),
  imageUrl: text("image_url"),
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertWorkoutSchema = createInsertSchema(workouts).omit({ id: true, createdAt: true });
export const insertExerciseSchema = createInsertSchema(exercises).omit({ id: true });
export const insertNutritionPlanSchema = createInsertSchema(nutritionPlans).omit({ id: true });
export const insertYogaRoutineSchema = createInsertSchema(yogaRoutines).omit({ id: true });
export const insertSleepDataSchema = createInsertSchema(sleepData).omit({ id: true });
export const insertStepDataSchema = createInsertSchema(stepData).omit({ id: true });
export const insertHealthTipSchema = createInsertSchema(healthTips).omit({ id: true });
export const insertCoachSchema = createInsertSchema(coaches).omit({ id: true });

// Create select types
export type User = typeof users.$inferSelect;
export type Workout = typeof workouts.$inferSelect;
export type Exercise = typeof exercises.$inferSelect;
export type NutritionPlan = typeof nutritionPlans.$inferSelect;
export type YogaRoutine = typeof yogaRoutines.$inferSelect;
export type SleepData = typeof sleepData.$inferSelect;
export type StepData = typeof stepData.$inferSelect;
export type HealthTip = typeof healthTips.$inferSelect;
export type Coach = typeof coaches.$inferSelect;

// Create insert types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertWorkout = z.infer<typeof insertWorkoutSchema>;
export type InsertExercise = z.infer<typeof insertExerciseSchema>;
export type InsertNutritionPlan = z.infer<typeof insertNutritionPlanSchema>;
export type InsertYogaRoutine = z.infer<typeof insertYogaRoutineSchema>;
export type InsertSleepData = z.infer<typeof insertSleepDataSchema>;
export type InsertStepData = z.infer<typeof insertStepDataSchema>;
export type InsertHealthTip = z.infer<typeof insertHealthTipSchema>;
export type InsertCoach = z.infer<typeof insertCoachSchema>;

// Custom schemas
export const fitnessPlanSchema = z.object({
  userId: z.number(),
  goals: z.array(z.string()),
  bodyParts: z.array(z.string()),
  fitnessLevel: z.string(),
  age: z.number(),
  height: z.number().optional(),
  weight: z.number().optional(),
});

export type FitnessPlan = z.infer<typeof fitnessPlanSchema>;
