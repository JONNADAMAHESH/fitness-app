import { useEffect, useState, useRef } from "react";
import { Link } from "wouter";
import { 
  PlusCircle, 
  Zap, 
  Moon, 
  Droplet, 
  Book, 
  ChevronRight,
  Calendar,
  TrendingUp,
  Award,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Brain,
  Activity,
  MoonStar,
  Sparkles as Sparkle,
  Mic
} from "lucide-react";
import { formatDate } from "@/lib/utils";
import ProgressCard from "@/components/ProgressCard";
import WorkoutPlan from "@/components/WorkoutPlan";
import FeatureCard from "@/components/FeatureCard";
import HealthTipCard from "@/components/HealthTipCard";
import CoachCard from "@/components/CoachCard";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";

const Home = () => {
  const { toast } = useToast();
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [healthTipModal, setHealthTipModal] = useState<{
    show: boolean;
    title: string;
    content: string;
  }>({ show: false, title: "", content: "" });

  // Fetch workouts
  const { data: workouts, isLoading: isLoadingWorkouts } = useQuery({
    queryKey: ["/api/workouts"],
  });

  // Fetch health tips
  const { data: healthTips, isLoading: isLoadingHealthTips } = useQuery({
    queryKey: ["/api/health-tips"],
  });

  // Handle actions
  const handleStartWorkout = () => {
    toast({
      title: "Starting Workout",
      description: "Prepare for your Upper Body Focus workout!",
    });
  };

  const handleCustomizeWorkout = () => {
    toast({
      title: "Customize Workout",
      description: "You can customize your workout in the profile section",
    });
  };

  const handleReadMore = (title: string, content: string) => {
    setHealthTipModal({
      show: true,
      title,
      content,
    });
  };

  const handleScheduleCoach = () => {
    toast({
      title: "Schedule Session",
      description: "Your session has been scheduled for tomorrow at 5:30 PM",
    });
  };

  const handleMessageCoach = () => {
    toast({
      title: "Message Sent",
      description: "Your message has been sent to Coach Sarah",
    });
  };

  // Mock data (would normally come from API)
  const progressStats = {
    steps: {
      current: 7243,
      goal: 10000,
      remaining: "2,757 steps to go",
      percentage: 72,
    },
    calories: {
      current: 1840,
      goal: 2220,
      remaining: "380 cal remaining",
      percentage: 83,
    },
    sleep: {
      current: 7.3,
      goal: 9,
      remaining: "1.7h to goal",
      percentage: 81,
    },
    water: {
      current: 4,
      goal: 8,
      remaining: "4 cups to go",
      percentage: 50,
    },
  };

  const exercises = [
    { name: "Chest Press", sets: 3, reps: 12, restTime: 60 },
    { name: "Barbell Rows", sets: 3, reps: 10, restTime: 60 },
    { name: "Shoulder Press", sets: 3, reps: 12, restTime: 60 },
    { name: "Bicep Curls", sets: 3, reps: 15, restTime: 45 },
  ];

  const features = [
    {
      imageUrl: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b",
      title: "Yoga & Mindfulness",
      description: "Reduce stress and improve flexibility with guided yoga sessions for all levels.",
      linkText: "View sessions",
      linkUrl: "/yoga",
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd",
      title: "Nutrition & Diet",
      description: "Personalized meal plans and nutrition advice for your fitness goals.",
      linkText: "View plans",
      linkUrl: "/nutrition",
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1445384763658-0400939829cd",
      title: "Sleep & Recovery",
      description: "Track sleep patterns and learn strategies to improve rest and recovery.",
      linkText: "Track sleep",
      linkUrl: "/sleep",
    },
  ];

  return (
    <main className="flex-grow container mx-auto px-4 py-6 mb-16 md:mb-0">
      {/* Dashboard Section */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Your Dashboard</h2>
          <span className="text-gray-500">{formatDate(currentDate)}</span>
        </div>

        {/* Progress Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <ProgressCard
            title="Today's Steps"
            value={progressStats.steps.current.toLocaleString()}
            progressText={`${progressStats.steps.percentage}% of daily goal`}
            progress={progressStats.steps.percentage}
            icon={<PlusCircle className="h-6 w-6" />}
            color="primary"
          />
          <ProgressCard
            title="Calories"
            value={progressStats.calories.current.toLocaleString()}
            progressText={progressStats.calories.remaining}
            progress={progressStats.calories.percentage}
            icon={<Zap className="h-6 w-6" />}
            color="secondary"
          />
          <ProgressCard
            title="Sleep"
            value={progressStats.sleep.current}
            progressText={progressStats.sleep.remaining}
            progress={progressStats.sleep.percentage}
            icon={<Moon className="h-6 w-6" />}
            color="accent"
          />
          <ProgressCard
            title="Water"
            value={progressStats.water.current}
            progressText={progressStats.water.remaining}
            progress={progressStats.water.percentage}
            icon={<Droplet className="h-6 w-6" />}
            color="primary-light"
          />
        </div>
      </section>

      {/* Workout Plan Section */}
      <WorkoutPlan
        title="Upper Body Focus"
        level="Intermediate"
        duration={45}
        calories={350}
        imageUrl="https://images.unsplash.com/photo-1517836357463-d25dfeac3438"
        exercises={exercises}
        onStartWorkout={handleStartWorkout}
        onCustomize={handleCustomizeWorkout}
      />

      {/* Featured Sections */}
      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-6">Explore Features</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              imageUrl={feature.imageUrl}
              title={feature.title}
              description={feature.description}
              linkText={feature.linkText}
              linkUrl={feature.linkUrl}
            />
          ))}
        </div>
      </section>
      
      {/* Advanced Health Features */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Advanced Health Features</h2>
          <Link href="/explore">
            <div className="text-primary font-medium text-sm flex items-center cursor-pointer">
              View all features
              <ChevronRight className="h-4 w-4 ml-1" />
            </div>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="overflow-hidden">
            <div className="h-40 bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center text-white">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Brain className="h-16 w-16" />
              </motion.div>
            </div>
            <CardHeader className="pb-2">
              <CardTitle>Mental Health Assessment</CardTitle>
              <CardDescription>
                Evaluate your mental wellbeing and get personalized recommendations
              </CardDescription>
            </CardHeader>
            <CardFooter>
              <Link href="/mental-health">
                <Button className="w-full">
                  Start Assessment
                </Button>
              </Link>
            </CardFooter>
          </Card>
          
          <Card className="overflow-hidden">
            <div className="h-40 bg-gradient-to-r from-blue-600 to-teal-500 flex items-center justify-center text-white">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Activity className="h-16 w-16" />
              </motion.div>
            </div>
            <CardHeader className="pb-2">
              <CardTitle>Biofeedback Training</CardTitle>
              <CardDescription>
                Learn to control your body's stress response with real-time feedback
              </CardDescription>
            </CardHeader>
            <CardFooter>
              <Link href="/biofeedback">
                <Button className="w-full">
                  Start Training
                </Button>
              </Link>
            </CardFooter>
          </Card>
          
          <Card className="overflow-hidden">
            <div className="h-40 bg-gradient-to-r from-indigo-600 to-purple-500 flex items-center justify-center text-white">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <MoonStar className="h-16 w-16" />
              </motion.div>
            </div>
            <CardHeader className="pb-2">
              <CardTitle>Sleep Analytics</CardTitle>
              <CardDescription>
                Analyze your sleep patterns and improve rest quality with AI insights
              </CardDescription>
            </CardHeader>
            <CardFooter>
              <Link href="/sleep-analytics">
                <Button className="w-full">
                  View Analytics
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <Card className="overflow-hidden">
            <div className="h-40 bg-gradient-to-r from-green-600 to-teal-500 flex items-center justify-center text-white">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Sparkle className="h-16 w-16" />
              </motion.div>
            </div>
            <CardHeader className="pb-2">
              <CardTitle>Cognitive Training</CardTitle>
              <CardDescription>
                Enhance mental performance with brain games and memory exercises
              </CardDescription>
            </CardHeader>
            <CardFooter>
              <Link href="/cognitive-training">
                <Button className="w-full">
                  Train Your Brain
                </Button>
              </Link>
            </CardFooter>
          </Card>
          
          <Card className="overflow-hidden">
            <div className="h-40 bg-gradient-to-r from-amber-500 to-orange-600 flex items-center justify-center text-white">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Mic className="h-16 w-16" />
              </motion.div>
            </div>
            <CardHeader className="pb-2">
              <CardTitle>Voice-Guided Meditation</CardTitle>
              <CardDescription>
                Practice mindfulness with voice-controlled meditation sessions
              </CardDescription>
            </CardHeader>
            <CardFooter>
              <Link href="/guided-meditation">
                <Button className="w-full">
                  Start Meditating
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </section>

      {/* Fitness Coaching */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Live Coaching</h2>
          <Link href="/coaches">
            <div className="text-primary font-medium text-sm flex items-center cursor-pointer">
              View all coaches
              <ChevronRight className="h-4 w-4 ml-1" />
            </div>
          </Link>
        </div>

        <CoachCard
          name="Coach Sarah"
          specialization="Certified Personal Trainer, Nutrition Specialist"
          imageUrl="https://images.unsplash.com/photo-1517836357463-d25dfeac3438"
          nextSession="Tomorrow, 5:30 PM"
          onSchedule={handleScheduleCoach}
          onMessage={handleMessageCoach}
        />
      </section>

      {/* Health Tips Section */}
      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-6">Health Tips</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <HealthTipCard
            icon={<Book className="h-6 w-6 text-amber-500" />}
            title="Vitamin D: The Sunshine Nutrient"
            content="Learn why Vitamin D is crucial for bone health, immune function, and overall wellbeing - especially for adults over 35."
            onReadMore={() => handleReadMore(
              "Vitamin D: The Sunshine Nutrient",
              "Vitamin D is essential for calcium absorption, bone health, and immune function. As we age, our ability to synthesize vitamin D from sunlight decreases, making supplementation more important. Adults over 35 should consider getting their vitamin D levels checked regularly. Natural sources include fatty fish, egg yolks, and fortified foods. Regular, moderate sun exposure (10-15 minutes a day) can also help boost your vitamin D levels naturally."
            )}
          />
          <HealthTipCard
            icon={<Book className="h-6 w-6 text-amber-500" />}
            title="The Importance of Sleep for Recovery"
            content="Discover why quality sleep is essential for muscle recovery, hormone regulation, and maintaining a healthy weight."
            onReadMore={() => handleReadMore(
              "The Importance of Sleep for Recovery",
              "Quality sleep is when your body repairs muscles, consolidates memory, and regulates crucial hormones like cortisol (stress) and leptin/ghrelin (hunger). Consistently getting 7-9 hours of sleep can improve workout performance, accelerate recovery, and help maintain a healthy weight. Create a sleep routine by going to bed at the same time, keeping your bedroom cool and dark, and avoiding screens at least 30 minutes before bedtime. Your fitness results will dramatically improve with better sleep habits."
            )}
          />
        </div>
      </section>

      {/* Health Tip Modal */}
      <Dialog open={healthTipModal.show} onOpenChange={(open) => setHealthTipModal(prev => ({ ...prev, show: open }))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{healthTipModal.title}</DialogTitle>
            <DialogDescription className="pt-4">
              {healthTipModal.content}
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </main>
  );
};

export default Home;
