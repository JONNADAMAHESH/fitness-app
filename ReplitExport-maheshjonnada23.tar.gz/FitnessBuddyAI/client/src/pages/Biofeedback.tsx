import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { 
  Activity, 
  Heart, 
  Droplets, 
  Zap, 
  BarChart3, 
  Brain,
  ArrowDown,
  ArrowUp,
  LineChart,
  Timer,
  Play,
  Pause,
  RefreshCw,
  Laptop,
  Smartphone,
  ScanLine
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";

interface BiofeedbackSession {
  id: string;
  date: Date;
  duration: number; // in minutes
  averageHR: number;
  minHR: number;
  maxHR: number;
  averageHRV: number;
  averageGSR: number; // galvanic skin response
  breathRate: number;
  stressScore: number;
  coherenceScore: number;
}

interface BreathPattern {
  id: string;
  name: string;
  inhaleTime: number;
  holdAfterInhale: number;
  exhaleTime: number;
  holdAfterExhale: number;
  description: string;
}

export default function Biofeedback() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [selectedDuration, setSelectedDuration] = useState("5");
  const [selectedBreathPattern, setSelectedBreathPattern] = useState<BreathPattern | null>(null);
  const [breathPhase, setBreathPhase] = useState<"inhale" | "inhale-hold" | "exhale" | "exhale-hold">("inhale");
  const [phaseProgress, setPhaseProgress] = useState(0);
  const [currentHeartRate, setCurrentHeartRate] = useState(75);
  const [coherenceScore, setCoherenceScore] = useState(0);
  const [stressLevel, setStressLevel] = useState(60);
  const [hrv, setHrv] = useState(45);
  const [gsr, setGsr] = useState(3.2);
  const [breathingRate, setBreathingRate] = useState(12);
  
  const sessionTimerRef = useRef<NodeJS.Timeout | null>(null);
  const breathTimerRef = useRef<NodeJS.Timeout | null>(null);
  const simulationTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Sample breath patterns
  const breathPatterns: BreathPattern[] = [
    {
      id: "box-breathing",
      name: "Box Breathing",
      inhaleTime: 4,
      holdAfterInhale: 4,
      exhaleTime: 4,
      holdAfterExhale: 4,
      description: "A technique used by Navy SEALs to induce calm and reduce stress."
    },
    {
      id: "4-7-8",
      name: "4-7-8 Technique",
      inhaleTime: 4,
      holdAfterInhale: 7,
      exhaleTime: 8,
      holdAfterExhale: 0,
      description: "Helps reduce anxiety and helps people fall asleep."
    },
    {
      id: "coherent-breathing",
      name: "Coherent Breathing",
      inhaleTime: 5.5,
      holdAfterInhale: 0,
      exhaleTime: 5.5,
      holdAfterExhale: 0,
      description: "Helps achieve heart rate variability coherence for optimal stress reduction."
    },
    {
      id: "diaphragmatic",
      name: "Diaphragmatic Breathing",
      inhaleTime: 4,
      holdAfterInhale: 1,
      exhaleTime: 6,
      holdAfterExhale: 1,
      description: "Deep belly breathing that activates the parasympathetic nervous system."
    }
  ];
  
  // Sample biofeedback session history
  const sessionHistory: BiofeedbackSession[] = [
    {
      id: "session-1",
      date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
      duration: 10,
      averageHR: 72,
      minHR: 65,
      maxHR: 78,
      averageHRV: 42,
      averageGSR: 3.1,
      breathRate: 8,
      stressScore: 45,
      coherenceScore: 68
    },
    {
      id: "session-2",
      date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      duration: 5,
      averageHR: 70,
      minHR: 67,
      maxHR: 75,
      averageHRV: 45,
      averageGSR: 3.0,
      breathRate: 7,
      stressScore: 40,
      coherenceScore: 72
    },
    {
      id: "session-3",
      date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      duration: 15,
      averageHR: 68,
      minHR: 63,
      maxHR: 74,
      averageHRV: 48,
      averageGSR: 2.8,
      breathRate: 6,
      stressScore: 35,
      coherenceScore: 79
    }
  ];
  
  // Initialize with a default breath pattern
  useEffect(() => {
    setSelectedBreathPattern(breathPatterns[0]);
  }, []);
  
  // Start biofeedback session
  const startSession = () => {
    if (!selectedBreathPattern) {
      toast({
        title: "Error",
        description: "Please select a breathing pattern.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSessionActive(true);
    setSessionTime(0);
    setBreathPhase("inhale");
    setPhaseProgress(0);
    setCoherenceScore(20); // Start with a low score
    
    // Start session timer
    const durationInMinutes = parseInt(selectedDuration);
    const totalSessionTimeInMs = durationInMinutes * 60 * 1000;
    const startTime = Date.now();
    
    if (sessionTimerRef.current) {
      clearInterval(sessionTimerRef.current);
    }
    
    sessionTimerRef.current = setInterval(() => {
      const elapsedTime = Date.now() - startTime;
      setSessionTime(elapsedTime);
      
      if (elapsedTime >= totalSessionTimeInMs) {
        endSession();
      }
    }, 1000);
    
    // Start breath guide
    startBreathingGuide();
    
    // Start biometric simulation
    startBiometricSimulation();
    
    toast({
      title: "Session started",
      description: `Started a ${durationInMinutes} minute biofeedback session.`,
    });
  };
  
  // Start the breathing guide
  const startBreathingGuide = () => {
    if (!selectedBreathPattern) return;
    
    if (breathTimerRef.current) {
      clearInterval(breathTimerRef.current);
    }
    
    // The total cycle time in milliseconds
    const totalCycleTime = (
      (selectedBreathPattern.inhaleTime + 
       selectedBreathPattern.holdAfterInhale + 
       selectedBreathPattern.exhaleTime + 
       selectedBreathPattern.holdAfterExhale) * 1000
    );
    
    // Set up interval for smooth animation
    const updateInterval = 50; // Update every 50ms for smooth animation
    let currentPhase: "inhale" | "inhale-hold" | "exhale" | "exhale-hold" = "inhale";
    let timeInPhase = 0;
    
    breathTimerRef.current = setInterval(() => {
      timeInPhase += updateInterval;
      
      // Determine current phase
      if (currentPhase === "inhale" && timeInPhase >= selectedBreathPattern.inhaleTime * 1000) {
        currentPhase = "inhale-hold";
        timeInPhase = 0;
        setBreathPhase("inhale-hold");
      } else if (currentPhase === "inhale-hold" && timeInPhase >= selectedBreathPattern.holdAfterInhale * 1000) {
        currentPhase = "exhale";
        timeInPhase = 0;
        setBreathPhase("exhale");
      } else if (currentPhase === "exhale" && timeInPhase >= selectedBreathPattern.exhaleTime * 1000) {
        currentPhase = "exhale-hold";
        timeInPhase = 0;
        setBreathPhase("exhale-hold");
      } else if (currentPhase === "exhale-hold" && timeInPhase >= selectedBreathPattern.holdAfterExhale * 1000) {
        currentPhase = "inhale";
        timeInPhase = 0;
        setBreathPhase("inhale");
      }
      
      // Calculate progress for current phase
      let phaseDuration: number = 0;
      switch (currentPhase) {
        case "inhale":
          phaseDuration = selectedBreathPattern.inhaleTime * 1000;
          break;
        case "inhale-hold":
          phaseDuration = selectedBreathPattern.holdAfterInhale * 1000;
          break;
        case "exhale":
          phaseDuration = selectedBreathPattern.exhaleTime * 1000;
          break;
        case "exhale-hold":
          phaseDuration = selectedBreathPattern.holdAfterExhale * 1000;
          break;
      }
      
      if (phaseDuration > 0) {
        setPhaseProgress((timeInPhase / phaseDuration) * 100);
      }
      
    }, updateInterval);
  };
  
  // Simulate biometric changes during the session
  const startBiometricSimulation = () => {
    if (simulationTimerRef.current) {
      clearInterval(simulationTimerRef.current);
    }
    
    const updateInterval = 2000; // Update every 2 seconds
    let elapsed = 0;
    
    simulationTimerRef.current = setInterval(() => {
      elapsed += updateInterval;
      
      // Simulate heart rate - gradually decreases with controlled breathing
      const hrMaxDecrease = 15;
      const hrProgress = Math.min(elapsed / (parseInt(selectedDuration) * 60 * 1000), 1);
      const newHR = Math.max(65, 75 - (hrMaxDecrease * hrProgress) + (Math.random() * 4 - 2));
      setCurrentHeartRate(Math.round(newHR));
      
      // Simulate coherence score - gradually increases
      const maxCoherence = 90;
      const coherenceIncrease = 70; // We start at 20, so we can increase by up to 70
      const coherenceProgress = Math.min(elapsed / (parseInt(selectedDuration) * 60 * 1000 * 0.7), 1);
      const newCoherence = Math.min(maxCoherence, 20 + (coherenceIncrease * coherenceProgress) + (Math.random() * 6 - 3));
      setCoherenceScore(Math.round(newCoherence));
      
      // Simulate stress level - gradually decreases
      const minStress = 20;
      const stressDecrease = 40; // From 60 to 20
      const stressProgress = Math.min(elapsed / (parseInt(selectedDuration) * 60 * 1000 * 0.8), 1);
      const newStress = Math.max(minStress, 60 - (stressDecrease * stressProgress) + (Math.random() * 6 - 3));
      setStressLevel(Math.round(newStress));
      
      // Simulate HRV - gradually increases
      const maxHRV = 75;
      const hrvIncrease = 30; // From 45 to 75
      const hrvProgress = Math.min(elapsed / (parseInt(selectedDuration) * 60 * 1000 * 0.75), 1);
      const newHRV = Math.min(maxHRV, 45 + (hrvIncrease * hrvProgress) + (Math.random() * 5 - 2.5));
      setHrv(Math.round(newHRV));
      
      // Simulate GSR - gradually decreases (less sweat = less stress)
      const minGSR = 1.8;
      const gsrDecrease = 1.4; // From 3.2 to 1.8
      const gsrProgress = Math.min(elapsed / (parseInt(selectedDuration) * 60 * 1000 * 0.85), 1);
      const newGSR = Math.max(minGSR, 3.2 - (gsrDecrease * gsrProgress) + (Math.random() * 0.3 - 0.15));
      setGsr(parseFloat(newGSR.toFixed(1)));
      
      // Simulate breathing rate - gradually decreases to match the guided pattern
      const minBreathRate = 6;
      const breathRateDecrease = 6; // From 12 to 6
      const breathProgress = Math.min(elapsed / (parseInt(selectedDuration) * 60 * 1000 * 0.6), 1);
      const newBreathRate = Math.max(minBreathRate, 12 - (breathRateDecrease * breathProgress) + (Math.random() * 1 - 0.5));
      setBreathingRate(parseFloat(newBreathRate.toFixed(1)));
      
    }, updateInterval);
  };
  
  // End the biofeedback session
  const endSession = () => {
    setIsSessionActive(false);
    
    // Clear all timers
    if (sessionTimerRef.current) {
      clearInterval(sessionTimerRef.current);
      sessionTimerRef.current = null;
    }
    
    if (breathTimerRef.current) {
      clearInterval(breathTimerRef.current);
      breathTimerRef.current = null;
    }
    
    if (simulationTimerRef.current) {
      clearInterval(simulationTimerRef.current);
      simulationTimerRef.current = null;
    }
    
    // Show session summary
    toast({
      title: "Session complete",
      description: `Completed a biofeedback session with ${coherenceScore}% coherence.`,
    });
    
    // Switch to the results tab
    setActiveTab("results");
  };
  
  // Pause or resume the session
  const toggleSession = () => {
    if (isSessionActive) {
      // Pause session
      if (sessionTimerRef.current) {
        clearInterval(sessionTimerRef.current);
      }
      
      if (breathTimerRef.current) {
        clearInterval(breathTimerRef.current);
      }
      
      if (simulationTimerRef.current) {
        clearInterval(simulationTimerRef.current);
      }
      
      setIsSessionActive(false);
      
      toast({
        title: "Session paused",
        description: "Your biofeedback session has been paused.",
      });
    } else {
      // Resume session
      startSession();
      
      toast({
        title: "Session resumed",
        description: "Your biofeedback session has been resumed.",
      });
    }
  };
  
  // Format time for display (mm:ss)
  const formatSessionTime = () => {
    const totalSeconds = Math.floor(sessionTime / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Calculate session progress percentage
  const getSessionProgress = () => {
    const durationInMs = parseInt(selectedDuration) * 60 * 1000;
    return Math.min((sessionTime / durationInMs) * 100, 100);
  };
  
  // Get color based on coherence score
  const getCoherenceColor = (score: number) => {
    if (score < 40) return "text-red-500";
    if (score < 60) return "text-yellow-500";
    if (score < 80) return "text-blue-500";
    return "text-green-500";
  };
  
  // Get color based on stress level
  const getStressColor = (level: number) => {
    if (level > 70) return "text-red-500";
    if (level > 50) return "text-yellow-500";
    if (level > 30) return "text-blue-500";
    return "text-green-500";
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (sessionTimerRef.current) clearInterval(sessionTimerRef.current);
      if (breathTimerRef.current) clearInterval(breathTimerRef.current);
      if (simulationTimerRef.current) clearInterval(simulationTimerRef.current);
    };
  }, []);
  
  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col items-center mb-8">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold text-center bg-gradient-to-r from-blue-600 to-teal-500 text-transparent bg-clip-text">
            Biofeedback Training
          </h1>
        </motion.div>
        <p className="text-gray-600 mt-2 text-center max-w-2xl">
          Learn to control your physiological responses to stress through real-time feedback and guided exercises.
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 max-w-lg mx-auto mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="training">Training</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>What is Biofeedback?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Biofeedback is a technique that helps you learn to control your body's functions, such as your heart rate or breathing. This is done by measuring these functions and providing real-time feedback.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                        <Heart className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">Heart Rate Variability (HRV)</p>
                        <p className="text-sm text-gray-500">The variation in time between consecutive heartbeats, a key indicator of autonomic nervous system function.</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                        <Droplets className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium">Galvanic Skin Response (GSR)</p>
                        <p className="text-sm text-gray-500">Measures changes in the electrical properties of the skin related to sweat gland activity, an indicator of stress.</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                        <Zap className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-medium">Respiratory Rate</p>
                        <p className="text-sm text-gray-500">The number of breaths per minute, which can be voluntarily controlled to influence other physiological parameters.</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Benefits of Biofeedback</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Regular biofeedback training can help you develop greater awareness and control over physiological functions that are normally automatic, leading to numerous health benefits.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span>Reduced stress and anxiety</span>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span>Improved focus and concentration</span>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span>Better sleep quality</span>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span>Enhanced emotional regulation</span>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span>Improved heart rate variability</span>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span>Reduced muscle tension and pain</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-center mb-2">
                    <div className="p-3 rounded-full bg-blue-100">
                      <Brain className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                  <CardTitle className="text-center">Neurofeedback</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-gray-600">
                    Monitors brain activity in real-time and provides feedback to help train your brain for improved focus and relaxation.
                  </p>
                </CardContent>
                <CardFooter className="pt-0 flex justify-center">
                  <Badge className="bg-blue-50 text-blue-700 hover:bg-blue-100">Coming Soon</Badge>
                </CardFooter>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-center mb-2">
                    <div className="p-3 rounded-full bg-green-100">
                      <Activity className="h-6 w-6 text-green-600" />
                    </div>
                  </div>
                  <CardTitle className="text-center">HRV Training</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-gray-600">
                    Learn to increase your heart rate variability for improved stress resilience and emotional regulation.
                  </p>
                </CardContent>
                <CardFooter className="pt-0 flex justify-center">
                  <Button variant="outline" onClick={() => setActiveTab("training")}>
                    Start Training
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-center mb-2">
                    <div className="p-3 rounded-full bg-purple-100">
                      <BarChart3 className="h-6 w-6 text-purple-600" />
                    </div>
                  </div>
                  <CardTitle className="text-center">Progress Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-gray-600">
                    Track your biofeedback training progress over time with detailed analytics and insights.
                  </p>
                </CardContent>
                <CardFooter className="pt-0 flex justify-center">
                  <Button variant="outline" onClick={() => setActiveTab("history")}>
                    View History
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          </div>
          
          <div className="mt-12">
            <Card className="bg-gradient-to-r from-blue-50 to-teal-50 border-none">
              <CardHeader>
                <CardTitle className="text-xl text-center">Ready to Get Started?</CardTitle>
                <CardDescription className="text-center">
                  Begin your biofeedback journey with a guided HRV training session
                </CardDescription>
              </CardHeader>
              <CardFooter className="flex justify-center pb-6">
                <Button 
                  className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                  onClick={() => setActiveTab("training")}
                >
                  Start Training
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="training">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>HRV Coherence Training</CardTitle>
                <CardDescription>
                  Follow the breathing guide to synchronize your heart rhythm and increase coherence
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {!isSessionActive ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Session Duration</label>
                        <Select 
                          value={selectedDuration} 
                          onValueChange={setSelectedDuration}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select duration" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="3">3 minutes</SelectItem>
                            <SelectItem value="5">5 minutes</SelectItem>
                            <SelectItem value="10">10 minutes</SelectItem>
                            <SelectItem value="15">15 minutes</SelectItem>
                            <SelectItem value="20">20 minutes</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium mb-2 block">Breathing Pattern</label>
                        <Select 
                          value={selectedBreathPattern?.id} 
                          onValueChange={(value) => {
                            const pattern = breathPatterns.find(p => p.id === value);
                            if (pattern) setSelectedBreathPattern(pattern);
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select pattern" />
                          </SelectTrigger>
                          <SelectContent>
                            {breathPatterns.map(pattern => (
                              <SelectItem key={pattern.id} value={pattern.id}>
                                {pattern.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    {selectedBreathPattern && (
                      <div className="p-4 border rounded-lg bg-gray-50">
                        <h3 className="font-medium mb-2">{selectedBreathPattern.name}</h3>
                        <p className="text-sm text-gray-600 mb-3">{selectedBreathPattern.description}</p>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500">Inhale:</span> {selectedBreathPattern.inhaleTime} seconds
                          </div>
                          <div>
                            <span className="text-gray-500">Hold after inhale:</span> {selectedBreathPattern.holdAfterInhale} seconds
                          </div>
                          <div>
                            <span className="text-gray-500">Exhale:</span> {selectedBreathPattern.exhaleTime} seconds
                          </div>
                          <div>
                            <span className="text-gray-500">Hold after exhale:</span> {selectedBreathPattern.holdAfterExhale} seconds
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-center space-x-4">
                      <div className="flex-shrink-0">
                        <div className="p-3 rounded-full bg-blue-100">
                          <ScanLine className="h-6 w-6 text-blue-600" />
                        </div>
                      </div>
                      <div>
                        <h3 className="font-medium">Connect to Biofeedback Devices</h3>
                        <p className="text-sm text-gray-500">Our app is compatible with the following devices:</p>
                        <div className="flex space-x-4 mt-2 text-sm">
                          <div className="flex items-center">
                            <Smartphone className="h-4 w-4 mr-1 text-gray-500" />
                            <span>Mobile Sensors</span>
                          </div>
                          <div className="flex items-center">
                            <Laptop className="h-4 w-4 mr-1 text-gray-500" />
                            <span>Webcam PPG</span>
                          </div>
                          <div className="flex items-center">
                            <Heart className="h-4 w-4 mr-1 text-gray-500" />
                            <span>HRV Sensors</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-center pt-4">
                      <Button 
                        size="lg"
                        className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                        onClick={startSession}
                      >
                        Start Session
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Timer className="h-5 w-5 text-gray-500" />
                        <span className="text-lg font-medium">{formatSessionTime()}</span>
                      </div>
                      <Badge variant="outline" className="bg-blue-50 text-blue-800">
                        {selectedBreathPattern?.name}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Session Progress</span>
                        <span>{Math.round(getSessionProgress())}%</span>
                      </div>
                      <Progress value={getSessionProgress()} className="h-2" />
                    </div>
                    
                    <div className="p-6 bg-gradient-to-r from-blue-50 to-teal-50 rounded-lg flex flex-col items-center">
                      <motion.div
                        animate={{
                          scale: breathPhase === "inhale" || breathPhase === "inhale-hold" ? [1, 1.15] : [1.15, 1],
                          transition: {
                            duration: breathPhase === "inhale" ? selectedBreathPattern?.inhaleTime || 4 :
                                      breathPhase === "exhale" ? selectedBreathPattern?.exhaleTime || 4 : 0.1,
                            ease: "easeInOut"
                          }
                        }}
                        className="w-32 h-32 rounded-full bg-white shadow-md border border-blue-100 flex items-center justify-center mb-6"
                      >
                        {breathPhase === "inhale" && <ArrowDown className="h-10 w-10 text-blue-500" />}
                        {breathPhase === "inhale-hold" && <span className="text-blue-500 text-lg font-medium">Hold</span>}
                        {breathPhase === "exhale" && <ArrowUp className="h-10 w-10 text-teal-500" />}
                        {breathPhase === "exhale-hold" && <span className="text-teal-500 text-lg font-medium">Hold</span>}
                      </motion.div>
                      
                      <div className="text-center mb-2">
                        <h3 className="text-lg font-medium">
                          {breathPhase === "inhale" ? "Breathe In" :
                           breathPhase === "inhale-hold" ? "Hold" :
                           breathPhase === "exhale" ? "Breathe Out" : "Hold"}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {breathPhase === "inhale" ? "Inhale deeply through your nose" :
                           breathPhase === "inhale-hold" ? "Hold your breath" :
                           breathPhase === "exhale" ? "Exhale slowly through your mouth" : "Hold and prepare to inhale"}
                        </p>
                      </div>
                      
                      <Progress value={phaseProgress} className="h-1.5 w-64 max-w-full" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <Button 
                        variant="outline"
                        onClick={endSession}
                        className="w-full"
                      >
                        End Session
                      </Button>
                      <Button 
                        variant={isSessionActive ? "destructive" : "default"}
                        onClick={toggleSession}
                        className="w-full"
                      >
                        {isSessionActive ? "Pause" : "Resume"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Real-time Metrics</CardTitle>
                <CardDescription>
                  {isSessionActive 
                    ? "Your current biofeedback measurements"
                    : "Connect your device to see real-time metrics"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="text-center pb-4">
                  <div className="relative inline-flex items-center justify-center">
                    <svg className="w-32 h-32">
                      <circle
                        cx="64"
                        cy="64"
                        r="58"
                        fill="none"
                        stroke="#e2e8f0"
                        strokeWidth="8"
                      />
                      <circle
                        cx="64"
                        cy="64"
                        r="58"
                        fill="none"
                        stroke={`${
                          coherenceScore < 40 ? "#ef4444" :
                          coherenceScore < 60 ? "#f59e0b" :
                          coherenceScore < 80 ? "#3b82f6" : "#22c55e"
                        }`}
                        strokeWidth="8"
                        strokeDasharray={`${coherenceScore * 3.65} 365`}
                        strokeDashoffset="0"
                        strokeLinecap="round"
                        transform="rotate(-90 64 64)"
                      />
                    </svg>
                    <div className="absolute flex flex-col items-center justify-center">
                      <span className={`text-3xl font-bold ${getCoherenceColor(coherenceScore)}`}>
                        {coherenceScore}%
                      </span>
                      <span className="text-xs text-gray-500">Coherence</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <div className="flex items-center">
                        <Heart className="h-4 w-4 mr-1 text-red-500" />
                        <span className="text-sm font-medium">Heart Rate</span>
                      </div>
                      <span className="text-sm">{currentHeartRate} BPM</span>
                    </div>
                    <Progress value={(currentHeartRate - 50) / 100 * 100} className="h-1.5" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <div className="flex items-center">
                        <Activity className="h-4 w-4 mr-1 text-blue-500" />
                        <span className="text-sm font-medium">HRV</span>
                      </div>
                      <span className="text-sm">{hrv} ms</span>
                    </div>
                    <Progress value={hrv / 100 * 100} className="h-1.5" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <div className="flex items-center">
                        <Droplets className="h-4 w-4 mr-1 text-green-500" />
                        <span className="text-sm font-medium">GSR</span>
                      </div>
                      <span className="text-sm">{gsr} μS</span>
                    </div>
                    <Progress value={gsr / 8 * 100} className="h-1.5" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <div className="flex items-center">
                        <Zap className="h-4 w-4 mr-1 text-yellow-500" />
                        <span className="text-sm font-medium">Stress Level</span>
                      </div>
                      <span className={`text-sm ${getStressColor(stressLevel)}`}>{stressLevel}%</span>
                    </div>
                    <Progress value={stressLevel} className="h-1.5" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <div className="flex items-center">
                        <ScanLine className="h-4 w-4 mr-1 text-purple-500" />
                        <span className="text-sm font-medium">Breathing Rate</span>
                      </div>
                      <span className="text-sm">{breathingRate} breaths/min</span>
                    </div>
                    <Progress value={breathingRate / 20 * 100} className="h-1.5" />
                  </div>
                </div>
                
                {!isSessionActive && (
                  <div className="flex justify-center pt-4">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div>
                            <Button 
                              variant="outline" 
                              className="w-full"
                              disabled={!isSessionActive}
                            >
                              <RefreshCw className="h-4 w-4 mr-2" />
                              Calibrate Sensors
                            </Button>
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Start a session to enable sensor calibration</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="results">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="max-w-4xl mx-auto mb-8">
              <CardHeader>
                <CardTitle>Your Session Results</CardTitle>
                <CardDescription>
                  Analysis of your most recent biofeedback training session
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gradient-to-r from-blue-50 to-teal-50 rounded-lg">
                  <div className="text-center">
                    <p className="text-gray-500 text-sm mb-1">Coherence Score</p>
                    <p className={`text-2xl font-bold ${getCoherenceColor(coherenceScore)}`}>{coherenceScore}%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-500 text-sm mb-1">Stress Reduction</p>
                    <p className="text-2xl font-bold text-green-600">-{60 - stressLevel}%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-500 text-sm mb-1">HRV Improvement</p>
                    <p className="text-2xl font-bold text-blue-600">+{hrv - 45}ms</p>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium mb-4">Session Analysis</h3>
                  <div className="space-y-4">
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center mb-2">
                        <Activity className="h-5 w-5 mr-2 text-blue-500" />
                        <h4 className="font-medium">Heart Rate Variability</h4>
                      </div>
                      <p className="text-sm text-gray-600">
                        Your HRV increased from 45ms to {hrv}ms during the session, indicating improved autonomic nervous system balance and reduced stress.
                      </p>
                    </div>
                    
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center mb-2">
                        <Droplets className="h-5 w-5 mr-2 text-green-500" />
                        <h4 className="font-medium">Stress Response</h4>
                      </div>
                      <p className="text-sm text-gray-600">
                        Your GSR decreased from 3.2μS to {gsr}μS, showing reduced sweat gland activity which correlates with lower stress levels.
                      </p>
                    </div>
                    
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center mb-2">
                        <ScanLine className="h-5 w-5 mr-2 text-purple-500" />
                        <h4 className="font-medium">Breathing Pattern</h4>
                      </div>
                      <p className="text-sm text-gray-600">
                        Your breathing rate slowed from 12 to {breathingRate} breaths per minute, approaching the optimal resonant frequency for maximum HRV.
                      </p>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium mb-2">Recommendations</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span className="text-gray-700">Practice this breathing pattern for 5-10 minutes daily to maintain and improve your HRV.</span>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span className="text-gray-700">Try increasing session duration to 10 minutes for enhanced stress resilience.</span>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3 mt-0.5">✓</div>
                      <span className="text-gray-700">Use this breathing technique during stressful situations to activate your parasympathetic nervous system.</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setActiveTab("training")}>
                  New Session
                </Button>
                <Button 
                  className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                  onClick={() => setActiveTab("history")}
                >
                  View History
                </Button>
              </CardFooter>
            </Card>
            
            <div className="max-w-4xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle>Coherence Chart</CardTitle>
                  <CardDescription>
                    Visualization would show your heart rhythm pattern and coherence level over time
                  </CardDescription>
                </CardHeader>
                <CardContent className="h-64 flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                    <p className="text-gray-500">Real-time coherence chart would be displayed here</p>
                    <p className="text-sm text-gray-400">Showing heart rhythm patterns and coherence scores</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>
        
        <TabsContent value="history">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Session History</CardTitle>
                <CardDescription>
                  Your biofeedback training sessions over time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sessionHistory.map((session, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-medium">{session.date.toLocaleDateString()}</h4>
                          <p className="text-sm text-gray-500">{session.duration} minute session</p>
                        </div>
                        <Badge variant="outline" className={
                          session.coherenceScore >= 80 ? "bg-green-50 text-green-700 border-green-200" :
                          session.coherenceScore >= 60 ? "bg-blue-50 text-blue-700 border-blue-200" :
                          session.coherenceScore >= 40 ? "bg-yellow-50 text-yellow-700 border-yellow-200" :
                          "bg-red-50 text-red-700 border-red-200"
                        }>
                          {session.coherenceScore}% Coherence
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                        <div>
                          <p className="text-gray-500">Heart Rate</p>
                          <p className="font-medium">{session.averageHR} BPM</p>
                        </div>
                        <div>
                          <p className="text-gray-500">HRV</p>
                          <p className="font-medium">{session.averageHRV} ms</p>
                        </div>
                        <div>
                          <p className="text-gray-500">GSR</p>
                          <p className="font-medium">{session.averageGSR} μS</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Breathing Rate</p>
                          <p className="font-medium">{session.breathRate} BPM</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Progress Summary</CardTitle>
                <CardDescription>
                  Your biofeedback training improvement over time
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="p-4 bg-gray-50 rounded-lg text-center">
                  <p className="text-gray-500 text-sm mb-1">Total Training Time</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {sessionHistory.reduce((sum, session) => sum + session.duration, 0)} minutes
                  </p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Average Coherence</span>
                      <span className="text-sm text-gray-500">
                        {Math.round(sessionHistory.reduce((sum, session) => sum + session.coherenceScore, 0) / sessionHistory.length)}%
                      </span>
                    </div>
                    <Progress 
                      value={sessionHistory.reduce((sum, session) => sum + session.coherenceScore, 0) / sessionHistory.length} 
                      className="h-2" 
                    />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Average HRV</span>
                      <span className="text-sm text-gray-500">
                        {Math.round(sessionHistory.reduce((sum, session) => sum + session.averageHRV, 0) / sessionHistory.length)} ms
                      </span>
                    </div>
                    <Progress 
                      value={sessionHistory.reduce((sum, session) => sum + session.averageHRV, 0) / sessionHistory.length / 100 * 100} 
                      className="h-2" 
                    />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Stress Reduction</span>
                      <span className="text-sm text-gray-500">
                        -{100 - Math.round(sessionHistory.reduce((sum, session) => sum + session.stressScore, 0) / sessionHistory.length)}%
                      </span>
                    </div>
                    <Progress 
                      value={100 - sessionHistory.reduce((sum, session) => sum + session.stressScore, 0) / sessionHistory.length} 
                      className="h-2" 
                    />
                  </div>
                </div>
                
                <div className="h-48 flex items-center justify-center text-gray-500 border rounded-lg">
                  <div className="text-center">
                    <BarChart3 className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                    <p>Progress charts would be displayed here</p>
                    <p className="text-xs text-gray-400">Showing trends in key metrics over time</p>
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button 
                    className="w-full bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                    onClick={() => setActiveTab("training")}
                  >
                    New Training Session
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}