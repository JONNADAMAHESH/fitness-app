import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { 
  Heart, 
  Clock, 
  Mic, 
  Volume2, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward,
  Moon,
  Sun,
  Wind,
  Sparkles,
  Feather,
  Headphones
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

interface Meditation {
  id: string;
  title: string;
  description: string;
  category: "sleep" | "focus" | "stress" | "mindfulness" | "energy";
  duration: number; // in minutes
  voiceActivated: boolean;
  backgroundSound: string;
  icon: React.ReactNode;
  favorited?: boolean;
  completions?: number;
  image?: string;
}

export default function GuidedMeditation() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("featured");
  const [currentMeditation, setCurrentMeditation] = useState<Meditation | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentProgress, setCurrentProgress] = useState(0);
  const [volume, setVolume] = useState(70);
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const [voiceCommands, setVoiceCommands] = useState<string[]>([]);
  const progressRef = useRef<NodeJS.Timeout | null>(null);
  
  // Sample meditation data
  const meditations: Meditation[] = [
    {
      id: "deep-sleep",
      title: "Deep Sleep Journey",
      description: "A gentle meditation to help you fall asleep faster and enjoy deeper sleep through progressive relaxation.",
      category: "sleep",
      duration: 15,
      voiceActivated: true,
      backgroundSound: "gentle_waves",
      icon: <Moon className="h-5 w-5" />,
      favorited: true,
      completions: 5
    },
    {
      id: "morning-energy",
      title: "Morning Energy Boost",
      description: "Start your day with positive energy and mindful intention setting in this uplifting morning practice.",
      category: "energy",
      duration: 8,
      voiceActivated: true,
      backgroundSound: "morning_birds",
      icon: <Sun className="h-5 w-5" />,
      favorited: false,
      completions: 2
    },
    {
      id: "stress-release",
      title: "Stress Release",
      description: "Let go of tension and anxiety with this guided breath-focused meditation designed for stress relief.",
      category: "stress",
      duration: 12,
      voiceActivated: true,
      backgroundSound: "gentle_rain",
      icon: <Wind className="h-5 w-5" />,
      favorited: true,
      completions: 8
    },
    {
      id: "focus-flow",
      title: "Focus Flow",
      description: "Enhance your concentration and mental clarity with this meditation designed for improved focus.",
      category: "focus",
      duration: 10,
      voiceActivated: true,
      backgroundSound: "light_ambient",
      icon: <Sparkles className="h-5 w-5" />,
      favorited: false,
      completions: 0
    },
    {
      id: "mindful-awareness",
      title: "Mindful Awareness",
      description: "Develop present moment awareness and acceptance with this classic mindfulness meditation practice.",
      category: "mindfulness",
      duration: 20,
      voiceActivated: true,
      backgroundSound: "soft_chimes",
      icon: <Feather className="h-5 w-5" />,
      favorited: false,
      completions: 3
    }
  ];
  
  // Start meditation playback
  const startMeditation = (meditation: Meditation) => {
    setCurrentMeditation(meditation);
    setCurrentProgress(0);
    setIsPlaying(true);
    
    toast({
      title: `Starting ${meditation.title}`,
      description: "Find a comfortable position and relax...",
    });
    
    // Simulate progress of the meditation
    if (progressRef.current) {
      clearInterval(progressRef.current);
    }
    
    const totalSeconds = meditation.duration * 60;
    let elapsed = 0;
    
    progressRef.current = setInterval(() => {
      elapsed += 1;
      const progress = Math.min((elapsed / totalSeconds) * 100, 100);
      setCurrentProgress(progress);
      
      if (progress >= 100) {
        if (progressRef.current) {
          clearInterval(progressRef.current);
        }
        setIsPlaying(false);
        
        toast({
          title: "Meditation complete",
          description: "We hope you enjoyed your session.",
        });
      }
    }, 1000);
  };
  
  // Pause or resume meditation
  const togglePlayPause = () => {
    if (isPlaying) {
      // Pause meditation
      if (progressRef.current) {
        clearInterval(progressRef.current);
      }
      setIsPlaying(false);
      
      toast({
        title: "Meditation paused",
        description: "Take your time, resume when ready.",
      });
    } else if (currentMeditation) {
      // Resume meditation
      setIsPlaying(true);
      
      const totalSeconds = currentMeditation.duration * 60;
      const elapsedSeconds = (currentProgress / 100) * totalSeconds;
      let elapsed = elapsedSeconds;
      
      progressRef.current = setInterval(() => {
        elapsed += 1;
        const progress = Math.min((elapsed / totalSeconds) * 100, 100);
        setCurrentProgress(progress);
        
        if (progress >= 100) {
          if (progressRef.current) {
            clearInterval(progressRef.current);
          }
          setIsPlaying(false);
          
          toast({
            title: "Meditation complete",
            description: "We hope you enjoyed your session.",
          });
        }
      }, 1000);
      
      toast({
        title: "Meditation resumed",
        description: "Continuing your session...",
      });
    }
  };
  
  // End meditation session
  const endMeditation = () => {
    if (progressRef.current) {
      clearInterval(progressRef.current);
    }
    setIsPlaying(false);
    setCurrentMeditation(null);
    setCurrentProgress(0);
    
    toast({
      title: "Meditation ended",
      description: "Your session has been ended.",
    });
  };
  
  // Handle voice activation
  const toggleVoiceActivation = () => {
    setIsVoiceListening(!isVoiceListening);
    
    if (!isVoiceListening) {
      // Starting voice listening
      setVoiceCommands([]);
      
      toast({
        title: "Voice commands activated",
        description: "Try saying 'start', 'pause', 'resume', or 'stop'",
      });
      
      // Simulate voice recognition after a delay
      setTimeout(() => {
        if (currentMeditation && !isPlaying) {
          simulateVoiceCommand("start");
        } else if (isPlaying) {
          simulateVoiceCommand("pause");
        }
      }, 3000);
    } else {
      // Stopping voice listening
      toast({
        title: "Voice commands deactivated",
        description: "Switching to manual control.",
      });
    }
  };
  
  // Simulate voice command processing
  const simulateVoiceCommand = (command: string) => {
    setVoiceCommands(prev => [...prev, command]);
    
    setTimeout(() => {
      switch (command.toLowerCase()) {
        case "start":
          if (currentMeditation && !isPlaying) {
            setIsPlaying(true);
            
            const totalSeconds = currentMeditation.duration * 60;
            const elapsedSeconds = (currentProgress / 100) * totalSeconds;
            let elapsed = elapsedSeconds;
            
            if (progressRef.current) {
              clearInterval(progressRef.current);
            }
            
            progressRef.current = setInterval(() => {
              elapsed += 1;
              const progress = Math.min((elapsed / totalSeconds) * 100, 100);
              setCurrentProgress(progress);
              
              if (progress >= 100) {
                if (progressRef.current) {
                  clearInterval(progressRef.current);
                }
                setIsPlaying(false);
              }
            }, 1000);
            
            toast({
              title: "Voice command: Start",
              description: "Starting meditation...",
            });
          }
          break;
          
        case "pause":
          if (isPlaying) {
            if (progressRef.current) {
              clearInterval(progressRef.current);
            }
            setIsPlaying(false);
            
            toast({
              title: "Voice command: Pause",
              description: "Pausing meditation...",
            });
          }
          break;
          
        case "resume":
          if (currentMeditation && !isPlaying) {
            setIsPlaying(true);
            
            const totalSeconds = currentMeditation.duration * 60;
            const elapsedSeconds = (currentProgress / 100) * totalSeconds;
            let elapsed = elapsedSeconds;
            
            if (progressRef.current) {
              clearInterval(progressRef.current);
            }
            
            progressRef.current = setInterval(() => {
              elapsed += 1;
              const progress = Math.min((elapsed / totalSeconds) * 100, 100);
              setCurrentProgress(progress);
              
              if (progress >= 100) {
                if (progressRef.current) {
                  clearInterval(progressRef.current);
                }
                setIsPlaying(false);
              }
            }, 1000);
            
            toast({
              title: "Voice command: Resume",
              description: "Resuming meditation...",
            });
          }
          break;
          
        case "stop":
          if (currentMeditation) {
            if (progressRef.current) {
              clearInterval(progressRef.current);
            }
            setIsPlaying(false);
            setCurrentMeditation(null);
            setCurrentProgress(0);
            
            toast({
              title: "Voice command: Stop",
              description: "Stopping meditation...",
            });
          }
          break;
          
        default:
          toast({
            title: "Voice command not recognized",
            description: "Try saying 'start', 'pause', 'resume', or 'stop'",
            variant: "destructive",
          });
      }
    }, 500);
  };
  
  // Format time from seconds
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Calculate time elapsed and remaining
  const getTimeInfo = () => {
    if (!currentMeditation) return { elapsed: "0:00", remaining: "0:00" };
    
    const totalSeconds = currentMeditation.duration * 60;
    const elapsedSeconds = (currentProgress / 100) * totalSeconds;
    const remainingSeconds = totalSeconds - elapsedSeconds;
    
    return {
      elapsed: formatTime(elapsedSeconds),
      remaining: formatTime(remainingSeconds)
    };
  };
  
  // Clean up interval on unmount
  useEffect(() => {
    return () => {
      if (progressRef.current) {
        clearInterval(progressRef.current);
      }
    };
  }, []);
  
  // Get category badge color
  const getCategoryColor = (category: Meditation["category"]) => {
    switch (category) {
      case "sleep":
        return "bg-indigo-100 text-indigo-800 border-indigo-200";
      case "focus":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "stress":
        return "bg-green-100 text-green-800 border-green-200";
      case "mindfulness":
        return "bg-purple-100 text-purple-800 border-purple-200";
      case "energy":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
    }
  };
  
  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col items-center mb-8">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold text-center bg-gradient-to-r from-purple-600 to-indigo-500 text-transparent bg-clip-text">
            Voice-Guided Meditation
          </h1>
        </motion.div>
        <p className="text-gray-600 mt-2 text-center max-w-2xl">
          Enhance your mindfulness practice with our voice-activated guided meditations for stress reduction and mental clarity.
        </p>
      </div>
      
      {currentMeditation ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="max-w-4xl mx-auto">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl">{currentMeditation.title}</CardTitle>
                  <CardDescription className="mt-1">
                    {currentMeditation.description}
                  </CardDescription>
                </div>
                <Badge variant="outline" className={`${getCategoryColor(currentMeditation.category)}`}>
                  {currentMeditation.category.charAt(0).toUpperCase() + currentMeditation.category.slice(1)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="bg-gradient-to-r from-purple-100 to-indigo-100 rounded-lg p-8 flex flex-col items-center justify-center">
                <div className="w-24 h-24 rounded-full bg-white shadow-md flex items-center justify-center mb-4">
                  <motion.div
                    animate={isPlaying ? { 
                      scale: [1, 1.1, 1],
                      opacity: [1, 0.8, 1] 
                    } : {}}
                    transition={{ repeat: Infinity, duration: 2 }}
                  >
                    {currentMeditation.icon}
                  </motion.div>
                </div>
                
                <div className="text-center mb-2">
                  <p className="text-sm text-gray-500">
                    {isPlaying ? "Currently playing..." : "Paused"}
                  </p>
                  <p className="text-lg font-medium">
                    {isVoiceListening ? "Voice control active" : "Manual control"}
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span>{getTimeInfo().elapsed}</span>
                  <span>{getTimeInfo().remaining}</span>
                </div>
                <Progress value={currentProgress} className="h-2" />
              </div>
              
              <div className="flex items-center justify-center space-x-4">
                <Button variant="outline" size="icon">
                  <SkipBack className="h-4 w-4" />
                </Button>
                
                <Button 
                  size="icon" 
                  variant="default"
                  className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-600 to-indigo-500 hover:from-purple-700 hover:to-indigo-600"
                  onClick={togglePlayPause}
                >
                  {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
                </Button>
                
                <Button variant="outline" size="icon">
                  <SkipForward className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="flex items-center space-x-3">
                <Volume2 className="h-5 w-5 text-gray-500" />
                <Slider
                  value={[volume]}
                  max={100}
                  step={1}
                  onValueChange={(value) => setVolume(value[0])}
                  className="flex-1"
                />
              </div>
              
              {currentMeditation.voiceActivated && (
                <div className="pt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Button 
                        variant={isVoiceListening ? "default" : "outline"}
                        className={isVoiceListening ? "bg-gradient-to-r from-purple-600 to-indigo-500" : ""}
                        onClick={toggleVoiceActivation}
                      >
                        <Mic className="h-4 w-4 mr-2" />
                        {isVoiceListening ? "Voice Activated" : "Enable Voice Control"}
                      </Button>
                    </div>
                    
                    {isVoiceListening && voiceCommands.length > 0 && (
                      <div className="text-sm text-gray-500">
                        Last command: <span className="font-medium">{voiceCommands[voiceCommands.length - 1]}</span>
                      </div>
                    )}
                  </div>
                  
                  {isVoiceListening && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      transition={{ duration: 0.3 }}
                      className="mt-3 p-3 bg-gray-50 rounded-md"
                    >
                      <p className="text-sm font-medium mb-1">Voice Commands:</p>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>"Start" - Begin meditation</li>
                        <li>"Pause" - Pause meditation</li>
                        <li>"Resume" - Continue meditation</li>
                        <li>"Stop" - End session</li>
                      </ul>
                    </motion.div>
                  )}
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button 
                variant="outline"
                className="w-full"
                onClick={endMeditation}
              >
                End Session
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      ) : (
        <>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-4 max-w-lg mx-auto mb-8">
              <TabsTrigger value="featured">Featured</TabsTrigger>
              <TabsTrigger value="sleep">Sleep</TabsTrigger>
              <TabsTrigger value="focus">Focus</TabsTrigger>
              <TabsTrigger value="stress">Stress</TabsTrigger>
            </TabsList>
            
            <TabsContent value="featured">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {meditations.map((meditation, index) => (
                  <motion.div
                    key={meditation.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <Card className="h-full flex flex-col">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center space-x-2">
                            <div className="p-2 rounded-full bg-purple-100 text-purple-600">
                              {meditation.icon}
                            </div>
                            <CardTitle className="text-lg">{meditation.title}</CardTitle>
                          </div>
                          <Badge variant="outline" className={`${getCategoryColor(meditation.category)}`}>
                            {meditation.category.charAt(0).toUpperCase() + meditation.category.slice(1)}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-0 flex-grow">
                        <p className="text-gray-600 mb-4">{meditation.description}</p>
                        <div className="flex items-center justify-between text-sm text-gray-500">
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            <span>{meditation.duration} min</span>
                          </div>
                          {meditation.voiceActivated && (
                            <div className="flex items-center">
                              <Mic className="h-4 w-4 mr-1" />
                              <span>Voice enabled</span>
                            </div>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter className="pt-4">
                        <Button 
                          className="w-full bg-gradient-to-r from-purple-600 to-indigo-500 hover:from-purple-700 hover:to-indigo-600"
                          onClick={() => startMeditation(meditation)}
                        >
                          Start Meditation
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="sleep">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {meditations
                  .filter(med => med.category === "sleep")
                  .map((meditation, index) => (
                    <motion.div
                      key={meditation.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Card className="h-full flex flex-col">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center space-x-2">
                              <div className="p-2 rounded-full bg-purple-100 text-purple-600">
                                {meditation.icon}
                              </div>
                              <CardTitle className="text-lg">{meditation.title}</CardTitle>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-0 flex-grow">
                          <p className="text-gray-600 mb-4">{meditation.description}</p>
                          <div className="flex items-center justify-between text-sm text-gray-500">
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              <span>{meditation.duration} min</span>
                            </div>
                            {meditation.voiceActivated && (
                              <div className="flex items-center">
                                <Mic className="h-4 w-4 mr-1" />
                                <span>Voice enabled</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                        <CardFooter className="pt-4">
                          <Button 
                            className="w-full bg-gradient-to-r from-purple-600 to-indigo-500 hover:from-purple-700 hover:to-indigo-600"
                            onClick={() => startMeditation(meditation)}
                          >
                            Start Meditation
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                ))}
                
                {meditations.filter(med => med.category === "sleep").length === 0 && (
                  <div className="col-span-full text-center py-10">
                    <Moon className="h-10 w-10 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No sleep meditations found</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="focus">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {meditations
                  .filter(med => med.category === "focus")
                  .map((meditation, index) => (
                    <motion.div
                      key={meditation.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Card className="h-full flex flex-col">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center space-x-2">
                              <div className="p-2 rounded-full bg-purple-100 text-purple-600">
                                {meditation.icon}
                              </div>
                              <CardTitle className="text-lg">{meditation.title}</CardTitle>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-0 flex-grow">
                          <p className="text-gray-600 mb-4">{meditation.description}</p>
                          <div className="flex items-center justify-between text-sm text-gray-500">
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              <span>{meditation.duration} min</span>
                            </div>
                            {meditation.voiceActivated && (
                              <div className="flex items-center">
                                <Mic className="h-4 w-4 mr-1" />
                                <span>Voice enabled</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                        <CardFooter className="pt-4">
                          <Button 
                            className="w-full bg-gradient-to-r from-purple-600 to-indigo-500 hover:from-purple-700 hover:to-indigo-600"
                            onClick={() => startMeditation(meditation)}
                          >
                            Start Meditation
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                ))}
                
                {meditations.filter(med => med.category === "focus").length === 0 && (
                  <div className="col-span-full text-center py-10">
                    <Sparkles className="h-10 w-10 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No focus meditations found</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="stress">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {meditations
                  .filter(med => med.category === "stress")
                  .map((meditation, index) => (
                    <motion.div
                      key={meditation.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Card className="h-full flex flex-col">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center space-x-2">
                              <div className="p-2 rounded-full bg-purple-100 text-purple-600">
                                {meditation.icon}
                              </div>
                              <CardTitle className="text-lg">{meditation.title}</CardTitle>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-0 flex-grow">
                          <p className="text-gray-600 mb-4">{meditation.description}</p>
                          <div className="flex items-center justify-between text-sm text-gray-500">
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              <span>{meditation.duration} min</span>
                            </div>
                            {meditation.voiceActivated && (
                              <div className="flex items-center">
                                <Mic className="h-4 w-4 mr-1" />
                                <span>Voice enabled</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                        <CardFooter className="pt-4">
                          <Button 
                            className="w-full bg-gradient-to-r from-purple-600 to-indigo-500 hover:from-purple-700 hover:to-indigo-600"
                            onClick={() => startMeditation(meditation)}
                          >
                            Start Meditation
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                ))}
                
                {meditations.filter(med => med.category === "stress").length === 0 && (
                  <div className="col-span-full text-center py-10">
                    <Wind className="h-10 w-10 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No stress meditations found</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="mt-12">
            <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 border-none">
              <CardHeader>
                <div className="flex justify-center mb-4">
                  <Headphones className="h-12 w-12 text-purple-600" />
                </div>
                <CardTitle className="text-xl text-center">Your Meditation Journey</CardTitle>
                <CardDescription className="text-center">
                  Start your practice today and track your mindfulness progress over time
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <div className="grid grid-cols-3 gap-8 text-center">
                  <div>
                    <div className="text-2xl font-bold text-purple-600 mb-1">0</div>
                    <p className="text-sm text-gray-600">Streak Days</p>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-indigo-600 mb-1">0</div>
                    <p className="text-sm text-gray-600">Minutes Meditated</p>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-600 mb-1">0</div>
                    <p className="text-sm text-gray-600">Sessions Completed</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center pb-6">
                <Button
                  variant="outline"
                  className="border-purple-200 text-purple-700 hover:bg-purple-50"
                >
                  View Progress
                </Button>
              </CardFooter>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}