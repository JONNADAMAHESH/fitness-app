import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Grid, ChevronRight, Filter, Search, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const Explore = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch all content
  const { data: workouts, isLoading: isLoadingWorkouts } = useQuery({
    queryKey: ["/api/workouts"],
  });

  const { data: nutritionPlans, isLoading: isLoadingNutrition } = useQuery({
    queryKey: ["/api/nutrition-plans"],
  });

  const { data: yogaRoutines, isLoading: isLoadingYoga } = useQuery({
    queryKey: ["/api/yoga-routines"],
  });

  const { data: healthTips, isLoading: isLoadingHealth } = useQuery({
    queryKey: ["/api/health-tips"],
  });

  const { data: coaches, isLoading: isLoadingCoaches } = useQuery({
    queryKey: ["/api/coaches"],
  });

  // Categories for filtering
  const categories = [
    { id: "beginner", label: "Beginner" },
    { id: "intermediate", label: "Intermediate" },
    { id: "advanced", label: "Advanced" },
    { id: "weightLoss", label: "Weight Loss" },
    { id: "muscleGain", label: "Muscle Gain" },
    { id: "18-35", label: "Age 18-35" },
    { id: "35-90", label: "Age 35-90" },
    { id: "yoga", label: "Yoga" },
    { id: "nutrition", label: "Nutrition" },
    { id: "sleep", label: "Sleep" },
    { id: "stress", label: "Stress Relief" },
  ];

  // Featured content
  const featuredContent = [
    {
      id: 1,
      type: "article",
      title: "How Vitamin D Affects Your Fitness",
      category: "nutrition",
      imageUrl: "https://images.unsplash.com/photo-1535083252457-6eab4a9db4c6",
      description: "Learn about the crucial role vitamin D plays in muscle strength, bone health, and overall fitness performance.",
      ageGroup: "35-90",
    },
    {
      id: 2,
      type: "workout",
      title: "Full Body HIIT for Beginners",
      category: "beginner",
      imageUrl: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438",
      description: "A high-intensity interval training workout designed specifically for beginners to improve cardiovascular health and strength.",
      ageGroup: "18-35",
    },
    {
      id: 3,
      type: "nutrition",
      title: "Calcium-Rich Diet Guide",
      category: "nutrition",
      imageUrl: "https://images.unsplash.com/photo-1498837167922-ddd27525d352",
      description: "Discover calcium-rich foods and how to incorporate them into your daily diet for better bone health, especially important for ages 35+.",
      ageGroup: "35-90",
    },
    {
      id: 4,
      type: "yoga",
      title: "Stress-Relief Yoga Flow",
      category: "yoga",
      imageUrl: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b",
      description: "A calming yoga sequence designed to reduce stress and anxiety while improving flexibility and mindfulness.",
      ageGroup: "all",
    },
    {
      id: 5,
      type: "article",
      title: "The Science of Sleep and Fitness",
      category: "sleep",
      imageUrl: "https://images.unsplash.com/photo-1445384763658-0400939829cd",
      description: "Understand how sleep affects your workout recovery, muscle growth, and overall fitness progress.",
      ageGroup: "all",
    },
    {
      id: 6,
      type: "workout",
      title: "Joint-Friendly Strength Training",
      category: "intermediate",
      imageUrl: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd",
      description: "A specialized strength training program designed to build muscle while protecting your joints, ideal for ages 35 and up.",
      ageGroup: "35-90",
    },
  ];

  // Filter content based on search query and active tab
  const filteredContent = featuredContent.filter(item => {
    // Filter by search query
    if (searchQuery && !item.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !item.description.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Filter by tab
    if (activeTab !== "all" && item.type !== activeTab) {
      return false;
    }
    
    return true;
  });

  return (
    <div className="container mx-auto px-4 py-6 mb-16 md:mb-0">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Explore</h2>
      </div>

      <div className="relative mb-6">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <Input
          className="pl-10"
          placeholder="Search workouts, nutrition, yoga, and more..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="flex justify-between items-center mb-4">
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="workout">Workouts</TabsTrigger>
            <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
            <TabsTrigger value="yoga">Yoga</TabsTrigger>
            <TabsTrigger value="article">Articles</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="md:col-span-2">
          <h3 className="text-lg font-semibold mb-4">Featured Content</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredContent.length > 0 ? (
              filteredContent.map((item) => (
                <Card key={item.id} className="overflow-hidden">
                  <div className="h-40 relative">
                    <img 
                      src={item.imageUrl} 
                      alt={item.title} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-white text-primary">
                        {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold">{item.title}</h4>
                    </div>
                    <div className="mb-3 flex">
                      <Badge variant="outline" className="mr-2">{item.category}</Badge>
                      <Badge variant="outline">{item.ageGroup}</Badge>
                    </div>
                    <p className="text-gray-500 text-sm mb-4 line-clamp-2">{item.description}</p>
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-primary flex items-center"
                      onClick={() => {
                        toast({
                          title: "Content Selected",
                          description: `You've selected ${item.title}`,
                        });
                      }}
                    >
                      View Details
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-2 text-center py-10 bg-white rounded-xl shadow-sm">
                <Grid className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No content found</h3>
                <p className="text-gray-500">Try adjusting your search or filters</p>
              </div>
            )}
          </div>
        </div>

        <div>
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-4">Browse by Category</h3>
              
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="fitness-level">
                  <AccordionTrigger className="text-sm">Fitness Level</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {["beginner", "intermediate", "advanced"].map(category => (
                        <div 
                          key={category} 
                          className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-md"
                          onClick={() => {
                            setSearchQuery("");
                            setActiveTab("all");
                            toast({
                              title: "Category Selected",
                              description: `Showing content for ${category} level`,
                            });
                          }}
                        >
                          <Tag className="h-4 w-4 mr-2 text-gray-500" />
                          <span className="text-sm capitalize">{category}</span>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="goals">
                  <AccordionTrigger className="text-sm">Goals</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {["weightLoss", "muscleGain", "stress"].map(category => (
                        <div 
                          key={category} 
                          className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-md"
                          onClick={() => {
                            setSearchQuery("");
                            setActiveTab("all");
                            toast({
                              title: "Category Selected",
                              description: `Showing content for ${category.replace(/([A-Z])/g, ' $1').toLowerCase()} goal`,
                            });
                          }}
                        >
                          <Tag className="h-4 w-4 mr-2 text-gray-500" />
                          <span className="text-sm">{category.replace(/([A-Z])/g, ' $1').trim()}</span>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="age-group">
                  <AccordionTrigger className="text-sm">Age Group</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {["18-35", "35-90"].map(category => (
                        <div 
                          key={category} 
                          className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-md"
                          onClick={() => {
                            setSearchQuery("");
                            setActiveTab("all");
                            toast({
                              title: "Age Group Selected",
                              description: `Showing content for ages ${category}`,
                            });
                          }}
                        >
                          <Tag className="h-4 w-4 mr-2 text-gray-500" />
                          <span className="text-sm">Age {category}</span>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="content-type">
                  <AccordionTrigger className="text-sm">Content Type</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {["yoga", "nutrition", "sleep"].map(category => (
                        <div 
                          key={category} 
                          className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-md"
                          onClick={() => {
                            setSearchQuery("");
                            setActiveTab(category === "sleep" ? "article" : category);
                            toast({
                              title: "Content Type Selected",
                              description: `Showing ${category} content`,
                            });
                          }}
                        >
                          <Tag className="h-4 w-4 mr-2 text-gray-500" />
                          <span className="text-sm capitalize">{category}</span>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
              
              <div className="mt-6 space-y-4">
                <h3 className="font-semibold text-lg">Quick Links</h3>
                <div className="space-y-2">
                  <Link href="/workout">
                    <div className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-md">
                      <ChevronRight className="h-4 w-4 mr-2 text-primary" />
                      <span className="text-sm text-primary">All Workouts</span>
                    </div>
                  </Link>
                  <Link href="/nutrition">
                    <div className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-md">
                      <ChevronRight className="h-4 w-4 mr-2 text-primary" />
                      <span className="text-sm text-primary">Nutrition Plans</span>
                    </div>
                  </Link>
                  <Link href="/yoga">
                    <div className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-md">
                      <ChevronRight className="h-4 w-4 mr-2 text-primary" />
                      <span className="text-sm text-primary">Yoga & Mindfulness</span>
                    </div>
                  </Link>
                  <Link href="/sleep">
                    <div className="flex items-center cursor-pointer p-2 hover:bg-gray-50 rounded-md">
                      <ChevronRight className="h-4 w-4 mr-2 text-primary" />
                      <span className="text-sm text-primary">Sleep Tracking</span>
                    </div>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <h3 className="text-lg font-semibold mb-4">Trending Content</h3>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="overflow-hidden">
          <div className="h-40 relative">
            <img 
              src="https://images.unsplash.com/photo-1552196563-55cd4e45efb3" 
              alt="Eye Strain Relief" 
              className="w-full h-full object-cover"
            />
          </div>
          <CardContent className="p-4">
            <Badge className="mb-2">Hand & Eye Health</Badge>
            <h4 className="font-semibold mb-2">Eye Strain Relief Exercises</h4>
            <p className="text-gray-500 text-sm line-clamp-2">Simple exercises to reduce digital eye strain for those who spend hours looking at screens.</p>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-40 relative">
            <img 
              src="https://images.unsplash.com/photo-1616279969963-0e342b64c59c" 
              alt="Knee Health" 
              className="w-full h-full object-cover"
            />
          </div>
          <CardContent className="p-4">
            <Badge className="mb-2">Joint Care</Badge>
            <h4 className="font-semibold mb-2">Knee Strengthening Program</h4>
            <p className="text-gray-500 text-sm line-clamp-2">Targeted exercises to build knee stability and reduce pain for all ages.</p>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-40 relative">
            <img 
              src="https://images.unsplash.com/photo-1521804906057-1df8fdb718b7" 
              alt="Neck Pain Relief" 
              className="w-full h-full object-cover"
            />
          </div>
          <CardContent className="p-4">
            <Badge className="mb-2">Neck Health</Badge>
            <h4 className="font-semibold mb-2">Neck Tension Relief Guide</h4>
            <p className="text-gray-500 text-sm line-clamp-2">Exercises and stretches to alleviate neck pain from poor posture and desk work.</p>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-40 relative">
            <img 
              src="https://images.unsplash.com/photo-1518611012118-696072aa579a" 
              alt="Stress Management" 
              className="w-full h-full object-cover"
            />
          </div>
          <CardContent className="p-4">
            <Badge className="mb-2">Stress Relief</Badge>
            <h4 className="font-semibold mb-2">10-Minute Stress Busters</h4>
            <p className="text-gray-500 text-sm line-clamp-2">Quick and effective techniques to manage stress throughout your busy day.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Explore;
