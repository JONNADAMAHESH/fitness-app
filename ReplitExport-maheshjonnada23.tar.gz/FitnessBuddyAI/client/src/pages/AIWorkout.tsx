import { useState } from "react";
import { AIWorkoutGenerator } from "@/components/ai/AIWorkoutGenerator";
import { AIWorkoutDisplay } from "@/components/ai/AIWorkoutDisplay";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";

// Types for our workout data
interface WorkoutExercise {
  name: string;
  sets: number;
  reps: number;
  restTime: number;
  instructions: string;
}

interface AIWorkoutPlan {
  name: string;
  description: string;
  difficulty: string;
  targetBodyParts: string[];
  exercises: WorkoutExercise[];
  duration: number;
  calories: number;
  ageGroup: string;
}

export default function AIWorkoutPage() {
  const { toast } = useToast();
  const [generatedWorkout, setGeneratedWorkout] = useState<AIWorkoutPlan | null>(null);
  const [activeTab, setActiveTab] = useState<string>("generator");

  const saveWorkoutMutation = useMutation({
    mutationFn: async (workout: AIWorkoutPlan) => {
      const response = await apiRequest("POST", "/api/workouts", {
        name: workout.name,
        description: workout.description,
        difficulty: workout.difficulty,
        targetBodyParts: workout.targetBodyParts,
        exercises: workout.exercises.map(ex => ({
          name: ex.name,
          sets: ex.sets,
          reps: ex.reps,
          restTime: ex.restTime,
          instructions: ex.instructions
        })),
        duration: workout.duration,
        estimatedCalories: workout.calories,
        ageGroup: workout.ageGroup
      });
      
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Workout saved successfully!",
        description: "You can find this workout in your saved workouts",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to save workout",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleWorkoutGenerated = (workout: AIWorkoutPlan) => {
    setGeneratedWorkout(workout);
    setActiveTab("result");
  };

  const handleSaveWorkout = () => {
    if (generatedWorkout) {
      saveWorkoutMutation.mutate(generatedWorkout);
    }
  };

  const handleRegenerate = () => {
    setActiveTab("generator");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          AI Workout Creator
        </h1>
        <p className="text-gray-600 mt-2 max-w-2xl mx-auto">
          Let our AI create a personalized workout plan tailored to your specific needs, 
          fitness level, and goals. Just provide a few details and get a complete workout routine instantly.
        </p>
      </motion.div>

      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full max-w-4xl mx-auto"
      >
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="generator">Create Workout</TabsTrigger>
          <TabsTrigger value="result" disabled={!generatedWorkout}>
            View Result
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generator" className="mt-0">
          <AIWorkoutGenerator onWorkoutGenerated={handleWorkoutGenerated} />
        </TabsContent>

        <TabsContent value="result" className="mt-0">
          {generatedWorkout && (
            <AIWorkoutDisplay
              workout={generatedWorkout}
              onSave={handleSaveWorkout}
              onRegenerate={handleRegenerate}
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}