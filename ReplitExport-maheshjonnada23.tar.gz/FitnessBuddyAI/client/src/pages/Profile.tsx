import { useState } from "react";
import { User, Settings, BarChart2, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { calculateBMI, calculateCalorieNeeds, fitnessLevels, fitnessGoals } from "@/lib/utils";

const Profile = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");

  // Mock user data (would come from API)
  const [userData, setUserData] = useState({
    name: "John Doe",
    age: 32,
    gender: "male",
    height: 178,
    weight: 75,
    fitnessLevel: "intermediate",
    fitnessGoals: ["gain_muscle", "improve_fitness"],
  });

  const handleUpdateProfile = () => {
    toast({
      title: "Profile Updated",
      description: "Your profile information has been updated",
    });
  };

  const bmi = calculateBMI(userData.weight, userData.height);
  const bmiCategory = () => {
    if (bmi < 18.5) return "Underweight";
    if (bmi < 25) return "Normal weight";
    if (bmi < 30) return "Overweight";
    return "Obese";
  };

  const dailyCalories = calculateCalorieNeeds(
    userData.weight,
    userData.height,
    userData.age,
    userData.gender as "male" | "female",
    "moderate"
  );

  return (
    <div className="container mx-auto px-4 py-6 mb-16 md:mb-0">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Profile</h2>
      </div>

      <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 w-full mb-6">
          <TabsTrigger value="profile" className="flex items-center">
            <User className="h-4 w-4 mr-2" />
            <span>Profile</span>
          </TabsTrigger>
          <TabsTrigger value="stats" className="flex items-center">
            <BarChart2 className="h-4 w-4 mr-2" />
            <span>Stats</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center">
            <Settings className="h-4 w-4 mr-2" />
            <span>Settings</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Name</label>
                    <Input 
                      value={userData.name} 
                      onChange={(e) => setUserData({...userData, name: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Age</label>
                    <Input 
                      type="number" 
                      value={userData.age} 
                      onChange={(e) => setUserData({...userData, age: parseInt(e.target.value)})}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Gender</label>
                    <Select 
                      value={userData.gender} 
                      onValueChange={(value) => setUserData({...userData, gender: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Height (cm)</label>
                    <Input 
                      type="number" 
                      value={userData.height} 
                      onChange={(e) => setUserData({...userData, height: parseInt(e.target.value)})}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Weight (kg)</label>
                    <Input 
                      type="number" 
                      value={userData.weight} 
                      onChange={(e) => setUserData({...userData, weight: parseInt(e.target.value)})}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Fitness Level</label>
                    <Select 
                      value={userData.fitnessLevel} 
                      onValueChange={(value) => setUserData({...userData, fitnessLevel: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select fitness level" />
                      </SelectTrigger>
                      <SelectContent>
                        {fitnessLevels.map(level => (
                          <SelectItem key={level.value} value={level.value}>
                            {level.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button className="w-full" onClick={handleUpdateProfile}>
                  Update Profile
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Body Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">BMI</span>
                      <span className="font-semibold">{bmi}</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div 
                        className={`h-2 rounded-full ${
                          bmi < 18.5 ? "bg-yellow-400" : 
                          bmi < 25 ? "bg-green-400" : 
                          bmi < 30 ? "bg-orange-400" : "bg-red-400"
                        }`} 
                        style={{ width: `${Math.min(100, (bmi / 40) * 100)}%` }}
                      ></div>
                    </div>
                    <p className="text-xs mt-2 text-gray-500">Category: {bmiCategory()}</p>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">Daily Calorie Needs</span>
                      <span className="font-semibold">{dailyCalories} cal</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs text-gray-500 mt-2">
                      <div>
                        <p className="font-medium">Weight Loss</p>
                        <p>{dailyCalories - 500} cal</p>
                      </div>
                      <div>
                        <p className="font-medium">Maintenance</p>
                        <p>{dailyCalories} cal</p>
                      </div>
                      <div>
                        <p className="font-medium">Weight Gain</p>
                        <p>{dailyCalories + 500} cal</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Progress Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">Workouts Completed</span>
                      <span className="font-semibold">24</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-primary" style={{ width: "60%" }}></div>
                    </div>
                    <p className="text-xs mt-2 text-gray-500">Last 30 days</p>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">Average Sleep</span>
                      <span className="font-semibold">7.2h</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-accent" style={{ width: "72%" }}></div>
                    </div>
                    <p className="text-xs mt-2 text-gray-500">Last 7 days</p>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">Daily Steps</span>
                      <span className="font-semibold">8,436</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-primary-light" style={{ width: "84%" }}></div>
                    </div>
                    <p className="text-xs mt-2 text-gray-500">Average over 30 days</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>App Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Notifications</p>
                    <p className="text-sm text-gray-500">Receive workout and progress reminders</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="notifications" className="rounded text-primary" defaultChecked />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Units</p>
                    <p className="text-sm text-gray-500">Set your preferred units of measurement</p>
                  </div>
                  <Select defaultValue="metric">
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Units" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="metric">Metric</SelectItem>
                      <SelectItem value="imperial">Imperial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Dark Mode</p>
                    <p className="text-sm text-gray-500">Switch between light and dark themes</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="darkMode" className="rounded text-primary" />
                  </div>
                </div>

                <div className="pt-4">
                  <Button variant="destructive" className="w-full">
                    Log Out
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Profile;
