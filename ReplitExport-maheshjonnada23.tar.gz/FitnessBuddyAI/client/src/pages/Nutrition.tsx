import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Apple, ChevronRight, Filter, Utensils } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const Nutrition = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("plans");
  const [selectedMeal, setSelectedMeal] = useState<any>(null);
  const [showMealModal, setShowMealModal] = useState(false);
  const [filters, setFilters] = useState({
    goal: "all",
    calories: "all",
    ageGroup: "all",
  });

  // Fetch nutrition plans
  const { data: nutritionPlans = [], isLoading: isLoadingPlans } = useQuery<any[]>({
    queryKey: ["/api/nutrition-plans"],
  });

  const handleViewMeal = (meal: any) => {
    setSelectedMeal(meal);
    setShowMealModal(true);
  };

  const handleStartPlan = (planId: number) => {
    toast({
      title: "Nutrition Plan Started",
      description: "Your nutrition plan has been added to your dashboard",
    });
  };

  const filteredPlans = nutritionPlans
    ? nutritionPlans.filter((plan: any) => {
        if (filters.goal !== "all" && plan.goal !== filters.goal) {
          return false;
        }
        if (filters.ageGroup !== "all" && plan.ageGroup !== filters.ageGroup) {
          return false;
        }
        if (filters.calories !== "all") {
          const calorieRange = filters.calories.split("-");
          const min = parseInt(calorieRange[0]);
          const max = parseInt(calorieRange[1]);
          if (plan.calories < min || plan.calories > max) {
            return false;
          }
        }
        return true;
      })
    : [];

  const goalOptions = [
    { value: "all", label: "All Goals" },
    { value: "weight_loss", label: "Weight Loss" },
    { value: "weight_gain", label: "Weight Gain" },
    { value: "maintenance", label: "Maintenance" },
    { value: "muscle_building", label: "Muscle Building" },
  ];

  const calorieOptions = [
    { value: "all", label: "All Calories" },
    { value: "1200-1500", label: "1200-1500 cal" },
    { value: "1500-1800", label: "1500-1800 cal" },
    { value: "1800-2200", label: "1800-2200 cal" },
    { value: "2200-2500", label: "2200-2500 cal" },
    { value: "2500-3000", label: "2500-3000 cal" },
  ];

  const ageGroupOptions = [
    { value: "all", label: "All Ages" },
    { value: "18-35", label: "18-35" },
    { value: "35-90", label: "35-90" },
  ];

  return (
    <div className="container mx-auto px-4 py-6 mb-16 md:mb-0">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Nutrition</h2>
        <Button
          variant="default"
          className="bg-gradient-to-r from-green-500 to-teal-600 text-white hover:from-green-600 hover:to-teal-700"
          onClick={() => window.location.href = "/ai-nutrition"}
        >
          <Utensils className="mr-2 h-4 w-4" />
          AI Nutrition Planner
        </Button>
      </div>

      <Tabs defaultValue="plans" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="plans">Meal Plans</TabsTrigger>
          <TabsTrigger value="tracking">Calorie Tracking</TabsTrigger>
          <TabsTrigger value="education">Nutrition Education</TabsTrigger>
        </TabsList>

        <TabsContent value="plans">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Nutrition Filters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Goal</label>
                  <Select 
                    value={filters.goal}
                    onValueChange={(value) => setFilters({...filters, goal: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Goals" />
                    </SelectTrigger>
                    <SelectContent>
                      {goalOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Calories</label>
                  <Select 
                    value={filters.calories}
                    onValueChange={(value) => setFilters({...filters, calories: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Calories" />
                    </SelectTrigger>
                    <SelectContent>
                      {calorieOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Age Group</label>
                  <Select 
                    value={filters.ageGroup}
                    onValueChange={(value) => setFilters({...filters, ageGroup: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Ages" />
                    </SelectTrigger>
                    <SelectContent>
                      {ageGroupOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {isLoadingPlans ? (
              Array(4).fill(0).map((_, i) => (
                <Card key={i}>
                  <Skeleton className="h-48 rounded-t-xl" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-2/3 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <Skeleton className="h-9 w-full" />
                  </CardContent>
                </Card>
              ))
            ) : filteredPlans && filteredPlans.length > 0 ? (
              filteredPlans.map((plan: any) => (
                <Card key={plan.id} className="overflow-hidden">
                  <div className="h-48 relative">
                    <img 
                      src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd" 
                      alt={plan.name} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-5">
                      <h3 className="text-white text-xl font-bold">{plan.name}</h3>
                      <p className="text-white text-sm opacity-90">
                        {plan.calories} cal · {plan.protein}g protein · {plan.carbs}g carbs · {plan.fat}g fat
                      </p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <p className="text-gray-500 text-sm mb-4">{plan.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {plan.meals && plan.meals.map((meal: any, idx: number) => (
                        <Button 
                          key={idx} 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleViewMeal(meal)}
                        >
                          {meal.name}
                        </Button>
                      ))}
                    </div>
                    <Button 
                      className="w-full" 
                      onClick={() => handleStartPlan(plan.id)}
                    >
                      Start Plan
                    </Button>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-2 text-center py-10">
                <Apple className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No nutrition plans found</h3>
                <p className="text-gray-500">Try adjusting your filters or create a custom plan</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="tracking">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Today's Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">Calories</span>
                      <span className="font-semibold">1,840 / 2,200</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-primary" style={{ width: "83.6%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">Protein</span>
                      <span className="font-semibold">95g / 150g</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-secondary" style={{ width: "63%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">Carbs</span>
                      <span className="font-semibold">180g / 220g</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-amber-400" style={{ width: "82%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">Fat</span>
                      <span className="font-semibold">60g / 70g</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-red-400" style={{ width: "86%" }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Meal Tracker</CardTitle>
                <Button size="sm">Add Meal</Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium mb-3">Breakfast</h4>
                    <div className="flex items-center p-3 bg-gray-50 rounded-lg mb-2">
                      <div className="bg-primary-light/10 rounded-lg h-10 w-10 flex items-center justify-center mr-3">
                        <Utensils className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <p className="font-medium">Oatmeal with berries</p>
                          <p className="text-sm text-gray-500">300 cal</p>
                        </div>
                        <p className="text-xs text-gray-500">10g protein · 45g carbs · 5g fat</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="text-primary">+ Add food</Button>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Lunch</h4>
                    <div className="flex items-center p-3 bg-gray-50 rounded-lg mb-2">
                      <div className="bg-primary-light/10 rounded-lg h-10 w-10 flex items-center justify-center mr-3">
                        <Utensils className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <p className="font-medium">Grilled chicken salad</p>
                          <p className="text-sm text-gray-500">400 cal</p>
                        </div>
                        <p className="text-xs text-gray-500">35g protein · 25g carbs · 15g fat</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="text-primary">+ Add food</Button>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Dinner</h4>
                    <Button variant="ghost" size="sm" className="text-primary">+ Add food</Button>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Snacks</h4>
                    <Button variant="ghost" size="sm" className="text-primary">+ Add food</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="education">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="overflow-hidden">
              <div className="h-48 relative">
                <img 
                  src="https://images.unsplash.com/photo-1498837167922-ddd27525d352" 
                  alt="Calcium-rich foods" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-5">
                  <h3 className="text-white text-xl font-bold">Calcium Essential Guide: Ages 35-90</h3>
                </div>
              </div>
              <CardContent className="p-4">
                <p className="text-gray-500 text-sm mb-4">
                  Learn about the importance of calcium for bone health as you age, and discover natural sources to maintain strong bones.
                </p>
                <Button>Read Guide</Button>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <div className="h-48 relative">
                <img 
                  src="https://images.unsplash.com/photo-1535083252457-6eab4a9db4c6" 
                  alt="Vitamin D sources" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-5">
                  <h3 className="text-white text-xl font-bold">Vitamin D: The Sunshine Nutrient</h3>
                </div>
              </div>
              <CardContent className="p-4">
                <p className="text-gray-500 text-sm mb-4">
                  Discover why Vitamin D is essential for health, how it affects calcium absorption, and natural ways to get enough.
                </p>
                <Button>Read Guide</Button>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <div className="h-48 relative">
                <img 
                  src="https://images.unsplash.com/photo-1567057419565-4349c49d8a04" 
                  alt="Bulking nutrition" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-5">
                  <h3 className="text-white text-xl font-bold">Bulking Phase: Nutrition Guide</h3>
                </div>
              </div>
              <CardContent className="p-4">
                <p className="text-gray-500 text-sm mb-4">
                  Learn how to gain muscle mass effectively with proper nutrition strategies for your bulking phase.
                </p>
                <Button>Read Guide</Button>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <div className="h-48 relative">
                <img 
                  src="https://images.unsplash.com/photo-1505576399279-565b52d4ac71" 
                  alt="Weight loss nutrition" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-5">
                  <h3 className="text-white text-xl font-bold">Cutting Phase: Nutrition Guide</h3>
                </div>
              </div>
              <CardContent className="p-4">
                <p className="text-gray-500 text-sm mb-4">
                  Understand the proper approach to cutting calories while maintaining muscle mass and energy levels.
                </p>
                <Button>Read Guide</Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={showMealModal} onOpenChange={setShowMealModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedMeal?.name}</DialogTitle>
            <DialogDescription>
              {selectedMeal && (
                <div className="mt-4 space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Nutritional Information</h4>
                    <div className="grid grid-cols-4 gap-2 text-center">
                      <div className="bg-gray-50 p-2 rounded">
                        <p className="text-xs text-gray-500">Calories</p>
                        <p className="font-medium">{selectedMeal.foods?.reduce((acc: number, food: any) => acc + food.calories, 0)} cal</p>
                      </div>
                      <div className="bg-gray-50 p-2 rounded">
                        <p className="text-xs text-gray-500">Protein</p>
                        <p className="font-medium">{selectedMeal.foods?.reduce((acc: number, food: any) => acc + food.protein, 0)}g</p>
                      </div>
                      <div className="bg-gray-50 p-2 rounded">
                        <p className="text-xs text-gray-500">Carbs</p>
                        <p className="font-medium">{selectedMeal.foods?.reduce((acc: number, food: any) => acc + food.carbs, 0)}g</p>
                      </div>
                      <div className="bg-gray-50 p-2 rounded">
                        <p className="text-xs text-gray-500">Fat</p>
                        <p className="font-medium">{selectedMeal.foods?.reduce((acc: number, food: any) => acc + food.fat, 0)}g</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Foods</h4>
                    {selectedMeal.foods?.map((food: any, idx: number) => (
                      <div key={idx} className="flex items-center p-3 bg-gray-50 rounded-lg mb-2">
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <p className="font-medium">{food.name}</p>
                            <p className="text-sm text-gray-500">{food.calories} cal</p>
                          </div>
                          <p className="text-xs text-gray-500">{food.protein}g protein · {food.carbs}g carbs · {food.fat}g fat</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Nutrition;
