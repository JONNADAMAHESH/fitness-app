import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Moon, ArrowUp, ArrowDown, Plus, BarChart2, Moon as MoonIcon, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const Sleep = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("tracking");
  const [showAddSleepModal, setShowAddSleepModal] = useState(false);
  const [newSleepData, setNewSleepData] = useState({
    date: new Date().toISOString().split("T")[0],
    duration: 7.5,
    quality: 3,
    notes: "",
  });

  // Fetch sleep data
  const { data: sleepData, isLoading: isLoadingSleepData } = useQuery({
    queryKey: ["/api/sleep-data/1"], // Using user ID 1 for demo
  });

  const handleAddSleep = () => {
    toast({
      title: "Sleep Data Added",
      description: "Your sleep data has been recorded",
    });
    setShowAddSleepModal(false);
  };

  // Mock sleep data for demonstration
  const sleepChartData = [
    { day: "Mon", hours: 7.2, quality: 3 },
    { day: "Tue", hours: 6.8, quality: 2 },
    { day: "Wed", hours: 7.5, quality: 4 },
    { day: "Thu", hours: 8.1, quality: 5 },
    { day: "Fri", hours: 7.0, quality: 3 },
    { day: "Sat", hours: 8.5, quality: 4 },
    { day: "Sun", hours: 7.3, quality: 3 },
  ];

  const sleepTips = [
    {
      title: "Maintain a Consistent Schedule",
      description: "Go to bed and wake up at the same time every day, including weekends.",
      icon: <Clock className="h-6 w-6 text-primary" />,
    },
    {
      title: "Create a Restful Environment",
      description: "Keep your bedroom cool, dark, and quiet for optimal sleep quality.",
      icon: <MoonIcon className="h-6 w-6 text-primary" />,
    },
    {
      title: "Limit Screen Time Before Bed",
      description: "Avoid screens (phone, computer, TV) for at least 30 minutes before sleeping.",
      icon: <BarChart2 className="h-6 w-6 text-primary" />,
    },
    {
      title: "Avoid Large Meals Before Bed",
      description: "Finish eating at least 2-3 hours before bedtime to prevent digestive issues.",
      icon: <Moon className="h-6 w-6 text-primary" />,
    },
  ];

  return (
    <div className="container mx-auto px-4 py-6 mb-16 md:mb-0">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Sleep & Recovery</h2>
        <Button size="sm" onClick={() => setShowAddSleepModal(true)}>
          <Plus className="h-4 w-4 mr-1" /> Log Sleep
        </Button>
      </div>

      <Tabs defaultValue="tracking" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="tracking">Sleep Tracking</TabsTrigger>
          <TabsTrigger value="insights">Sleep Insights</TabsTrigger>
          <TabsTrigger value="tips">Sleep Tips</TabsTrigger>
        </TabsList>

        <TabsContent value="tracking">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Sleep Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Average Sleep Duration</p>
                  <div className="flex items-center">
                    <span className="text-2xl font-bold">7.3</span>
                    <span className="text-sm text-gray-500 ml-1">hours</span>
                    <span className="ml-2 text-amber-500 flex items-center text-sm">
                      <ArrowDown className="h-4 w-4 mr-1" />
                      0.7h
                    </span>
                  </div>
                  <p className="text-xs text-gray-500">vs. recommended 8 hours</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Average Sleep Quality</p>
                  <div className="flex items-center">
                    <span className="text-2xl font-bold">3.4</span>
                    <span className="text-sm text-gray-500 ml-1">/ 5</span>
                    <span className="ml-2 text-green-500 flex items-center text-sm">
                      <ArrowUp className="h-4 w-4 mr-1" />
                      0.2
                    </span>
                  </div>
                  <p className="text-xs text-gray-500">vs. last week</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Sleep Debt</p>
                  <div className="flex items-center">
                    <span className="text-2xl font-bold">4.9</span>
                    <span className="text-sm text-gray-500 ml-1">hours</span>
                    <span className="ml-2 text-amber-500 flex items-center text-sm">
                      <ArrowUp className="h-4 w-4 mr-1" />
                      1.1h
                    </span>
                  </div>
                  <p className="text-xs text-gray-500">accumulated this week</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Weekly Sleep Pattern</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={sleepChartData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis yAxisId="left" domain={[4, 10]} />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 5]} />
                    <Tooltip />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="hours"
                      stroke="#3B82F6"
                      strokeWidth={2}
                      activeDot={{ r: 8 }}
                      name="Hours Slept"
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="quality"
                      stroke="#10B981"
                      strokeWidth={2}
                      name="Sleep Quality"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center mt-4 space-x-8">
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm text-gray-500">Hours Slept</span>
                </div>
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-secondary mr-2"></div>
                  <span className="text-sm text-gray-500">Sleep Quality (1-5)</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Sleep Quality Factors</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Screen Time Before Bed</span>
                      <span className="text-sm text-gray-500">High Impact</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-red-400" style={{ width: "80%" }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Room Temperature</span>
                      <span className="text-sm text-gray-500">Medium Impact</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-amber-400" style={{ width: "60%" }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Exercise During Day</span>
                      <span className="text-sm text-gray-500">Positive Impact</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-green-400" style={{ width: "75%" }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Evening Caffeine</span>
                      <span className="text-sm text-gray-500">High Impact</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-red-400" style={{ width: "85%" }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Consistent Sleep Schedule</span>
                      <span className="text-sm text-gray-500">Positive Impact</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-2 rounded-full bg-green-400" style={{ width: "70%" }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sleep and Recovery</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <p className="text-gray-500 text-sm">
                    Sleep is crucial for muscle recovery, hormone regulation, and cognitive function. Your 
                    current sleep patterns may be affecting your fitness results.
                  </p>
                  
                  <div className="space-y-3">
                    <h4 className="font-medium">Sleep Impact on:</h4>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Muscle Recovery</span>
                        <span className="text-sm text-amber-500">Moderate</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full">
                        <div className="h-2 rounded-full bg-amber-400" style={{ width: "65%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Hormone Balance</span>
                        <span className="text-sm text-amber-500">Moderate</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full">
                        <div className="h-2 rounded-full bg-amber-400" style={{ width: "60%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Workout Performance</span>
                        <span className="text-sm text-amber-500">Moderate</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full">
                        <div className="h-2 rounded-full bg-amber-400" style={{ width: "55%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Nutrition Choices</span>
                        <span className="text-sm text-red-500">Poor</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full">
                        <div className="h-2 rounded-full bg-red-400" style={{ width: "40%" }}></div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-amber-50 p-4 rounded-lg">
                    <h4 className="font-medium text-amber-700 mb-2">Recommendation</h4>
                    <p className="text-amber-700 text-sm">
                      Adding an extra 30-45 minutes of sleep could significantly improve your 
                      recovery and workout performance.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tips">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sleepTips.map((tip, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex">
                    <div className="bg-primary-light/10 rounded-lg h-12 w-12 flex items-center justify-center flex-shrink-0 mr-4">
                      {tip.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-2">{tip.title}</h3>
                      <p className="text-gray-500 text-sm">{tip.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>The Importance of Sleep for Recovery</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div>
                  <img 
                    src="https://images.unsplash.com/photo-1445384763658-0400939829cd" 
                    alt="Peaceful sleep" 
                    className="rounded-lg mb-4 w-full h-48 object-cover"
                  />
                  <p className="text-gray-500 text-sm">
                    Quality sleep is when your body repairs muscles, consolidates memory, and regulates 
                    crucial hormones like cortisol (stress) and leptin/ghrelin (hunger). Consistently getting 
                    7-9 hours of sleep can improve workout performance, accelerate recovery, and help maintain 
                    a healthy weight.
                  </p>
                  <p className="text-gray-500 text-sm mt-4">
                    Your fitness results will dramatically improve with better sleep habits. Research shows that 
                    proper sleep can increase muscle gains by up to 40% and significantly improve athletic performance.
                  </p>
                </div>
                <div className="space-y-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Muscle Recovery</h4>
                    <p className="text-gray-500 text-sm">
                      During deep sleep, growth hormone is released, which helps repair muscle tissue damaged 
                      during exercise. Without adequate sleep, this process is impaired.
                    </p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Hormonal Balance</h4>
                    <p className="text-gray-500 text-sm">
                      Poor sleep disrupts cortisol (stress hormone) and testosterone levels, which can lead 
                      to increased fat storage and decreased muscle growth.
                    </p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Cognitive Function</h4>
                    <p className="text-gray-500 text-sm">
                      Sleep improves reaction time, decision-making, and focus during workouts, leading to more 
                      effective training sessions and better technique.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showAddSleepModal} onOpenChange={setShowAddSleepModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Log Sleep</DialogTitle>
            <DialogDescription>
              Record your sleep duration and quality for tracking.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Date</label>
              <Input 
                type="date" 
                value={newSleepData.date}
                onChange={(e) => setNewSleepData({...newSleepData, date: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <label className="text-sm font-medium">Sleep Duration (hours)</label>
                <span className="text-sm text-gray-500">{newSleepData.duration} hours</span>
              </div>
              <Slider
                min={0}
                max={12}
                step={0.1}
                value={[newSleepData.duration]}
                onValueChange={(value) => setNewSleepData({...newSleepData, duration: value[0]})}
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <label className="text-sm font-medium">Sleep Quality (1-5)</label>
                <span className="text-sm text-gray-500">{newSleepData.quality} / 5</span>
              </div>
              <Slider
                min={1}
                max={5}
                step={1}
                value={[newSleepData.quality]}
                onValueChange={(value) => setNewSleepData({...newSleepData, quality: value[0]})}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Notes</label>
              <Input 
                placeholder="Any factors that affected your sleep?" 
                value={newSleepData.notes}
                onChange={(e) => setNewSleepData({...newSleepData, notes: e.target.value})}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddSleepModal(false)}>Cancel</Button>
            <Button onClick={handleAddSleep}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Sleep;
