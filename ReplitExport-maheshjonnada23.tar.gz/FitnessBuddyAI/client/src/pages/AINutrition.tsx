import { useState } from "react";
import { AINutritionGenerator } from "@/components/ai/AINutritionGenerator";
import { AINutritionDisplay } from "@/components/ai/AINutritionDisplay";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";

// Types for our nutrition plan data
interface FoodItem {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface Meal {
  name: string;
  foods: FoodItem[];
}

interface Supplement {
  name: string;
  dosage: string;
  timing: string;
  benefits: string[];
}

interface AINutritionPlan {
  name: string;
  description: string;
  goal: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  meals: Meal[];
  supplements?: Supplement[];
  ageGroup: string;
}

export default function AINutritionPage() {
  const { toast } = useToast();
  const [generatedNutritionPlan, setGeneratedNutritionPlan] = useState<AINutritionPlan | null>(null);
  const [activeTab, setActiveTab] = useState<string>("generator");

  const saveNutritionPlanMutation = useMutation({
    mutationFn: async (nutritionPlan: AINutritionPlan) => {
      const response = await apiRequest("POST", "/api/nutrition-plans", {
        name: nutritionPlan.name,
        description: nutritionPlan.description,
        goal: nutritionPlan.goal,
        calories: nutritionPlan.calories,
        protein: nutritionPlan.protein,
        carbs: nutritionPlan.carbs,
        fat: nutritionPlan.fat,
        meals: JSON.stringify(nutritionPlan.meals),
        supplements: nutritionPlan.supplements ? JSON.stringify(nutritionPlan.supplements) : null,
        ageGroup: nutritionPlan.ageGroup
      });
      
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Nutrition plan saved successfully!",
        description: "You can find this nutrition plan in your saved plans",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to save nutrition plan",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleNutritionGenerated = (nutritionPlan: AINutritionPlan) => {
    setGeneratedNutritionPlan(nutritionPlan);
    setActiveTab("result");
  };

  const handleSaveNutritionPlan = () => {
    if (generatedNutritionPlan) {
      saveNutritionPlanMutation.mutate(generatedNutritionPlan);
    }
  };

  const handleRegenerate = () => {
    setActiveTab("generator");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-green-500 to-teal-600 bg-clip-text text-transparent">
          AI Nutrition Planner
        </h1>
        <p className="text-gray-600 mt-2 max-w-2xl mx-auto">
          Let our AI create a personalized nutrition plan tailored to your specific needs, 
          dietary preferences, and fitness goals. Just provide a few details and get a complete meal plan instantly.
        </p>
      </motion.div>

      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full max-w-4xl mx-auto"
      >
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="generator">Create Plan</TabsTrigger>
          <TabsTrigger value="result" disabled={!generatedNutritionPlan}>
            View Result
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generator" className="mt-0">
          <AINutritionGenerator onNutritionGenerated={handleNutritionGenerated} />
        </TabsContent>

        <TabsContent value="result" className="mt-0">
          {generatedNutritionPlan && (
            <AINutritionDisplay
              nutritionPlan={generatedNutritionPlan}
              onSave={handleSaveNutritionPlan}
              onRegenerate={handleRegenerate}
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}