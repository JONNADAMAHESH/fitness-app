import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Flower2, Timer, ChevronRight, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const Yoga = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("routines");
  const [selectedPose, setSelectedPose] = useState<any>(null);
  const [showPoseModal, setShowPoseModal] = useState(false);
  const [filter, setFilter] = useState({
    difficulty: "all",
    duration: "all",
  });

  // Fetch yoga routines
  const { data: yogaRoutines, isLoading: isLoadingRoutines } = useQuery({
    queryKey: ["/api/yoga-routines"],
  });

  const handleStartYoga = (routineId: number) => {
    toast({
      title: "Yoga Routine Started",
      description: "Prepare for your yoga session!",
    });
  };

  const handleViewPose = (pose: any) => {
    setSelectedPose(pose);
    setShowPoseModal(true);
  };

  const filteredRoutines = yogaRoutines
    ? yogaRoutines.filter((routine: any) => {
        if (filter.difficulty !== "all" && routine.difficulty !== filter.difficulty) {
          return false;
        }
        if (filter.duration !== "all") {
          const durationRange = filter.duration.split("-");
          const min = parseInt(durationRange[0]);
          const max = parseInt(durationRange[1]);
          if (routine.duration < min || routine.duration > max) {
            return false;
          }
        }
        return true;
      })
    : [];

  const difficultyOptions = [
    { value: "all", label: "All Levels" },
    { value: "beginner", label: "Beginner" },
    { value: "intermediate", label: "Intermediate" },
    { value: "advanced", label: "Advanced" },
  ];

  const durationOptions = [
    { value: "all", label: "All Durations" },
    { value: "5-15", label: "5-15 min" },
    { value: "15-30", label: "15-30 min" },
    { value: "30-60", label: "30-60 min" },
    { value: "60-120", label: "60+ min" },
  ];

  return (
    <div className="container mx-auto px-4 py-6 mb-16 md:mb-0">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Yoga & Mindfulness</h2>
      </div>

      <Tabs defaultValue="routines" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="routines">Yoga Routines</TabsTrigger>
          <TabsTrigger value="poses">Yoga Poses</TabsTrigger>
          <TabsTrigger value="meditation">Meditation</TabsTrigger>
        </TabsList>

        <TabsContent value="routines">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Filter Routines</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Difficulty</label>
                  <Select 
                    value={filter.difficulty}
                    onValueChange={(value) => setFilter({...filter, difficulty: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Levels" />
                    </SelectTrigger>
                    <SelectContent>
                      {difficultyOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Duration</label>
                  <Select 
                    value={filter.duration}
                    onValueChange={(value) => setFilter({...filter, duration: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Durations" />
                    </SelectTrigger>
                    <SelectContent>
                      {durationOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {isLoadingRoutines ? (
              Array(4).fill(0).map((_, i) => (
                <Card key={i}>
                  <Skeleton className="h-48 rounded-t-xl" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-2/3 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <Skeleton className="h-9 w-full" />
                  </CardContent>
                </Card>
              ))
            ) : filteredRoutines && filteredRoutines.length > 0 ? (
              filteredRoutines.map((routine: any) => (
                <Card key={routine.id} className="overflow-hidden">
                  <div className="h-48 relative">
                    <img 
                      src="https://images.unsplash.com/photo-1544367567-0f2fcb009e0b" 
                      alt={routine.name} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-5">
                      <h3 className="text-white text-xl font-bold">{routine.name}</h3>
                      <p className="text-white text-sm opacity-90">
                        {routine.difficulty.charAt(0).toUpperCase() + routine.difficulty.slice(1)} · {routine.duration} min
                      </p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <p className="text-gray-500 text-sm mb-4">{routine.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {routine.benefits && routine.benefits.map((benefit: string, idx: number) => (
                        <Badge key={idx} variant="secondary">{benefit}</Badge>
                      ))}
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        className="flex-1" 
                        onClick={() => handleStartYoga(routine.id)}
                      >
                        Start Session
                      </Button>
                      <Button 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => {
                          toast({
                            title: "Added to Favorites",
                            description: "This yoga routine has been added to your favorites",
                          });
                        }}
                      >
                        Save
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-2 text-center py-10">
                <Flower2 className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No yoga routines found</h3>
                <p className="text-gray-500">Try adjusting your filters</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="poses">
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {/* Sample poses - would be fetched from API in real implementation */}
            {[
              { id: 1, name: "Mountain Pose", difficulty: "beginner", imageUrl: "https://images.unsplash.com/photo-1566501206188-5dd0cf160a0e" },
              { id: 2, name: "Downward Dog", difficulty: "beginner", imageUrl: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b" },
              { id: 3, name: "Warrior I", difficulty: "beginner", imageUrl: "https://images.unsplash.com/photo-1545389336-cf090694435e" },
              { id: 4, name: "Warrior II", difficulty: "intermediate", imageUrl: "https://images.unsplash.com/photo-1599447292461-69e1a5b557de" },
              { id: 5, name: "Triangle Pose", difficulty: "intermediate", imageUrl: "https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b" },
              { id: 6, name: "Tree Pose", difficulty: "beginner", imageUrl: "https://images.unsplash.com/photo-1552286630-776ebc86c03c" },
              { id: 7, name: "Chair Pose", difficulty: "intermediate", imageUrl: "https://images.unsplash.com/photo-1506126613408-eca07ce68773" },
              { id: 8, name: "Cobra Pose", difficulty: "beginner", imageUrl: "https://images.unsplash.com/photo-1510894347713-fc3ed6fdf539" },
            ].map((pose) => (
              <Card key={pose.id} className="overflow-hidden cursor-pointer" onClick={() => handleViewPose(pose)}>
                <div className="h-48 relative">
                  <img 
                    src={pose.imageUrl} 
                    alt={pose.name} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 p-3">
                    <h3 className="text-white font-medium">{pose.name}</h3>
                    <p className="text-white text-xs opacity-90">
                      {pose.difficulty.charAt(0).toUpperCase() + pose.difficulty.slice(1)}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="meditation">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Sample meditations - would be fetched from API in real implementation */}
            {[
              { id: 1, name: "Stress Relief Meditation", duration: 10, description: "A quick meditation to help you release stress and tension." },
              { id: 2, name: "Morning Mindfulness", duration: 15, description: "Start your day with clarity and purpose through guided mindfulness." },
              { id: 3, name: "Deep Sleep Meditation", duration: 20, description: "Prepare your mind and body for a restful night's sleep." },
              { id: 4, name: "Anxiety Reduction", duration: 15, description: "Calm your mind and reduce anxiety with this guided meditation." }
            ].map((meditation) => (
              <Card key={meditation.id} className="overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="bg-primary-light/10 rounded-lg h-12 w-12 flex items-center justify-center mr-4">
                      <Timer className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{meditation.name}</h3>
                      <p className="text-gray-500 text-sm">{meditation.duration} min</p>
                    </div>
                  </div>
                  <p className="text-gray-500 text-sm mb-4">{meditation.description}</p>
                  <Button 
                    className="w-full"
                    onClick={() => {
                      toast({
                        title: "Meditation Started",
                        description: "Find a quiet place and follow the guided meditation",
                      });
                    }}
                  >
                    Start Meditation
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={showPoseModal} onOpenChange={setShowPoseModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedPose?.name}</DialogTitle>
            <DialogDescription>
              {selectedPose && (
                <div className="mt-4">
                  <div className="mb-4 aspect-video bg-gray-100 rounded-lg overflow-hidden">
                    <img 
                      src={selectedPose.imageUrl} 
                      alt={selectedPose.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="mb-4">
                    <h4 className="font-medium mb-2">Difficulty</h4>
                    <Badge>
                      {selectedPose.difficulty.charAt(0).toUpperCase() + selectedPose.difficulty.slice(1)}
                    </Badge>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">How to Perform</h4>
                    <p className="text-gray-600 text-sm">
                      Detailed instructions for the {selectedPose.name} would appear here, guiding you through the proper form and breathing techniques.
                    </p>
                  </div>
                  <Button className="w-full mt-4">
                    View Full Tutorial
                  </Button>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Yoga;
