import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Filter, Dumbbell, ChevronRight, Play, Flame, Trophy, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import ExerciseItem from "@/components/ExerciseItem";
import { InteractiveExerciseCard } from "@/components/InteractiveExerciseCard";
import { WorkoutTimer } from "@/components/WorkoutTimer";
import { ProgressChart } from "@/components/ProgressChart";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

type Exercise = {
  id: number;
  name: string;
  sets: number;
  reps: number;
  restTime: number;
  bodyPart: string;
};

const Workout = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("all");
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [showExerciseModal, setShowExerciseModal] = useState(false);
  const [filters, setFilters] = useState({
    difficulty: "all",
    bodyPart: "all",
    ageGroup: "all",
  });

  // Fetch workouts
  const { data: workouts = [], isLoading: isLoadingWorkouts } = useQuery<any[]>({
    queryKey: ["/api/workouts"],
  });

  // Fetch exercises
  const { data: exercises = [], isLoading: isLoadingExercises } = useQuery<any[]>({
    queryKey: ["/api/exercises"],
  });

  const [activeExercise, setActiveExercise] = useState<Exercise | null>(null);
  const [showWorkoutModal, setShowWorkoutModal] = useState(false);

  const handleWatchExercise = (exercise: Exercise) => {
    setSelectedExercise(exercise);
    setShowExerciseModal(true);
  };

  const handleStartWorkout = (workoutId: number) => {
    // Find the workout
    const workout = workouts.find((w: any) => w.id === workoutId);
    
    toast({
      title: "Workout Started",
      description: `Starting ${workout?.name || 'your workout'}. Good luck!`,
    });
    
    // Show a timer or other interactive elements
    setShowWorkoutModal(true);
  };

  const handleStartExercise = (exerciseId: number) => {
    // Find the exercise
    const exercise = exercises.find((e: any) => e.id === exerciseId);
    if (exercise) {
      setActiveExercise(exercise);
      toast({
        title: "Exercise Started",
        description: `Starting ${exercise.name}. Focus on form!`,
      });
    }
  };

  const filteredExercises = exercises.filter((exercise: any) => {
    if (filters.bodyPart !== "all" && exercise.bodyPart !== filters.bodyPart) {
      return false;
    }
    if (filters.difficulty !== "all" && exercise.difficulty !== filters.difficulty) {
      return false;
    }
    if (filters.ageGroup !== "all" && exercise.ageGroup !== filters.ageGroup) {
      return false;
    }
    return true;
  });

  const bodyPartOptions = [
    { value: "all", label: "All Body Parts" },
    { value: "chest", label: "Chest" },
    { value: "back", label: "Back" },
    { value: "shoulders", label: "Shoulders" },
    { value: "biceps", label: "Biceps" },
    { value: "triceps", label: "Triceps" },
    { value: "forearms", label: "Forearms" },
    { value: "abs", label: "Abs" },
    { value: "quads", label: "Quads" },
    { value: "hamstrings", label: "Hamstrings" },
    { value: "glutes", label: "Glutes" },
    { value: "calves", label: "Calves" },
    { value: "neck", label: "Neck" },
    { value: "eyes", label: "Eyes" },
    { value: "hands", label: "Hands" },
    { value: "knees", label: "Knees" },
  ];

  const difficultyOptions = [
    { value: "all", label: "All Levels" },
    { value: "beginner", label: "Beginner" },
    { value: "intermediate", label: "Intermediate" },
    { value: "advanced", label: "Advanced" },
  ];

  const ageGroupOptions = [
    { value: "all", label: "All Ages" },
    { value: "18-35", label: "18-35" },
    { value: "35-90", label: "35-90" },
  ];

  return (
    <div className="container mx-auto px-4 py-6 mb-16 md:mb-0">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Workouts & Exercises</h2>
        <Button
          variant="default"
          className="bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700"
          onClick={() => window.location.href = "/ai-workout"}
        >
          <Flame className="mr-2 h-4 w-4" />
          AI Workout Generator
        </Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="all">All Workouts</TabsTrigger>
          <TabsTrigger value="exercises">Exercises</TabsTrigger>
          <TabsTrigger value="saved">Saved Workouts</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {isLoadingWorkouts ? (
              Array(4).fill(0).map((_, i) => (
                <Card key={i}>
                  <Skeleton className="h-48 rounded-t-xl" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-2/3 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <Skeleton className="h-9 w-full" />
                  </CardContent>
                </Card>
              ))
            ) : workouts && workouts.length > 0 ? (
              workouts.map((workout: any) => (
                <Card key={workout.id} className="overflow-hidden">
                  <div className="h-48 relative">
                    <img 
                      src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438" 
                      alt={workout.name} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-5">
                      <h3 className="text-white text-xl font-bold">{workout.name}</h3>
                      <p className="text-white text-sm opacity-90">
                        {workout.difficulty.charAt(0).toUpperCase() + workout.difficulty.slice(1)} · {workout.duration} min · {workout.calories} cal
                      </p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <p className="text-gray-500 text-sm mb-4">{workout.description}</p>
                    <Button 
                      className="w-full" 
                      onClick={() => handleStartWorkout(workout.id)}
                    >
                      Start Workout
                    </Button>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-2 text-center py-10">
                <Dumbbell className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">No workouts found</h3>
                <p className="text-gray-500">Try adjusting your filters or create a custom workout</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="exercises">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Exercise Filters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Body Part</label>
                  <Select 
                    value={filters.bodyPart}
                    onValueChange={(value) => setFilters({...filters, bodyPart: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Body Parts" />
                    </SelectTrigger>
                    <SelectContent>
                      {bodyPartOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Difficulty</label>
                  <Select 
                    value={filters.difficulty}
                    onValueChange={(value) => setFilters({...filters, difficulty: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Levels" />
                    </SelectTrigger>
                    <SelectContent>
                      {difficultyOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Age Group</label>
                  <Select 
                    value={filters.ageGroup}
                    onValueChange={(value) => setFilters({...filters, ageGroup: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Ages" />
                    </SelectTrigger>
                    <SelectContent>
                      {ageGroupOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {isLoadingExercises ? (
            <div className="space-y-4">
              {Array(5).fill(0).map((_, i) => (
                <div key={i} className="flex items-center p-4 bg-white rounded-xl shadow-sm">
                  <Skeleton className="h-12 w-12 rounded-lg mr-4" />
                  <div className="flex-1">
                    <Skeleton className="h-5 w-1/3 mb-2" />
                    <Skeleton className="h-4 w-1/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredExercises.length > 0 ? (
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-4 space-y-4">
                {filteredExercises.map((exercise: any, index: number) => (
                  <ExerciseItem
                    key={exercise.id}
                    icon={<Dumbbell className="h-6 w-6 text-primary" />}
                    name={exercise.name}
                    details={`${exercise.bodyPart} · ${exercise.difficulty}`}
                    onWatch={() => handleWatchExercise(exercise)}
                    showBorder={index < filteredExercises.length - 1}
                  />
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm p-10 text-center">
              <Dumbbell className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">No exercises found</h3>
              <p className="text-gray-500">Try adjusting your filters</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="saved">
          <div className="bg-white rounded-xl shadow-sm p-10 text-center">
            <Dumbbell className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">No saved workouts yet</h3>
            <p className="text-gray-500 mb-6">Start saving your favorite workouts for quick access</p>
            <Button onClick={() => setActiveTab("all")}>Browse Workouts</Button>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={showExerciseModal} onOpenChange={setShowExerciseModal}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedExercise?.name}</DialogTitle>
          </DialogHeader>
          
          {selectedExercise && (
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1571019613914-85f342c6a11e"
                    alt={selectedExercise.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <Badge variant="outline" className="bg-blue-100 text-blue-800">
                      {selectedExercise.bodyPart}
                    </Badge>
                    <Badge variant="outline" className="bg-green-100 text-green-800">
                      Intermediate
                    </Badge>
                  </div>
                  
                  <div className="space-y-1">
                    <h3 className="font-semibold">Instructions:</h3>
                    <ol className="list-decimal pl-5 space-y-2 text-sm text-gray-600">
                      <li>Stand with feet shoulder-width apart</li>
                      <li>Maintain a tight core and straight back throughout the movement</li>
                      <li>Perform the exercise with controlled motion</li>
                      <li>Focus on the muscle contraction at the top of the movement</li>
                      <li>Return to starting position with a slow, controlled movement</li>
                    </ol>
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                <WorkoutTimer
                  initialDuration={selectedExercise.restTime}
                  exerciseName={selectedExercise.name}
                  onComplete={() => toast({
                    title: "Rest Complete",
                    description: "Time for the next set!",
                  })}
                />
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Workout Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Sets:</span>
                      <span className="font-semibold">{selectedExercise.sets}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Reps:</span>
                      <span className="font-semibold">{selectedExercise.reps}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Rest Time:</span>
                      <span className="font-semibold">{selectedExercise.restTime}s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Target Muscle:</span>
                      <span className="font-semibold">{selectedExercise.bodyPart}</span>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="flex gap-3">
                  <Button className="flex-1">
                    <Play className="mr-2 h-4 w-4" />
                    Start Set
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <ArrowUpRight className="mr-2 h-4 w-4" />
                    View Tutorial
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button
              onClick={() => setShowExerciseModal(false)}
              variant="secondary"
            >
              Close
            </Button>
            <Button
              onClick={() => {
                toast({
                  title: "Exercise Added",
                  description: "Exercise has been added to your workout",
                });
                setShowExerciseModal(false);
              }}
            >
              Add to Workout
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Workout;
