import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { 
  Brain, 
  Target, 
  Clock, 
  LineChart, 
  Activity, 
  Award,
  PlayCircle,
  PauseCircle,
  RefreshCw,
  Zap,
  Sparkles,
  Lightbulb
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

// Game types for cognitive training
type GameType = "memory" | "attention" | "processing" | "problem-solving" | "flexibility";

interface Game {
  id: string;
  name: string;
  type: GameType;
  description: string;
  difficulty: 1 | 2 | 3;
  duration: number;
  targetSkills: string[];
  icon: React.ReactNode;
}

interface UserProgress {
  level: number;
  xp: number;
  xpToNextLevel: number;
  totalGamesPlayed: number;
  skillLevels: {
    memory: number;
    attention: number;
    processing: number;
    problemSolving: number;
    flexibility: number;
  };
  recentScores: {
    gameId: string;
    date: Date;
    score: number;
    improvement: number;
  }[];
}

export default function CognitiveTraining() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [activeGame, setActiveGame] = useState<Game | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameTimeRemaining, setGameTimeRemaining] = useState(0);
  const [memorySequence, setMemorySequence] = useState<number[]>([]);
  const [userSequence, setUserSequence] = useState<number[]>([]);
  const [sequenceStep, setSequenceStep] = useState(0);
  const [showingSequence, setShowingSequence] = useState(false);
  const [score, setScore] = useState(0);
  
  // User progress - in a real app, this would come from an API
  const [userProgress, setUserProgress] = useState<UserProgress>({
    level: 3,
    xp: 1250,
    xpToNextLevel: 2000,
    totalGamesPlayed: 28,
    skillLevels: {
      memory: 4,
      attention: 3,
      processing: 5,
      problemSolving: 2,
      flexibility: 3
    },
    recentScores: [
      {
        gameId: "memory-matrix",
        date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        score: 85,
        improvement: 5
      },
      {
        gameId: "speed-match",
        date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        score: 72,
        improvement: 3
      },
      {
        gameId: "word-pairs",
        date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        score: 90,
        improvement: 8
      }
    ]
  });
  
  // Available cognitive games
  const games: Game[] = [
    {
      id: "memory-matrix",
      name: "Memory Matrix",
      type: "memory",
      description: "Remember the pattern of highlighted squares in a grid, then reproduce it.",
      difficulty: 2,
      duration: 3,
      targetSkills: ["Visual Memory", "Spatial Recall"],
      icon: <Brain />
    },
    {
      id: "speed-match",
      name: "Speed Match",
      type: "processing",
      description: "Quickly determine if the current symbol matches the one you saw previously.",
      difficulty: 1,
      duration: 2,
      targetSkills: ["Processing Speed", "Response Time"],
      icon: <Zap />
    },
    {
      id: "word-pairs",
      name: "Word Pairs",
      type: "memory",
      description: "Memorize pairs of words and recall them later.",
      difficulty: 2,
      duration: 4,
      targetSkills: ["Verbal Memory", "Association"],
      icon: <Sparkles />
    },
    {
      id: "divided-attention",
      name: "Divided Attention",
      type: "attention",
      description: "Track multiple moving objects while monitoring for specific events.",
      difficulty: 3,
      duration: 3,
      targetSkills: ["Divided Attention", "Mental Tracking"],
      icon: <Target />
    },
    {
      id: "logical-puzzles",
      name: "Logical Puzzles",
      type: "problem-solving",
      description: "Solve logic-based puzzles using deductive reasoning.",
      difficulty: 3,
      duration: 5,
      targetSkills: ["Logical Reasoning", "Problem Solving"],
      icon: <Lightbulb />
    }
  ];
  
  // Helper function to get the difficulty text
  const getDifficultyText = (level: 1 | 2 | 3) => {
    switch (level) {
      case 1: return "Beginner";
      case 2: return "Intermediate";
      case 3: return "Advanced";
    }
  };
  
  // Helper function to get difficulty badge
  const getDifficultyBadge = (level: 1 | 2 | 3) => {
    switch (level) {
      case 1:
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Beginner</Badge>;
      case 2:
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Intermediate</Badge>;
      case 3:
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Advanced</Badge>;
    }
  };
  
  // Start a game
  const startGame = (game: Game) => {
    setActiveGame(game);
    setActiveTab("play");
    setIsPlaying(false);
    setScore(0);
    
    toast({
      title: `${game.name} loaded`,
      description: "Get ready to start the game!",
    });
  };
  
  // Begin the actual gameplay
  const beginGameplay = () => {
    if (!activeGame) return;
    
    setIsPlaying(true);
    setGameTimeRemaining(activeGame.duration * 60);
    
    // Setup for memory matrix game
    if (activeGame.id === "memory-matrix") {
      // Generate a random sequence for the memory game
      const sequence = Array.from({ length: 5 }, () => Math.floor(Math.random() * 9));
      setMemorySequence(sequence);
      setUserSequence([]);
      setSequenceStep(0);
      setShowingSequence(true);
      
      // Show the sequence to the player
      let step = 0;
      const intervalId = setInterval(() => {
        if (step < sequence.length) {
          setSequenceStep(step);
          step++;
        } else {
          clearInterval(intervalId);
          setShowingSequence(false);
          setSequenceStep(-1);
        }
      }, 1000);
    }
  };
  
  // Handle user input for memory game
  const handleMemoryInput = (index: number) => {
    if (showingSequence || !isPlaying) return;
    
    // Add user's selection to their sequence
    const newUserSequence = [...userSequence, index];
    setUserSequence(newUserSequence);
    
    // Check if the selection was correct
    const currentStep = userSequence.length;
    if (index === memorySequence[currentStep]) {
      // Correct selection
      if (newUserSequence.length === memorySequence.length) {
        // Completed the sequence successfully
        toast({
          title: "Sequence complete!",
          description: "Well done! Get ready for the next sequence.",
        });
        
        setScore(score + 10);
        
        // Generate a new, slightly longer sequence
        const newLength = memorySequence.length + 1;
        const newSequence = Array.from({ length: newLength }, () => Math.floor(Math.random() * 9));
        
        // Reset for next round
        setTimeout(() => {
          setMemorySequence(newSequence);
          setUserSequence([]);
          setSequenceStep(0);
          setShowingSequence(true);
          
          // Show the new sequence
          let step = 0;
          const intervalId = setInterval(() => {
            if (step < newSequence.length) {
              setSequenceStep(step);
              step++;
            } else {
              clearInterval(intervalId);
              setShowingSequence(false);
              setSequenceStep(-1);
            }
          }, 1000);
        }, 1000);
      }
    } else {
      // Incorrect selection
      toast({
        title: "Incorrect",
        description: "That wasn't the right tile. Try again with a new sequence.",
        variant: "destructive"
      });
      
      // Generate a new sequence of the same length
      const newSequence = Array.from({ length: memorySequence.length }, () => Math.floor(Math.random() * 9));
      
      // Reset for next round
      setTimeout(() => {
        setMemorySequence(newSequence);
        setUserSequence([]);
        setSequenceStep(0);
        setShowingSequence(true);
        
        // Show the new sequence
        let step = 0;
        const intervalId = setInterval(() => {
          if (step < newSequence.length) {
            setSequenceStep(step);
            step++;
          } else {
            clearInterval(intervalId);
            setShowingSequence(false);
            setSequenceStep(-1);
          }
        }, 1000);
      }, 1000);
    }
  };
  
  // End the game
  const endGame = () => {
    setIsPlaying(false);
    
    // Update user progress with the new score
    if (activeGame) {
      const updatedRecentScores = [
        {
          gameId: activeGame.id,
          date: new Date(),
          score: score,
          improvement: Math.floor(Math.random() * 10)
        },
        ...userProgress.recentScores.slice(0, 2)
      ];
      
      setUserProgress({
        ...userProgress,
        xp: userProgress.xp + score,
        totalGamesPlayed: userProgress.totalGamesPlayed + 1,
        recentScores: updatedRecentScores
      });
    }
    
    toast({
      title: "Game complete!",
      description: `You scored ${score} points.`,
    });
    
    // Return to the games list
    setTimeout(() => {
      setActiveTab("games");
      setActiveGame(null);
    }, 2000);
  };
  
  // Game timer effect
  useEffect(() => {
    let timerId: NodeJS.Timeout;
    
    if (isPlaying && gameTimeRemaining > 0) {
      timerId = setInterval(() => {
        setGameTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timerId);
            endGame();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [isPlaying, gameTimeRemaining]);
  
  // Format time remaining in MM:SS
  const formatTimeRemaining = () => {
    const minutes = Math.floor(gameTimeRemaining / 60);
    const seconds = gameTimeRemaining % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col items-center mb-8">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold text-center bg-gradient-to-r from-blue-600 to-teal-500 text-transparent bg-clip-text">
            Cognitive Fitness Training
          </h1>
        </motion.div>
        <p className="text-gray-600 mt-2 text-center max-w-2xl">
          Enhance your mental performance with scientifically-designed brain training exercises.
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 max-w-2xl mx-auto mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="games">Games</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
          <TabsTrigger value="play" disabled={!activeGame}>Play</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Why Train Your Brain?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Cognitive training exercises are designed to improve specific brain functions through repeated practice and increasing challenges, similar to how physical exercise strengthens the body.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                        <Brain className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">Neuroplasticity</p>
                        <p className="text-sm text-gray-500">Your brain forms new neural connections throughout life, allowing it to adapt and improve.</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                        <Activity className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium">Targeted Training</p>
                        <p className="text-sm text-gray-500">Each exercise focuses on specific cognitive functions such as memory, attention, or processing speed.</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                        <LineChart className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-medium">Progressive Challenge</p>
                        <p className="text-sm text-gray-500">Exercises adapt to your skill level, becoming more challenging as you improve.</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Your Brain Profile</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-teal-500 flex items-center justify-center text-white text-lg font-bold mr-4">
                        {userProgress.level}
                      </div>
                      <div>
                        <p className="font-medium">Level {userProgress.level}</p>
                        <p className="text-sm text-gray-500">{userProgress.xp} / {userProgress.xpToNextLevel} XP</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      {userProgress.totalGamesPlayed} Games Played
                    </Badge>
                  </div>
                  
                  <Progress value={(userProgress.xp / userProgress.xpToNextLevel) * 100} className="h-2" />
                  
                  <Separator className="my-4" />
                  
                  <div className="space-y-3">
                    <h3 className="font-medium">Your Cognitive Skills</h3>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Memory</span>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div 
                              key={i} 
                              className={`w-3 h-3 rounded-full mx-0.5 ${
                                i < userProgress.skillLevels.memory 
                                  ? 'bg-blue-500' 
                                  : 'bg-gray-200'
                              }`} 
                            />
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Attention</span>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div 
                              key={i} 
                              className={`w-3 h-3 rounded-full mx-0.5 ${
                                i < userProgress.skillLevels.attention 
                                  ? 'bg-green-500' 
                                  : 'bg-gray-200'
                              }`} 
                            />
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Processing Speed</span>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div 
                              key={i} 
                              className={`w-3 h-3 rounded-full mx-0.5 ${
                                i < userProgress.skillLevels.processing 
                                  ? 'bg-purple-500' 
                                  : 'bg-gray-200'
                              }`} 
                            />
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Problem Solving</span>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div 
                              key={i} 
                              className={`w-3 h-3 rounded-full mx-0.5 ${
                                i < userProgress.skillLevels.problemSolving 
                                  ? 'bg-orange-500' 
                                  : 'bg-gray-200'
                              }`} 
                            />
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Cognitive Flexibility</span>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div 
                              key={i} 
                              className={`w-3 h-3 rounded-full mx-0.5 ${
                                i < userProgress.skillLevels.flexibility 
                                  ? 'bg-teal-500' 
                                  : 'bg-gray-200'
                              }`} 
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    onClick={() => setActiveTab("progress")}
                    variant="outline" 
                    className="w-full"
                  >
                    View Detailed Progress
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          </div>
          
          <Card className="bg-gradient-to-r from-blue-50 to-teal-50 border-none">
            <CardHeader>
              <CardTitle className="text-xl text-center">Ready to Train Your Brain?</CardTitle>
              <CardDescription className="text-center">
                Start with a cognitive exercise designed to improve your brain function
              </CardDescription>
            </CardHeader>
            <CardFooter className="flex justify-center pb-6">
              <Button 
                className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                onClick={() => setActiveTab("games")}
              >
                Explore Games
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="games">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game, index) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="h-full flex flex-col">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex items-center space-x-2">
                        <div className="p-2 rounded-full bg-blue-100 text-blue-600">
                          {game.icon}
                        </div>
                        <CardTitle className="text-lg">{game.name}</CardTitle>
                      </div>
                      {getDifficultyBadge(game.difficulty)}
                    </div>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <p className="text-gray-600 mb-4">{game.description}</p>
                    <div className="space-y-2">
                      <div className="flex items-center text-sm">
                        <Clock className="h-4 w-4 mr-2 text-gray-500" />
                        <span>{game.duration} min</span>
                      </div>
                      <div className="flex flex-wrap gap-1 text-sm">
                        {game.targetSkills.map((skill, i) => (
                          <Badge key={i} variant="secondary" className="bg-gray-100 text-gray-800 hover:bg-gray-200">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="w-full bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                      onClick={() => startGame(game)}
                    >
                      Play Game
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="progress">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Your Cognitive Progress</CardTitle>
                <CardDescription>
                  Track your improvements across different cognitive domains
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-6 bg-gray-50 rounded-lg mb-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-sm text-gray-500">Level</p>
                      <p className="text-2xl font-bold text-blue-600">{userProgress.level}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">XP</p>
                      <p className="text-2xl font-bold text-green-600">{userProgress.xp}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Games Played</p>
                      <p className="text-2xl font-bold text-purple-600">{userProgress.totalGamesPlayed}</p>
                    </div>
                  </div>
                </div>
                
                <h3 className="font-medium mb-4">Skill Development</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Memory</span>
                      <span className="text-sm text-gray-500">{userProgress.skillLevels.memory}/5</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500 rounded-full" 
                        style={{ width: `${(userProgress.skillLevels.memory / 5) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Attention</span>
                      <span className="text-sm text-gray-500">{userProgress.skillLevels.attention}/5</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-green-500 rounded-full" 
                        style={{ width: `${(userProgress.skillLevels.attention / 5) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Processing Speed</span>
                      <span className="text-sm text-gray-500">{userProgress.skillLevels.processing}/5</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-purple-500 rounded-full" 
                        style={{ width: `${(userProgress.skillLevels.processing / 5) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Problem Solving</span>
                      <span className="text-sm text-gray-500">{userProgress.skillLevels.problemSolving}/5</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-orange-500 rounded-full" 
                        style={{ width: `${(userProgress.skillLevels.problemSolving / 5) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Cognitive Flexibility</span>
                      <span className="text-sm text-gray-500">{userProgress.skillLevels.flexibility}/5</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-teal-500 rounded-full" 
                        style={{ width: `${(userProgress.skillLevels.flexibility / 5) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
                
                <Separator className="my-6" />
                
                <h3 className="font-medium mb-4">Progress Visualization</h3>
                <div className="h-64 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <LineChart className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                    <p>Skill development charts would be displayed here</p>
                    <p className="text-sm text-gray-400">Tracking your improvements over time</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Recent Performance</CardTitle>
                <CardDescription>
                  Your recent game scores and improvements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userProgress.recentScores.map((scoreData, index) => {
                    const game = games.find(g => g.id === scoreData.gameId);
                    return (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">{game?.name || scoreData.gameId}</h4>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            {new Date(scoreData.date).toLocaleDateString()}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <Award className="h-4 w-4 mr-2 text-yellow-500" />
                            <span>{scoreData.score} points</span>
                          </div>
                          <div className="flex items-center text-green-600">
                            <span>+{scoreData.improvement}%</span>
                            <RefreshCw className="h-4 w-4 ml-1" />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={() => setActiveTab("games")}
                  className="w-full bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                >
                  Play More Games
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="play">
          {activeGame && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center">
                      <div className="p-2 rounded-full bg-blue-100 text-blue-600 mr-3">
                        {activeGame.icon}
                      </div>
                      {activeGame.name}
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      {isPlaying && (
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          <Clock className="h-3 w-3 mr-1" /> {formatTimeRemaining()}
                        </Badge>
                      )}
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Score: {score}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {!isPlaying ? (
                    <div className="text-center py-8">
                      <div className="mb-4">
                        <PlayCircle className="h-16 w-16 mx-auto text-blue-500" />
                      </div>
                      <h3 className="text-xl font-medium mb-2">{activeGame.name}</h3>
                      <p className="text-gray-600 mb-4 max-w-md mx-auto">{activeGame.description}</p>
                      <div className="flex justify-center gap-4 mb-6">
                        <div className="text-center">
                          <p className="text-sm text-gray-500">Difficulty</p>
                          <p className="font-medium">{getDifficultyText(activeGame.difficulty)}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-gray-500">Duration</p>
                          <p className="font-medium">{activeGame.duration} min</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-gray-500">Skills</p>
                          <p className="font-medium">{activeGame.type.charAt(0).toUpperCase() + activeGame.type.slice(1)}</p>
                        </div>
                      </div>
                      <Button 
                        className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600"
                        onClick={beginGameplay}
                      >
                        Begin Game
                      </Button>
                    </div>
                  ) : (
                    <div className="p-4">
                      {/* Memory Matrix Game Interface */}
                      {activeGame.id === "memory-matrix" && (
                        <div className="max-w-md mx-auto">
                          <div className="mb-4 text-center">
                            <h3 className="text-lg font-medium mb-1">Memory Matrix</h3>
                            <p className="text-sm text-gray-500">
                              {showingSequence 
                                ? "Remember the highlighted squares..." 
                                : "Now reproduce the pattern you saw"}
                            </p>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-2 mb-4">
                            {Array.from({ length: 9 }).map((_, index) => (
                              <button
                                key={index}
                                className={`aspect-square rounded border-2 ${
                                  showingSequence && sequenceStep === memorySequence.indexOf(index) && memorySequence.includes(index)
                                    ? 'bg-blue-500 border-blue-600' 
                                    : userSequence.includes(index) && !showingSequence
                                    ? 'bg-green-100 border-green-300'
                                    : 'bg-gray-100 border-gray-200 hover:bg-gray-200'
                                }`}
                                onClick={() => handleMemoryInput(index)}
                                disabled={showingSequence}
                              />
                            ))}
                          </div>
                          
                          <div className="text-center">
                            <p className="text-sm text-gray-500 mb-2">
                              {showingSequence 
                                ? "Memorizing pattern..." 
                                : `Sequence length: ${memorySequence.length} | Correct: ${userSequence.length}/${memorySequence.length}`}
                            </p>
                            {showingSequence && (
                              <Progress value={(sequenceStep / memorySequence.length) * 100} className="h-2 mb-4" />
                            )}
                          </div>
                        </div>
                      )}
                      
                      {/* Other game interfaces would be implemented here */}
                      {activeGame.id !== "memory-matrix" && (
                        <div className="text-center py-16">
                          <div className="mb-4">
                            <PlayCircle className="h-16 w-16 mx-auto text-blue-500" />
                          </div>
                          <p className="text-gray-600">
                            {activeGame.name} game interface would be implemented here.
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setIsPlaying(false);
                      setActiveTab("games");
                      setActiveGame(null);
                    }}
                  >
                    Exit Game
                  </Button>
                  
                  {isPlaying && (
                    <Button 
                      variant="destructive"
                      onClick={endGame}
                    >
                      End Game
                    </Button>
                  )}
                </CardFooter>
              </Card>
            </motion.div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}