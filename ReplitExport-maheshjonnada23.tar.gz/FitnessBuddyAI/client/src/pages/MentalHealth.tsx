import { useState } from "react";
import { motion } from "framer-motion";
import { ChevronRight, BrainCircuit, ActivitySquare, LineChart, MessageCircle, Award } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";

interface MentalHealthScore {
  overall: number;
  stress: number;
  anxiety: number;
  mood: number;
  sleep: number;
  focus: number;
  recommendations: string[];
}

export default function MentalHealth() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("assessment");
  const [mentalHealthScore, setMentalHealthScore] = useState<MentalHealthScore | null>(null);
  const [assessmentStarted, setAssessmentStarted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});

  // Example assessment questions
  const questions = [
    {
      id: "stress_1",
      category: "stress",
      text: "How often do you feel overwhelmed by your responsibilities?",
      options: [
        { value: 1, label: "Never" },
        { value: 2, label: "Rarely" },
        { value: 3, label: "Sometimes" },
        { value: 4, label: "Often" },
        { value: 5, label: "Always" }
      ]
    },
    {
      id: "anxiety_1",
      category: "anxiety",
      text: "How frequently do you feel nervous or anxious?",
      options: [
        { value: 1, label: "Never" },
        { value: 2, label: "Rarely" },
        { value: 3, label: "Sometimes" },
        { value: 4, label: "Often" },
        { value: 5, label: "Always" }
      ]
    },
    {
      id: "mood_1",
      category: "mood",
      text: "How would you rate your overall mood most days?",
      options: [
        { value: 5, label: "Excellent" },
        { value: 4, label: "Good" },
        { value: 3, label: "Average" },
        { value: 2, label: "Poor" },
        { value: 1, label: "Very poor" }
      ]
    },
    {
      id: "sleep_1",
      category: "sleep",
      text: "How satisfied are you with your sleep quality?",
      options: [
        { value: 5, label: "Very satisfied" },
        { value: 4, label: "Satisfied" },
        { value: 3, label: "Neutral" },
        { value: 2, label: "Dissatisfied" },
        { value: 1, label: "Very dissatisfied" }
      ]
    },
    {
      id: "focus_1",
      category: "focus",
      text: "How easily can you concentrate on tasks?",
      options: [
        { value: 5, label: "Very easily" },
        { value: 4, label: "Easily" },
        { value: 3, label: "With some difficulty" },
        { value: 2, label: "With difficulty" },
        { value: 1, label: "With extreme difficulty" }
      ]
    },
    {
      id: "stress_2",
      category: "stress",
      text: "How often do you take time to relax and recharge?",
      options: [
        { value: 5, label: "Daily" },
        { value: 4, label: "Several times a week" },
        { value: 3, label: "Once a week" },
        { value: 2, label: "Rarely" },
        { value: 1, label: "Never" }
      ]
    },
    {
      id: "anxiety_2",
      category: "anxiety",
      text: "How frequently do you experience physical symptoms of anxiety (rapid heartbeat, sweating, etc.)?",
      options: [
        { value: 1, label: "Never" },
        { value: 2, label: "Rarely" },
        { value: 3, label: "Sometimes" },
        { value: 4, label: "Often" },
        { value: 5, label: "Always" }
      ]
    },
    {
      id: "mood_2",
      category: "mood",
      text: "How often do you feel optimistic about the future?",
      options: [
        { value: 5, label: "Always" },
        { value: 4, label: "Often" },
        { value: 3, label: "Sometimes" },
        { value: 2, label: "Rarely" },
        { value: 1, label: "Never" }
      ]
    },
    {
      id: "sleep_2",
      category: "sleep",
      text: "How often do you have difficulty falling asleep or staying asleep?",
      options: [
        { value: 1, label: "Never" },
        { value: 2, label: "Rarely" },
        { value: 3, label: "Sometimes" },
        { value: 4, label: "Often" },
        { value: 5, label: "Always" }
      ]
    },
    {
      id: "focus_2",
      category: "focus",
      text: "How often do you find yourself distracted when trying to complete important tasks?",
      options: [
        { value: 1, label: "Never" },
        { value: 2, label: "Rarely" },
        { value: 3, label: "Sometimes" },
        { value: 4, label: "Often" },
        { value: 5, label: "Always" }
      ]
    },
  ];

  const currentQuestion = questions[currentQuestionIndex];
  const assessmentProgress = (currentQuestionIndex / questions.length) * 100;

  const handleAnswer = (value: number) => {
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: value }));
    
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      // Calculate scores and submit assessment
      analyzeMentalHealthMutation.mutate();
    }
  };

  const analyzeMentalHealthMutation = useMutation({
    mutationFn: async () => {
      // Group answers by category
      const categoryScores: Record<string, number[]> = {};
      
      Object.entries(answers).forEach(([questionId, value]) => {
        const question = questions.find(q => q.id === questionId);
        if (question) {
          if (!categoryScores[question.category]) {
            categoryScores[question.category] = [];
          }
          categoryScores[question.category].push(value);
        }
      });
      
      // Calculate average for each category
      const averages: Record<string, number> = {};
      Object.entries(categoryScores).forEach(([category, values]) => {
        averages[category] = values.reduce((sum, val) => sum + val, 0) / values.length;
      });
      
      // Calculate overall score (inverted for stress and anxiety)
      const stressScore = 6 - averages.stress;
      const anxietyScore = 6 - averages.anxiety;
      const moodScore = averages.mood;
      const sleepScore = averages.sleep;
      const focusScore = averages.focus;
      
      const overall = (stressScore + anxietyScore + moodScore + sleepScore + focusScore) / 5;
      
      // Generate recommendations based on scores
      const recommendations = generateRecommendations({
        stress: stressScore,
        anxiety: anxietyScore,
        mood: moodScore,
        sleep: sleepScore,
        focus: focusScore
      });
      
      return {
        overall: Math.round(overall * 20), // scale to 0-100
        stress: Math.round(stressScore * 20),
        anxiety: Math.round(anxietyScore * 20),
        mood: Math.round(moodScore * 20),
        sleep: Math.round(sleepScore * 20),
        focus: Math.round(focusScore * 20),
        recommendations
      };
    },
    onSuccess: (data) => {
      setMentalHealthScore(data);
      setAssessmentStarted(false);
      setActiveTab("results");
      
      toast({
        title: "Mental health assessment complete",
        description: "Your results are ready to view",
      });
    },
    onError: (error) => {
      toast({
        title: "Assessment failed",
        description: "There was an error analyzing your responses. Please try again.",
        variant: "destructive",
      });
    },
  });

  function generateRecommendations(scores: Record<string, number>): string[] {
    const recommendations: string[] = [];
    
    if (scores.stress < 3.5) {
      recommendations.push("Practice daily stress reduction techniques such as deep breathing or progressive muscle relaxation.");
    }
    
    if (scores.anxiety < 3.5) {
      recommendations.push("Consider mindfulness meditation to manage anxiety. Start with just 5 minutes per day.");
    }
    
    if (scores.mood < 3.5) {
      recommendations.push("Incorporate more physical activity into your routine to boost mood and reduce symptoms of depression.");
    }
    
    if (scores.sleep < 3.5) {
      recommendations.push("Improve your sleep hygiene by maintaining a consistent sleep schedule and avoiding screens before bedtime.");
    }
    
    if (scores.focus < 3.5) {
      recommendations.push("Try the Pomodoro Technique (25 minutes of focused work followed by a 5-minute break) to improve concentration.");
    }
    
    // Add general recommendations
    recommendations.push("Stay hydrated and maintain a balanced diet rich in omega-3 fatty acids, which support brain health.");
    recommendations.push("Spend time in nature regularly, which has been shown to reduce stress and improve mood.");
    
    return recommendations;
  }

  const startAssessment = () => {
    setAssessmentStarted(true);
    setCurrentQuestionIndex(0);
    setAnswers({});
  };

  const resetAssessment = () => {
    startAssessment();
  };

  // Track progress changes with a colorful indicator
  const getProgressColor = (value: number) => {
    if (value < 40) return "bg-red-500";
    if (value < 60) return "bg-yellow-500";
    if (value < 80) return "bg-blue-500";
    return "bg-green-500";
  };

  // Features data
  const mentalHealthFeatures = [
    {
      icon: <BrainCircuit className="h-10 w-10 text-purple-500" />,
      title: "AI Mental Assessment",
      description: "Get insights into your mental wellbeing with our advanced assessment tool.",
    },
    {
      icon: <ActivitySquare className="h-10 w-10 text-blue-500" />,
      title: "Stress Biofeedback",
      description: "Learn to manage stress through biofeedback training techniques.",
    },
    {
      icon: <LineChart className="h-10 w-10 text-green-500" />,
      title: "Mood Tracking",
      description: "Track your mood patterns over time to identify triggers and improvements.",
    },
    {
      icon: <MessageCircle className="h-10 w-10 text-yellow-500" />,
      title: "AI Coaching",
      description: "Receive personalized coaching based on your mental health patterns.",
    },
    {
      icon: <Award className="h-10 w-10 text-red-500" />,
      title: "Cognitive Training",
      description: "Train your brain with exercises designed to improve memory and focus.",
    },
  ];

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col items-center mb-8">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold text-center bg-gradient-to-r from-purple-600 to-blue-500 text-transparent bg-clip-text">
            Mental Health & Wellness
          </h1>
        </motion.div>
        <p className="text-gray-600 mt-2 text-center max-w-2xl">
          Enhance your mental wellbeing with our AI-powered tools and personalized recommendations.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 max-w-2xl mx-auto mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="assessment">Assessment</TabsTrigger>
          <TabsTrigger value="results" disabled={!mentalHealthScore}>Results</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mentalHealthFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <div className="flex justify-center mb-4">
                      {feature.icon}
                    </div>
                    <CardTitle className="text-center">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-center text-gray-600">{feature.description}</p>
                  </CardContent>
                  <CardFooter className="pt-0 flex justify-center">
                    <Button variant="outline" className="mt-2">
                      Learn More <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="mt-12">
            <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-none">
              <CardHeader>
                <CardTitle className="text-xl text-center">Ready to improve your mental wellness?</CardTitle>
                <CardDescription className="text-center">
                  Take our comprehensive assessment to get personalized recommendations
                </CardDescription>
              </CardHeader>
              <CardFooter className="flex justify-center pb-6">
                <Button 
                  className="bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600"
                  onClick={() => setActiveTab("assessment")}
                >
                  Start Assessment
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="assessment">
          <Card className="max-w-3xl mx-auto">
            <CardHeader>
              <CardTitle>Mental Health Assessment</CardTitle>
              <CardDescription>
                {assessmentStarted 
                  ? "Answer honestly for the most accurate results"
                  : "This assessment will help us understand your mental wellbeing and provide personalized recommendations"
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!assessmentStarted ? (
                <div className="space-y-4">
                  <p>This confidential assessment will take approximately 5 minutes to complete and includes questions about:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Stress levels</li>
                    <li>Anxiety symptoms</li>
                    <li>Mood patterns</li>
                    <li>Sleep quality</li>
                    <li>Focus and concentration</li>
                  </ul>
                  <p className="text-sm text-gray-500 mt-4">
                    Note: This assessment is not a diagnostic tool. If you're experiencing severe symptoms, please consult a healthcare professional.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">{currentQuestion.text}</h3>
                    <div className="space-y-2">
                      {currentQuestion.options.map((option) => (
                        <Button
                          key={option.value}
                          variant="outline"
                          className="w-full justify-start text-left h-auto py-3 px-4"
                          onClick={() => handleAnswer(option.value)}
                        >
                          {option.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                  <div className="pt-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
                      <span>{Math.round(assessmentProgress)}% complete</span>
                    </div>
                    <Progress value={assessmentProgress} className="h-2" />
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-center">
              {!assessmentStarted && (
                <Button 
                  onClick={startAssessment}
                  className="bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600"
                >
                  Begin Assessment
                </Button>
              )}
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="results">
          {mentalHealthScore && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="max-w-3xl mx-auto mb-8">
                <CardHeader>
                  <CardTitle className="text-xl text-center">Your Mental Wellness Profile</CardTitle>
                  <CardDescription className="text-center">
                    Based on your responses, here's an overview of your current mental wellbeing
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center mb-6">
                    <div className="relative inline-flex items-center justify-center">
                      <svg className="w-32 h-32">
                        <circle
                          cx="64"
                          cy="64"
                          r="60"
                          fill="none"
                          stroke="#e2e8f0"
                          strokeWidth="8"
                        />
                        <circle
                          cx="64"
                          cy="64"
                          r="60"
                          fill="none"
                          stroke={`${
                            mentalHealthScore.overall < 40 ? "#ef4444" :
                            mentalHealthScore.overall < 60 ? "#f59e0b" :
                            mentalHealthScore.overall < 80 ? "#3b82f6" : "#22c55e"
                          }`}
                          strokeWidth="8"
                          strokeDasharray={`${mentalHealthScore.overall * 3.77} 377`}
                          strokeDashoffset="0"
                          strokeLinecap="round"
                          transform="rotate(-90 64 64)"
                        />
                      </svg>
                      <div className="absolute flex flex-col items-center justify-center">
                        <span className="text-4xl font-bold">{mentalHealthScore.overall}</span>
                        <span className="text-sm text-gray-500">Overall Score</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Stress Management</span>
                        <span>{mentalHealthScore.stress}/100</span>
                      </div>
                      <Progress value={mentalHealthScore.stress} className={`h-2 ${getProgressColor(mentalHealthScore.stress)}`} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Anxiety Level</span>
                        <span>{mentalHealthScore.anxiety}/100</span>
                      </div>
                      <Progress value={mentalHealthScore.anxiety} className={`h-2 ${getProgressColor(mentalHealthScore.anxiety)}`} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Mood Balance</span>
                        <span>{mentalHealthScore.mood}/100</span>
                      </div>
                      <Progress value={mentalHealthScore.mood} className={`h-2 ${getProgressColor(mentalHealthScore.mood)}`} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Sleep Quality</span>
                        <span>{mentalHealthScore.sleep}/100</span>
                      </div>
                      <Progress value={mentalHealthScore.sleep} className={`h-2 ${getProgressColor(mentalHealthScore.sleep)}`} />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <div className="flex justify-between items-center">
                        <span>Focus & Concentration</span>
                        <span>{mentalHealthScore.focus}/100</span>
                      </div>
                      <Progress value={mentalHealthScore.focus} className={`h-2 ${getProgressColor(mentalHealthScore.focus)}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="max-w-3xl mx-auto">
                <CardHeader>
                  <CardTitle>Personalized Recommendations</CardTitle>
                  <CardDescription>Based on your assessment, here are some strategies to improve your mental wellbeing</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {mentalHealthScore.recommendations.map((recommendation, index) => (
                      <li key={index} className="flex items-start">
                        <div className="flex-shrink-0 w-5 h-5 rounded-full bg-green-100 flex items-center justify-center mt-0.5 mr-3">
                          <span className="text-green-600 text-xs">✓</span>
                        </div>
                        <span>{recommendation}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={resetAssessment}>Retake Assessment</Button>
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600">
                    Save Results
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}