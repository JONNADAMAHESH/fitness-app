import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format } from "date-fns";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date): string {
  return format(date, "EEEE, MMMM d");
}

export function calculateCalorieNeeds(
  weight: number,
  height: number,
  age: number,
  gender: "male" | "female",
  activityLevel: "sedentary" | "light" | "moderate" | "active" | "veryActive"
): number {
  // Harris-Benedict Equation
  let bmr = 0;
  
  if (gender === "male") {
    bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
  } else {
    bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
  }
  
  // Activity multipliers
  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    veryActive: 1.9,
  };
  
  return Math.round(bmr * activityMultipliers[activityLevel]);
}

export function calculateBMI(weight: number, height: number): number {
  // height in cm, weight in kg
  const heightInMeters = height / 100;
  return Number((weight / (heightInMeters * heightInMeters)).toFixed(1));
}

export function getAgeGroup(age: number): string {
  if (age >= 18 && age <= 35) {
    return "18-35";
  } else if (age > 35 && age <= 90) {
    return "35-90";
  } else {
    return "all";
  }
}

export const bodyParts = [
  "chest",
  "back",
  "shoulders",
  "biceps",
  "triceps",
  "forearms",
  "abs",
  "quads",
  "hamstrings",
  "glutes",
  "calves",
  "neck",
  "eyes",
  "hands",
  "knees",
];

export const fitnessLevels = [
  { value: "beginner", label: "Beginner" },
  { value: "intermediate", label: "Intermediate" },
  { value: "advanced", label: "Advanced" },
];

export const fitnessGoals = [
  { value: "lose_weight", label: "Lose Weight" },
  { value: "gain_muscle", label: "Gain Muscle" },
  { value: "improve_fitness", label: "Improve Fitness" },
  { value: "increase_flexibility", label: "Increase Flexibility" },
  { value: "reduce_stress", label: "Reduce Stress" },
];
