import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import Header from "@/components/Header";
import BottomNavigation from "@/components/BottomNavigation";
import Home from "@/pages/Home";
import Profile from "@/pages/Profile";
import Workout from "@/pages/Workout";
import Nutrition from "@/pages/Nutrition";
import Yoga from "@/pages/Yoga";
import Sleep from "@/pages/Sleep";
import Explore from "@/pages/Explore";
import AIWorkout from "@/pages/AIWorkout";
import AINutrition from "@/pages/AINutrition";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";
import { useState, useEffect } from "react";
import OnboardingForm from "./components/OnboardingForm";

// Advanced health feature imports
import MentalHealth from "@/pages/MentalHealth";
import SleepAnalytics from "@/pages/SleepAnalytics";
import CognitiveTraining from "@/pages/CognitiveTraining";
import GuidedMeditation from "@/pages/GuidedMeditation";
import Biofeedback from "@/pages/Biofeedback";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Home} />
      <ProtectedRoute path="/profile" component={Profile} />
      <ProtectedRoute path="/workout" component={Workout} />
      <ProtectedRoute path="/nutrition" component={Nutrition} />
      <ProtectedRoute path="/yoga" component={Yoga} />
      <ProtectedRoute path="/sleep" component={Sleep} />
      <ProtectedRoute path="/explore" component={Explore} />
      <ProtectedRoute path="/ai-workout" component={AIWorkout} />
      <ProtectedRoute path="/ai-nutrition" component={AINutrition} />
      
      {/* Advanced health feature routes */}
      <ProtectedRoute path="/mental-health" component={MentalHealth} />
      <ProtectedRoute path="/sleep-analytics" component={SleepAnalytics} />
      <ProtectedRoute path="/cognitive-training" component={CognitiveTraining} />
      <ProtectedRoute path="/guided-meditation" component={GuidedMeditation} />
      <ProtectedRoute path="/biofeedback" component={Biofeedback} />
      
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isFirstVisit, setIsFirstVisit] = useState(true);
  const [onboardingComplete, setOnboardingComplete] = useState(false);

  useEffect(() => {
    const hasVisited = localStorage.getItem("hasVisited");
    if (hasVisited) {
      setIsFirstVisit(false);
      setOnboardingComplete(true);
    }
  }, []);

  const completeOnboarding = () => {
    localStorage.setItem("hasVisited", "true");
    setOnboardingComplete(true);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          {!onboardingComplete ? (
            <OnboardingForm onComplete={completeOnboarding} />
          ) : (
            <div className="flex flex-col min-h-screen">
              <Header />
              <div className="flex-grow">
                <Router />
              </div>
              <BottomNavigation />
              <Toaster />
            </div>
          )}
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
