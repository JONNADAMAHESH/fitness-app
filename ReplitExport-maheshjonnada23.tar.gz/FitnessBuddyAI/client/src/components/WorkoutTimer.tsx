import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Play, Pause, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface WorkoutTimerProps {
  initialDuration: number; // in seconds
  exerciseName: string;
  onComplete?: () => void;
}

export function WorkoutTimer({ initialDuration, exerciseName, onComplete }: WorkoutTimerProps) {
  const [timeLeft, setTimeLeft] = useState<number>(initialDuration);
  const [isActive, setIsActive] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Format time as mm:ss
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Calculate percentage complete
  const percentComplete = ((initialDuration - timeLeft) / initialDuration) * 100;

  useEffect(() => {
    if (isActive && !isPaused) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prevTime) => {
          if (prevTime <= 1) {
            clearInterval(intervalRef.current as NodeJS.Timeout);
            setIsActive(false);
            if (onComplete) onComplete();
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
    } else if (isPaused && intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isActive, isPaused, onComplete]);

  const startTimer = () => {
    setIsActive(true);
    setIsPaused(false);
  };

  const pauseTimer = () => {
    setIsPaused(true);
  };

  const resetTimer = () => {
    setIsActive(false);
    setIsPaused(false);
    setTimeLeft(initialDuration);
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl">{exerciseName}</CardTitle>
        <CardDescription>Workout Timer</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center space-y-6">
          <motion.div 
            className="text-5xl font-semibold"
            key={timeLeft}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {formatTime(timeLeft)}
          </motion.div>
          
          <Progress value={percentComplete} className="w-full h-2" />
          
          <div className="flex space-x-3">
            {!isActive || isPaused ? (
              <Button onClick={startTimer} size="lg" className="w-20">
                <Play className="mr-1 h-4 w-4" />
                {isPaused ? "Resume" : "Start"}
              </Button>
            ) : (
              <Button onClick={pauseTimer} size="lg" className="w-20" variant="secondary">
                <Pause className="mr-1 h-4 w-4" />
                Pause
              </Button>
            )}
            
            <Button onClick={resetTimer} size="lg" className="w-20" variant="outline">
              <RotateCcw className="mr-1 h-4 w-4" />
              Reset
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}