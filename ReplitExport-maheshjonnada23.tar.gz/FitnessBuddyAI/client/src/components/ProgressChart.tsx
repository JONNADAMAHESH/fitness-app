import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

interface DataPoint {
  date: string;
  value: number;
  target?: number;
}

interface ProgressChartProps {
  title: string;
  description: string;
  weekData: DataPoint[];
  monthData: DataPoint[];
  dataKey: string;
  targetKey?: string;
  unit: string;
  color: string;
}

export function ProgressChart({
  title,
  description,
  weekData,
  monthData,
  dataKey,
  targetKey,
  unit,
  color,
}: ProgressChartProps) {
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 shadow-md rounded-md border">
          <p className="font-semibold">{label}</p>
          <p className="text-sm text-gray-600">
            {payload[0].name}: {payload[0].value} {unit}
          </p>
          {payload.length > 1 && (
            <p className="text-sm text-gray-600">
              Target: {payload[1].value} {unit}
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="week">
          <TabsList className="mb-4">
            <TabsTrigger value="week">This Week</TabsTrigger>
            <TabsTrigger value="month">This Month</TabsTrigger>
          </TabsList>
          <TabsContent value="week" className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weekData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey={dataKey} 
                  name={dataKey} 
                  stroke={color} 
                  strokeWidth={2} 
                  dot={{ r: 4 }} 
                  activeDot={{ r: 8 }} 
                />
                {targetKey && (
                  <Line 
                    type="monotone" 
                    dataKey={targetKey} 
                    name="Target" 
                    stroke="#a3a3a3" 
                    strokeDasharray="5 5" 
                    strokeWidth={2}
                    dot={false}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          <TabsContent value="month" className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey={dataKey} name={dataKey} fill={color} barSize={10} radius={[4, 4, 0, 0]} />
                {targetKey && <Bar dataKey={targetKey} name="Target" fill="#a3a3a3" barSize={10} radius={[4, 4, 0, 0]} />}
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}