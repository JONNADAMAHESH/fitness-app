import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Bell, LogOut, Menu, X } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import feelfitIcon from "@/assets/feelfit-icon.svg";

const Header = () => {
  const [notifications, setNotifications] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  // Don't show header on auth page
  if (location === "/auth") {
    return null;
  }

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Get user initials for avatar
  const getInitials = () => {
    if (!user?.name) return "?";
    const names = user.name.split(" ");
    if (names.length >= 2) {
      return `${names[0][0]}${names[1][0]}`.toUpperCase();
    }
    return names[0][0].toUpperCase();
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/">
          <div className="flex items-center space-x-2 cursor-pointer">
            <img src={feelfitIcon} alt="FeelFit Logo" className="h-9 w-9" />
            <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-500 text-transparent bg-clip-text">
              FeelFit
            </h1>
          </div>
        </Link>
        
        {/* Mobile menu button */}
        <div className="md:hidden">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
        
        {/* Desktop navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/">
            <Button variant="link" className={location === "/" ? "text-primary font-bold" : ""}>
              Home
            </Button>
          </Link>
          <Link href="/workout">
            <Button variant="link" className={location === "/workout" ? "text-primary font-bold" : ""}>
              Workouts
            </Button>
          </Link>
          <Link href="/nutrition">
            <Button variant="link" className={location === "/nutrition" ? "text-primary font-bold" : ""}>
              Nutrition
            </Button>
          </Link>
          <Link href="/yoga">
            <Button variant="link" className={location === "/yoga" ? "text-primary font-bold" : ""}>
              Yoga
            </Button>
          </Link>
          <Link href="/explore">
            <Button variant="link" className={location === "/explore" ? "text-primary font-bold" : ""}>
              Explore
            </Button>
          </Link>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="text-gray-500 hover:text-primary relative">
            <Bell className="h-6 w-6" />
            {notifications > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                {notifications}
              </span>
            )}
          </button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <div className="rounded-full h-8 w-8 bg-primary text-white font-bold flex items-center justify-center cursor-pointer">
                {getInitials()}
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <Link href="/profile">
                <DropdownMenuItem>
                  Profile
                </DropdownMenuItem>
              </Link>
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Logout</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t">
          <div className="flex flex-col py-2">
            <Link href="/">
              <Button 
                variant="ghost" 
                className={`justify-start w-full ${location === "/" ? "text-primary font-bold" : ""}`}
              >
                Home
              </Button>
            </Link>
            <Link href="/workout">
              <Button 
                variant="ghost" 
                className={`justify-start w-full ${location === "/workout" ? "text-primary font-bold" : ""}`}
              >
                Workouts
              </Button>
            </Link>
            <Link href="/nutrition">
              <Button 
                variant="ghost" 
                className={`justify-start w-full ${location === "/nutrition" ? "text-primary font-bold" : ""}`}
              >
                Nutrition
              </Button>
            </Link>
            <Link href="/yoga">
              <Button 
                variant="ghost" 
                className={`justify-start w-full ${location === "/yoga" ? "text-primary font-bold" : ""}`}
              >
                Yoga
              </Button>
            </Link>
            <Link href="/explore">
              <Button 
                variant="ghost" 
                className={`justify-start w-full ${location === "/explore" ? "text-primary font-bold" : ""}`}
              >
                Explore
              </Button>
            </Link>
            <Link href="/profile">
              <Button 
                variant="ghost" 
                className={`justify-start w-full ${location === "/profile" ? "text-primary font-bold" : ""}`}
              >
                Profile
              </Button>
            </Link>
            <Button 
              variant="ghost" 
              className="justify-start w-full text-red-500"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
