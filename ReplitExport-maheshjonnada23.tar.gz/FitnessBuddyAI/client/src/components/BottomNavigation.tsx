import { useLocation, Link } from "wouter";
import { Home, Dumbbell, Pizza, Compass, User } from "lucide-react";

const BottomNavigation = () => {
  const [location] = useLocation();
  
  // Don't show bottom navigation on auth page
  if (location === "/auth") {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-2 px-6 z-40 md:hidden">
      <nav className="flex justify-between items-center">
        <Link href="/">
          <div className={`flex flex-col items-center ${location === '/' ? 'text-primary' : 'text-gray-500 hover:text-primary'} cursor-pointer`}>
            <Home className="h-6 w-6" />
            <span className="text-xs mt-1">Home</span>
          </div>
        </Link>
        <Link href="/workout">
          <div className={`flex flex-col items-center ${location === '/workout' ? 'text-primary' : 'text-gray-500 hover:text-primary'} cursor-pointer`}>
            <Dumbbell className="h-6 w-6" />
            <span className="text-xs mt-1">Workouts</span>
          </div>
        </Link>
        <Link href="/nutrition">
          <div className={`flex flex-col items-center ${location === '/nutrition' ? 'text-primary' : 'text-gray-500 hover:text-primary'} cursor-pointer`}>
            <Pizza className="h-6 w-6" />
            <span className="text-xs mt-1">Nutrition</span>
          </div>
        </Link>
        <Link href="/yoga">
          <div className={`flex flex-col items-center ${location === '/yoga' ? 'text-primary' : 'text-gray-500 hover:text-primary'} cursor-pointer`}>
            <Compass className="h-6 w-6" />
            <span className="text-xs mt-1">Yoga</span>
          </div>
        </Link>
        <Link href="/profile">
          <div className={`flex flex-col items-center ${location === '/profile' ? 'text-primary' : 'text-gray-500 hover:text-primary'} cursor-pointer`}>
            <User className="h-6 w-6" />
            <span className="text-xs mt-1">Profile</span>
          </div>
        </Link>
      </nav>
    </div>
  );
};

export default BottomNavigation;
