import { Play } from "lucide-react";

type ExerciseItemProps = {
  icon: React.ReactNode;
  name: string;
  details: string;
  onWatch?: () => void;
  showBorder?: boolean;
};

const ExerciseItem = ({
  icon,
  name,
  details,
  onWatch,
  showBorder = true,
}: ExerciseItemProps) => {
  return (
    <div className={`flex items-center ${showBorder ? 'border-b border-gray-100 pb-4' : ''}`}>
      <div className="bg-primary-light/10 rounded-lg h-12 w-12 flex items-center justify-center mr-4">
        {icon}
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-start">
          <div>
            <h4 className="font-medium text-gray-900">{name}</h4>
            <p className="text-gray-500 text-sm">{details}</p>
          </div>
          {onWatch && (
            <button className="text-primary" onClick={onWatch}>
              <Play className="h-5 w-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExerciseItem;
