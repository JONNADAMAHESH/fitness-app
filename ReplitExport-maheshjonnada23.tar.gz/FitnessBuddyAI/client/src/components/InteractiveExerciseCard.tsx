import React, { useState } from "react";
import { motion } from "framer-motion";
import { Play, ChevronDown, ChevronUp, Clock, Dumbbell, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ExerciseStep {
  text: string;
}

interface ExerciseProps {
  id: number;
  name: string;
  description: string;
  bodyPart: string;
  difficulty: string;
  sets: number;
  reps: number;
  restTime: number;
  instructionsSteps: ExerciseStep[] | string[];
  imageUrl?: string;
  videoUrl?: string;
  onStartExercise: (exerciseId: number) => void;
}

export function InteractiveExerciseCard({
  id,
  name,
  description,
  bodyPart,
  difficulty,
  sets,
  reps,
  restTime,
  instructionsSteps,
  imageUrl,
  videoUrl,
  onStartExercise,
}: ExerciseProps) {
  const [expanded, setExpanded] = useState(false);
  
  // Format the instruction steps
  const formattedSteps = instructionsSteps.map((step) => {
    if (typeof step === 'string') {
      return { text: step };
    }
    return step;
  });

  // Get difficulty color
  const getDifficultyColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'beginner':
        return 'bg-green-100 text-green-800';
      case 'intermediate':
        return 'bg-blue-100 text-blue-800';
      case 'advanced':
        return 'bg-orange-100 text-orange-800';
      case 'expert':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl font-bold">{name}</CardTitle>
            <div className="flex gap-2 mt-2">
              <Badge variant="outline" className={getDifficultyColor(difficulty)}>
                {difficulty}
              </Badge>
              <Badge variant="outline">{bodyPart}</Badge>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setExpanded(!expanded)}
            aria-label={expanded ? "Collapse" : "Expand"}
          >
            {expanded ? (
              <ChevronUp className="h-5 w-5" />
            ) : (
              <ChevronDown className="h-5 w-5" />
            )}
          </Button>
        </div>
      </CardHeader>

      <CardContent className="pb-3">
        <div className="flex items-center gap-6 my-3">
          <div className="flex items-center">
            <Dumbbell className="mr-2 h-4 w-4 text-primary" />
            <span>
              <span className="font-semibold">{sets}</span> sets × <span className="font-semibold">{reps}</span> reps
            </span>
          </div>
          <div className="flex items-center">
            <Clock className="mr-2 h-4 w-4 text-primary" />
            <span>
              <span className="font-semibold">{restTime}s</span> rest
            </span>
          </div>
        </div>

        {imageUrl && (
          <div className="mb-4 rounded-md overflow-hidden">
            <img 
              src={imageUrl} 
              alt={name} 
              className="w-full h-48 object-cover"
            />
          </div>
        )}

        <p className="text-sm text-gray-600 mb-4">{description}</p>

        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="mt-4"
          >
            <h4 className="font-semibold mb-2">Instructions:</h4>
            <ol className="list-decimal pl-5 space-y-2">
              {formattedSteps.map((step, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-sm"
                >
                  {step.text}
                </motion.li>
              ))}
            </ol>

            {videoUrl && (
              <div className="mt-4">
                <h4 className="font-semibold mb-2">Video Demonstration:</h4>
                <div className="rounded-md overflow-hidden bg-gray-100 h-48 flex items-center justify-center">
                  <Play className="h-12 w-12 text-primary" />
                </div>
              </div>
            )}
          </motion.div>
        )}
      </CardContent>

      <CardFooter className="pt-0">
        <Button 
          onClick={() => onStartExercise(id)} 
          className="w-full"
        >
          <Play className="mr-2 h-4 w-4" />
          Start Exercise
        </Button>
      </CardFooter>
    </Card>
  );
}