import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AIWorkoutGeneratorProps {
  onWorkoutGenerated?: (workout: any) => void;
}

export function AIWorkoutGenerator({ onWorkoutGenerated }: AIWorkoutGeneratorProps) {
  const { toast } = useToast();
  const [age, setAge] = useState<number>(30);
  const [fitnessLevel, setFitnessLevel] = useState<string>("intermediate");
  const [selectedBodyParts, setSelectedBodyParts] = useState<string[]>([]);
  const [goals, setGoals] = useState<string[]>([]);
  const [height, setHeight] = useState<number | undefined>();
  const [weight, setWeight] = useState<number | undefined>();

  const bodyPartOptions = [
    { id: "chest", label: "Chest" },
    { id: "back", label: "Back" },
    { id: "shoulders", label: "Shoulders" },
    { id: "arms", label: "Arms" },
    { id: "legs", label: "Legs" },
    { id: "core", label: "Core" },
    { id: "neck", label: "Neck" },
    { id: "eyes", label: "Eyes" },
    { id: "hands", label: "Hands" },
    { id: "knees", label: "Knees" },
  ];

  const goalOptions = [
    { id: "strength", label: "Strength" },
    { id: "muscle_growth", label: "Muscle Growth" },
    { id: "endurance", label: "Endurance" },
    { id: "weight_loss", label: "Weight Loss" },
    { id: "flexibility", label: "Flexibility" },
    { id: "rehabilitation", label: "Rehabilitation" },
  ];

  const toggleBodyPart = (bodyPart: string) => {
    setSelectedBodyParts((prev) =>
      prev.includes(bodyPart)
        ? prev.filter((part) => part !== bodyPart)
        : [...prev, bodyPart]
    );
  };

  const toggleGoal = (goal: string) => {
    setGoals((prev) =>
      prev.includes(goal)
        ? prev.filter((g) => g !== goal)
        : [...prev, goal]
    );
  };

  const generateWorkoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/workout-plan", {
        userId: 1, // Placeholder - would come from authenticated user
        age,
        fitnessLevel,
        bodyParts: selectedBodyParts,
        goals,
        height,
        weight,
      });
      
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Workout plan generated!",
        description: "Your custom workout plan is ready",
      });
      
      if (onWorkoutGenerated) {
        onWorkoutGenerated(data);
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to generate workout plan",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedBodyParts.length === 0) {
      toast({
        title: "Please select body parts",
        description: "Select at least one body part to target",
        variant: "destructive",
      });
      return;
    }
    
    if (goals.length === 0) {
      toast({
        title: "Please select goals",
        description: "Select at least one fitness goal",
        variant: "destructive",
      });
      return;
    }
    
    generateWorkoutMutation.mutate();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent">
            AI Workout Plan Generator
          </CardTitle>
          <CardDescription>
            Create a personalized workout plan tailored to your specific needs using our AI technology
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Your age"
                    value={age}
                    onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                    min={18}
                    max={90}
                  />
                </div>
                
                <div>
                  <Label htmlFor="fitness-level">Fitness Level</Label>
                  <Select
                    value={fitnessLevel}
                    onValueChange={setFitnessLevel}
                  >
                    <SelectTrigger id="fitness-level">
                      <SelectValue placeholder="Select your fitness level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                      <SelectItem value="athletic">Athletic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Optional"
                      value={height || ""}
                      onChange={(e) => setHeight(e.target.value ? parseInt(e.target.value) : undefined)}
                      min={100}
                      max={250}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder="Optional"
                      value={weight || ""}
                      onChange={(e) => setWeight(e.target.value ? parseInt(e.target.value) : undefined)}
                      min={30}
                      max={200}
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-base">Target Body Parts</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {bodyPartOptions.map((option) => (
                      <div key={option.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`body-part-${option.id}`}
                          checked={selectedBodyParts.includes(option.id)}
                          onCheckedChange={() => toggleBodyPart(option.id)}
                        />
                        <label
                          htmlFor={`body-part-${option.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {option.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <Label className="text-base">Fitness Goals</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {goalOptions.map((option) => (
                      <div key={option.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`goal-${option.id}`}
                          checked={goals.includes(option.id)}
                          onCheckedChange={() => toggleGoal(option.id)}
                        />
                        <label
                          htmlFor={`goal-${option.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {option.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </form>
        </CardContent>
        <CardFooter>
          <Button 
            type="submit" 
            className="w-full" 
            size="lg"
            onClick={handleSubmit}
            disabled={generateWorkoutMutation.isPending}
          >
            {generateWorkoutMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                Generating Plan...
              </>
            ) : (
              "Generate Workout Plan"
            )}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}