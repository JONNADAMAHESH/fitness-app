import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Utensils, Apple, Pill, HeartPulse, Leaf, ChevronDown, ChevronUp, Info } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface FoodItem {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface Meal {
  name: string;
  foods: FoodItem[];
}

interface Supplement {
  name: string;
  dosage: string;
  timing: string;
  benefits: string[];
}

interface AINutritionPlan {
  name: string;
  description: string;
  goal: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  meals: Meal[];
  supplements?: Supplement[];
  ageGroup: string;
}

interface AINutritionDisplayProps {
  nutritionPlan: AINutritionPlan;
  onSave?: () => void;
  onRegenerate?: () => void;
}

export function AINutritionDisplay({ nutritionPlan, onSave, onRegenerate }: AINutritionDisplayProps) {
  const [activeTab, setActiveTab] = useState("overview");

  if (!nutritionPlan) {
    return null;
  }

  const goalColor: Record<string, string> = {
    weight_loss: "bg-blue-100 text-blue-800",
    muscle_gain: "bg-purple-100 text-purple-800", 
    endurance: "bg-orange-100 text-orange-800",
    flexibility: "bg-teal-100 text-teal-800",
    overall_fitness: "bg-green-100 text-green-800",
    maintenance: "bg-gray-100 text-gray-800"
  };

  const goalLabel: Record<string, string> = {
    weight_loss: "Weight Loss",
    muscle_gain: "Muscle Gain",
    endurance: "Endurance",
    flexibility: "Flexibility", 
    overall_fitness: "Overall Fitness",
    maintenance: "Maintenance"
  };

  const ageGroupLabel = nutritionPlan.ageGroup === "18-35" ? "Young Adult" : 
                        nutritionPlan.ageGroup === "35-90" ? "Senior Adult" : "All Ages";

  const totalCalories = nutritionPlan.calories;
  const proteinCalories = nutritionPlan.protein * 4; // 4 calories per gram
  const carbsCalories = nutritionPlan.carbs * 4; // 4 calories per gram
  const fatCalories = nutritionPlan.fat * 9; // 9 calories per gram

  const proteinPercent = Math.round((proteinCalories / totalCalories) * 100);
  const carbsPercent = Math.round((carbsCalories / totalCalories) * 100);
  const fatPercent = Math.round((fatCalories / totalCalories) * 100);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="mt-6"
      >
        <Card className="w-full max-w-4xl mx-auto overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-green-500 to-teal-600 text-white">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl font-bold">{nutritionPlan.name}</CardTitle>
                <CardDescription className="text-gray-100 mt-1">
                  {nutritionPlan.description}
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Badge variant="outline" className="border-white text-white hover:bg-white/10">
                  {ageGroupLabel}
                </Badge>
                <Badge className={`${goalColor[nutritionPlan.goal]} bg-opacity-20 text-white border-white hover:bg-white/10`}>
                  {goalLabel[nutritionPlan.goal] || nutritionPlan.goal}
                </Badge>
              </div>
            </div>
          </CardHeader>
          
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 w-full rounded-none">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="meals">Meal Plan</TabsTrigger>
              {nutritionPlan.supplements && nutritionPlan.supplements.length > 0 && (
                <TabsTrigger value="supplements">Supplements</TabsTrigger>
              )}
            </TabsList>
            
            <TabsContent value="overview" className="pt-4">
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex flex-col items-center p-4 bg-gray-50 rounded-lg">
                    <HeartPulse className="h-8 w-8 text-red-500 mb-2" />
                    <p className="text-sm text-gray-500">Daily Calories</p>
                    <p className="text-xl font-bold">{nutritionPlan.calories} kcal</p>
                  </div>
                  
                  <div className="flex flex-col items-center p-4 bg-gray-50 rounded-lg">
                    <Utensils className="h-8 w-8 text-indigo-500 mb-2" />
                    <p className="text-sm text-gray-500">Meals</p>
                    <p className="text-xl font-bold">{nutritionPlan.meals.length} per day</p>
                  </div>
                  
                  <div className="flex flex-col items-center p-4 bg-gray-50 rounded-lg">
                    {nutritionPlan.supplements && nutritionPlan.supplements.length > 0 ? (
                      <>
                        <Pill className="h-8 w-8 text-purple-500 mb-2" />
                        <p className="text-sm text-gray-500">Supplements</p>
                        <p className="text-xl font-bold">{nutritionPlan.supplements.length}</p>
                      </>
                    ) : (
                      <>
                        <Leaf className="h-8 w-8 text-green-500 mb-2" />
                        <p className="text-sm text-gray-500">Focus</p>
                        <p className="text-xl font-bold">Whole Foods</p>
                      </>
                    )}
                  </div>
                </div>
                
                <div className="mt-8">
                  <h3 className="text-lg font-medium">Macronutrient Breakdown</h3>
                  
                  <div className="mt-4 space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <div className="flex items-center">
                          <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                          <span>Protein</span>
                        </div>
                        <span>{nutritionPlan.protein}g ({proteinPercent}%)</span>
                      </div>
                      <Progress value={proteinPercent} className="h-2 bg-gray-100" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <div className="flex items-center">
                          <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                          <span>Carbs</span>
                        </div>
                        <span>{nutritionPlan.carbs}g ({carbsPercent}%)</span>
                      </div>
                      <Progress value={carbsPercent} className="h-2 bg-gray-100" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <div className="flex items-center">
                          <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                          <span>Fat</span>
                        </div>
                        <span>{nutritionPlan.fat}g ({fatPercent}%)</span>
                      </div>
                      <Progress value={fatPercent} className="h-2 bg-gray-100" />
                    </div>
                  </div>
                </div>
                
                <div className="mt-8">
                  <h3 className="text-lg font-medium">Plan Overview</h3>
                  <p className="text-gray-600 mt-2">{nutritionPlan.description}</p>
                </div>
              </CardContent>
            </TabsContent>
            
            <TabsContent value="meals" className="pt-4">
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {nutritionPlan.meals.map((meal, index) => {
                    const mealTotalCalories = meal.foods.reduce((acc, food) => acc + food.calories, 0);
                    const mealTotalProtein = meal.foods.reduce((acc, food) => acc + food.protein, 0);
                    const mealTotalCarbs = meal.foods.reduce((acc, food) => acc + food.carbs, 0);
                    const mealTotalFat = meal.foods.reduce((acc, food) => acc + food.fat, 0);
                    
                    return (
                      <AccordionItem key={index} value={`meal-${index}`}>
                        <AccordionTrigger className="hover:bg-gray-50 px-4 py-2 rounded-md">
                          <div className="flex items-center justify-between w-full">
                            <span className="font-medium">{meal.name}</span>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{mealTotalCalories} kcal</Badge>
                              <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
                                {mealTotalProtein}g P
                              </Badge>
                              <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                                {mealTotalCarbs}g C
                              </Badge>
                              <Badge variant="outline" className="bg-yellow-50 text-yellow-600 border-yellow-200">
                                {mealTotalFat}g F
                              </Badge>
                            </div>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="px-4">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Food</TableHead>
                                <TableHead className="text-right">Calories</TableHead>
                                <TableHead className="text-right">Protein</TableHead>
                                <TableHead className="text-right">Carbs</TableHead>
                                <TableHead className="text-right">Fat</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {meal.foods.map((food, foodIndex) => (
                                <TableRow key={foodIndex}>
                                  <TableCell className="font-medium">{food.name}</TableCell>
                                  <TableCell className="text-right">{food.calories} kcal</TableCell>
                                  <TableCell className="text-right">{food.protein}g</TableCell>
                                  <TableCell className="text-right">{food.carbs}g</TableCell>
                                  <TableCell className="text-right">{food.fat}g</TableCell>
                                </TableRow>
                              ))}
                              <TableRow className="bg-gray-50">
                                <TableCell className="font-bold">Meal Total</TableCell>
                                <TableCell className="text-right font-bold">{mealTotalCalories} kcal</TableCell>
                                <TableCell className="text-right font-bold">{mealTotalProtein}g</TableCell>
                                <TableCell className="text-right font-bold">{mealTotalCarbs}g</TableCell>
                                <TableCell className="text-right font-bold">{mealTotalFat}g</TableCell>
                              </TableRow>
                            </TableBody>
                          </Table>
                        </AccordionContent>
                      </AccordionItem>
                    );
                  })}
                </Accordion>
              </CardContent>
            </TabsContent>
            
            {nutritionPlan.supplements && nutritionPlan.supplements.length > 0 && (
              <TabsContent value="supplements" className="pt-4">
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    {nutritionPlan.supplements.map((supplement, index) => (
                      <AccordionItem key={index} value={`supplement-${index}`}>
                        <AccordionTrigger className="hover:bg-gray-50 px-4 py-2 rounded-md">
                          <div className="flex items-center justify-between w-full">
                            <span className="font-medium">{supplement.name}</span>
                            <Badge variant="outline" className="bg-purple-50 text-purple-600 border-purple-200">
                              {supplement.timing}
                            </Badge>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="px-4 space-y-3">
                          <div>
                            <h4 className="text-sm font-medium text-gray-500">Dosage</h4>
                            <p>{supplement.dosage}</p>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500">Timing</h4>
                            <p>{supplement.timing}</p>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500">Benefits</h4>
                            <ul className="list-disc pl-5 space-y-1">
                              {supplement.benefits.map((benefit, benefitIndex) => (
                                <li key={benefitIndex} className="text-sm">{benefit}</li>
                              ))}
                            </ul>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </TabsContent>
            )}
          </Tabs>
          
          <CardFooter className="flex justify-between border-t p-4 bg-gray-50">
            <Button
              variant="outline"
              onClick={onRegenerate}
            >
              Regenerate
            </Button>
            
            <Button 
              onClick={onSave}
              className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700"
            >
              Save Nutrition Plan
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}