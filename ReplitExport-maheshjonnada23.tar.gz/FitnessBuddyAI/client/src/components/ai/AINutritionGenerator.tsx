import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AINutritionGeneratorProps {
  onNutritionGenerated?: (nutritionPlan: any) => void;
}

export function AINutritionGenerator({ onNutritionGenerated }: AINutritionGeneratorProps) {
  const { toast } = useToast();
  const [age, setAge] = useState<number>(30);
  const [weight, setWeight] = useState<number>(70);
  const [height, setHeight] = useState<number>(170);
  const [gender, setGender] = useState<string>("not_specified");
  const [fitnessGoals, setFitnessGoals] = useState<string>("muscle_gain");
  const [activityLevel, setActivityLevel] = useState<string>("moderate");
  const [selectedDietaryRestrictions, setSelectedDietaryRestrictions] = useState<string[]>([]);
  const [includeSupplements, setIncludeSupplements] = useState<boolean>(false);

  const dietaryRestrictionOptions = [
    { id: "vegetarian", label: "Vegetarian" },
    { id: "vegan", label: "Vegan" },
    { id: "gluten_free", label: "Gluten Free" },
    { id: "dairy_free", label: "Dairy Free" },
    { id: "nut_free", label: "Nut Free" },
    { id: "keto", label: "Keto" },
    { id: "paleo", label: "Paleo" },
    { id: "low_carb", label: "Low Carb" },
  ];

  const toggleDietaryRestriction = (restriction: string) => {
    setSelectedDietaryRestrictions((prev) =>
      prev.includes(restriction)
        ? prev.filter((r) => r !== restriction)
        : [...prev, restriction]
    );
  };

  const generateNutritionMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/nutrition-plan", {
        age,
        weight,
        height,
        gender: gender !== "not_specified" ? gender : undefined,
        fitnessGoals,
        activityLevel,
        dietaryRestrictions: selectedDietaryRestrictions.length > 0 ? selectedDietaryRestrictions : undefined,
        includeSupplements
      });
      
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Nutrition plan generated!",
        description: "Your custom nutrition plan is ready",
      });
      
      if (onNutritionGenerated) {
        onNutritionGenerated(data);
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to generate nutrition plan",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    generateNutritionMutation.mutate();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-green-500 to-teal-600 bg-clip-text text-transparent">
            AI Nutrition Plan Generator
          </CardTitle>
          <CardDescription>
            Create a personalized nutrition plan tailored to your specific needs, dietary preferences, and fitness goals
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Your age"
                      value={age}
                      onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                      min={18}
                      max={90}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder="Weight"
                      value={weight}
                      onChange={(e) => setWeight(parseInt(e.target.value) || 0)}
                      min={30}
                      max={200}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Height"
                      value={height}
                      onChange={(e) => setHeight(parseInt(e.target.value) || 0)}
                      min={100}
                      max={250}
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="gender">Gender (Optional)</Label>
                  <Select
                    value={gender}
                    onValueChange={setGender}
                  >
                    <SelectTrigger id="gender">
                      <SelectValue placeholder="Select your gender (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="not_specified">Prefer not to say</SelectItem>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="non_binary">Non-binary</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="fitness-goals">Fitness Goals</Label>
                  <Select
                    value={fitnessGoals}
                    onValueChange={setFitnessGoals}
                  >
                    <SelectTrigger id="fitness-goals">
                      <SelectValue placeholder="Select your primary fitness goal" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weight_loss">Weight Loss</SelectItem>
                      <SelectItem value="muscle_gain">Muscle Gain</SelectItem>
                      <SelectItem value="endurance">Endurance</SelectItem>
                      <SelectItem value="overall_fitness">Overall Fitness</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="activity-level">Activity Level</Label>
                  <Select
                    value={activityLevel}
                    onValueChange={setActivityLevel}
                  >
                    <SelectTrigger id="activity-level">
                      <SelectValue placeholder="Select your activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                      <SelectItem value="light">Light (light exercise 1-3 days/week)</SelectItem>
                      <SelectItem value="moderate">Moderate (moderate exercise 3-5 days/week)</SelectItem>
                      <SelectItem value="active">Active (hard exercise 6-7 days/week)</SelectItem>
                      <SelectItem value="very_active">Very Active (very hard exercise & physical job)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-base">Dietary Restrictions</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {dietaryRestrictionOptions.map((option) => (
                      <div key={option.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`diet-${option.id}`}
                          checked={selectedDietaryRestrictions.includes(option.id)}
                          onCheckedChange={() => toggleDietaryRestriction(option.id)}
                        />
                        <label
                          htmlFor={`diet-${option.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {option.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 pt-4">
                  <Switch
                    id="include-supplements"
                    checked={includeSupplements}
                    onCheckedChange={setIncludeSupplements}
                  />
                  <Label htmlFor="include-supplements" className="cursor-pointer">
                    Include Supplement Recommendations
                  </Label>
                </div>
                
                <div className="p-4 bg-blue-50 rounded-lg mt-4">
                  <p className="text-sm text-blue-700">
                    <strong>Note:</strong> Your nutrition plan will include personalized macronutrient
                    targets, meal suggestions, and portion recommendations based on your goals and preferences.
                    {includeSupplements && " It will also include supplement suggestions to support your goals."}
                  </p>
                </div>
              </div>
            </div>
          </form>
        </CardContent>
        <CardFooter>
          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-green-500 to-teal-600" 
            size="lg"
            onClick={handleSubmit}
            disabled={generateNutritionMutation.isPending}
          >
            {generateNutritionMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                Generating Plan...
              </>
            ) : (
              "Generate Nutrition Plan"
            )}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}