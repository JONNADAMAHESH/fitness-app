import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Clock, Dumbbell, Flame, ChevronDown, ChevronUp, Info } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

// This is the type we expect from the API
interface WorkoutExercise {
  name: string;
  sets: number;
  reps: number;
  restTime: number;
  instructions: string;
}

interface AIWorkoutPlan {
  name: string;
  description: string;
  difficulty: string;
  targetBodyParts: string[];
  exercises: WorkoutExercise[];
  duration: number;
  calories: number;
  ageGroup: string;
}

interface AIWorkoutDisplayProps {
  workout: AIWorkoutPlan;
  onSave?: () => void;
  onRegenerate?: () => void;
}

export function AIWorkoutDisplay({ workout, onSave, onRegenerate }: AIWorkoutDisplayProps) {
  const [activeTab, setActiveTab] = useState("overview");

  if (!workout) {
    return null;
  }

  const difficultyColor = {
    beginner: "bg-green-100 text-green-800",
    intermediate: "bg-yellow-100 text-yellow-800",
    advanced: "bg-orange-100 text-orange-800",
    expert: "bg-red-100 text-red-800"
  }[workout.difficulty.toLowerCase()] || "bg-blue-100 text-blue-800";

  const ageGroupLabel = workout.ageGroup === "18-35" ? "Young Adult" : "Senior Adult";

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="mt-6"
      >
        <Card className="w-full max-w-4xl mx-auto overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl font-bold">{workout.name}</CardTitle>
                <CardDescription className="text-gray-100 mt-1">
                  {workout.description}
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Badge variant="outline" className="border-white text-white hover:bg-white/10">
                  {ageGroupLabel}
                </Badge>
                <Badge className={`${difficultyColor} bg-opacity-20 text-white border-white hover:bg-white/10`}>
                  {workout.difficulty}
                </Badge>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 mt-4">
              {workout.targetBodyParts.map((bodyPart) => (
                <Badge key={bodyPart} variant="secondary" className="bg-white/20 hover:bg-white/30">
                  {bodyPart}
                </Badge>
              ))}
            </div>
          </CardHeader>
          
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-2 w-full rounded-none">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="exercises">Exercises</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="pt-4">
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex flex-col items-center p-4 bg-gray-50 rounded-lg">
                    <Clock className="h-8 w-8 text-gray-500 mb-2" />
                    <p className="text-sm text-gray-500">Duration</p>
                    <p className="text-xl font-bold">{workout.duration} mins</p>
                  </div>
                  
                  <div className="flex flex-col items-center p-4 bg-gray-50 rounded-lg">
                    <Flame className="h-8 w-8 text-orange-500 mb-2" />
                    <p className="text-sm text-gray-500">Calories</p>
                    <p className="text-xl font-bold">{workout.calories} kcal</p>
                  </div>
                  
                  <div className="flex flex-col items-center p-4 bg-gray-50 rounded-lg">
                    <Dumbbell className="h-8 w-8 text-blue-500 mb-2" />
                    <p className="text-sm text-gray-500">Exercises</p>
                    <p className="text-xl font-bold">{workout.exercises.length}</p>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="text-lg font-medium">Workout Overview</h3>
                  <p className="text-gray-600 mt-2">{workout.description}</p>
                  
                  <div className="mt-4">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium">Intensity</span>
                      <span className="text-sm">{
                        workout.difficulty === "beginner" ? "40%" :
                        workout.difficulty === "intermediate" ? "65%" :
                        workout.difficulty === "advanced" ? "85%" : "95%"
                      }</span>
                    </div>
                    <Progress value={
                      workout.difficulty === "beginner" ? 40 :
                      workout.difficulty === "intermediate" ? 65 :
                      workout.difficulty === "advanced" ? 85 : 95
                    } className="h-2" />
                  </div>
                </div>
              </CardContent>
            </TabsContent>
            
            <TabsContent value="exercises" className="pt-4">
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {workout.exercises.map((exercise, index) => (
                    <AccordionItem key={index} value={`exercise-${index}`}>
                      <AccordionTrigger className="hover:bg-gray-50 px-4 py-2 rounded-md">
                        <div className="flex items-center">
                          <span className="font-medium">{exercise.name}</span>
                          <div className="ml-4 flex gap-2">
                            <Badge variant="outline">{exercise.sets} sets</Badge>
                            <Badge variant="outline">{exercise.reps} reps</Badge>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-4">
                        <div className="space-y-3">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm text-gray-500">Sets</p>
                              <p className="text-lg font-medium">{exercise.sets}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Reps</p>
                              <p className="text-lg font-medium">{exercise.reps}</p>
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm text-gray-500">Rest Time</p>
                            <p className="text-lg font-medium">{exercise.restTime} sec</p>
                          </div>
                          
                          <div>
                            <div className="flex items-center gap-1 mb-1">
                              <p className="text-sm text-gray-500">Instructions</p>
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Info className="h-3.5 w-3.5 text-gray-400" />
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p className="w-80">Follow these instructions carefully for proper form</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            </div>
                            <p className="text-sm">{exercise.instructions}</p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </TabsContent>
          </Tabs>
          
          <CardFooter className="flex justify-between border-t p-4 bg-gray-50">
            <Button
              variant="outline"
              onClick={onRegenerate}
            >
              Regenerate
            </Button>
            
            <Button 
              onClick={onSave}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              Save Workout
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}