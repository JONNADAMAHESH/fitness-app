import { useState } from "react";
import ExerciseItem from "./ExerciseItem";
import { Dumbbell, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type Exercise = {
  name: string;
  sets: number;
  reps: number;
  restTime: number;
};

type WorkoutPlanProps = {
  title: string;
  level: string;
  duration: number;
  calories: number;
  imageUrl: string;
  exercises: Exercise[];
  onStartWorkout: () => void;
  onCustomize: () => void;
};

const WorkoutPlan = ({
  title,
  level,
  duration,
  calories,
  imageUrl,
  exercises,
  onStartWorkout,
  onCustomize,
}: WorkoutPlanProps) => {
  const [activeDay, setActiveDay] = useState("Today");
  const [showExerciseModal, setShowExerciseModal] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);

  const daysOfWeek = [
    "Today",
    "Tomorrow",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];

  const handleWatchExercise = (exercise: Exercise) => {
    setSelectedExercise(exercise);
    setShowExerciseModal(true);
  };

  return (
    <>
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Your AI Workout Plan</h2>
          <button
            className="text-primary font-medium text-sm flex items-center"
            onClick={onCustomize}
          >
            Customize
            <ChevronRight className="h-4 w-4 ml-1" />
          </button>
        </div>

        <div className="relative h-48 rounded-xl overflow-hidden mb-4">
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-5">
            <h3 className="text-white text-xl font-bold">{title}</h3>
            <p className="text-white text-sm opacity-90">
              {level} · {duration} min · {calories} cal
            </p>
          </div>
          <Button
            className="absolute bottom-5 right-5"
            onClick={onStartWorkout}
          >
            Start Workout
          </Button>
        </div>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="flex border-b overflow-x-auto hide-scrollbar">
            {daysOfWeek.map((day) => (
              <button
                key={day}
                className={`px-6 py-3 text-sm font-medium whitespace-nowrap ${
                  activeDay === day
                    ? "text-primary border-b-2 border-primary"
                    : "text-gray-500 hover:text-primary border-b-2 border-transparent"
                }`}
                onClick={() => setActiveDay(day)}
              >
                {day}
              </button>
            ))}
          </div>

          <div className="p-4">
            <div className="space-y-4">
              {exercises.map((exercise, index) => (
                <ExerciseItem
                  key={index}
                  icon={<Dumbbell className="h-6 w-6 text-primary" />}
                  name={exercise.name}
                  details={`${exercise.sets} sets · ${exercise.reps} reps · ${exercise.restTime}s rest`}
                  onWatch={() => handleWatchExercise(exercise)}
                  showBorder={index < exercises.length - 1}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      <Dialog open={showExerciseModal} onOpenChange={setShowExerciseModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedExercise?.name}</DialogTitle>
            <DialogDescription>
              {selectedExercise && (
                <div className="mt-4">
                  <p className="mb-2">
                    <strong>Sets:</strong> {selectedExercise.sets}
                  </p>
                  <p className="mb-2">
                    <strong>Reps:</strong> {selectedExercise.reps}
                  </p>
                  <p className="mb-2">
                    <strong>Rest Time:</strong> {selectedExercise.restTime}s
                  </p>
                  <div className="mt-4 aspect-video bg-gray-100 flex items-center justify-center">
                    <span className="text-gray-400">Exercise demonstration would appear here</span>
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WorkoutPlan;
