import { cn } from "@/lib/utils";

type ProgressCardProps = {
  title: string;
  value: string | number;
  progressText: string;
  progress: number; // 0-100
  icon: React.ReactNode;
  color: "primary" | "secondary" | "accent" | "primary-light";
};

const ProgressCard = ({
  title,
  value,
  progressText,
  progress,
  icon,
  color,
}: ProgressCardProps) => {
  // Calculate the stroke dashoffset for the progress circle
  // 163 is the circumference of the circle with radius 26
  const dashoffset = 163 - (163 * progress) / 100;

  const colorClasses = {
    primary: "text-primary",
    secondary: "text-secondary",
    accent: "text-accent",
    "primary-light": "text-primary-light",
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 flex items-center justify-between">
      <div>
        <p className="text-gray-500 text-sm">{title}</p>
        <p className="text-2xl font-bold">{value}</p>
        <p className={`text-xs ${colorClasses[color]}`}>{progressText}</p>
      </div>
      <div className="relative h-16 w-16">
        <svg className="transform -rotate-90" width="64" height="64">
          <circle
            className="text-gray-200"
            strokeWidth="5"
            stroke="currentColor"
            fill="transparent"
            r="26"
            cx="32"
            cy="32"
          />
          <circle
            className={colorClasses[color]}
            strokeWidth="5"
            stroke="currentColor"
            fill="transparent"
            r="26"
            cx="32"
            cy="32"
            strokeDasharray="163"
            strokeDashoffset={dashoffset}
          />
        </svg>
        <div
          className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 ${colorClasses[color]}`}
        >
          {icon}
        </div>
      </div>
    </div>
  );
};

export default ProgressCard;
