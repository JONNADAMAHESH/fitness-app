import { ChevronRight } from "lucide-react";

type HealthTipCardProps = {
  icon: React.ReactNode;
  title: string;
  content: string;
  onReadMore: () => void;
};

const HealthTipCard = ({
  icon,
  title,
  content,
  onReadMore,
}: HealthTipCardProps) => {
  return (
    <div className="bg-white rounded-xl shadow-sm p-5">
      <div className="flex items-start">
        <div className="bg-amber-100 rounded-lg h-12 w-12 flex items-center justify-center flex-shrink-0 mr-4">
          {icon}
        </div>
        <div>
          <h3 className="font-semibold text-lg mb-2">{title}</h3>
          <p className="text-gray-500 text-sm">{content}</p>
          <button
            className="mt-4 text-primary font-medium text-sm flex items-center"
            onClick={onReadMore}
          >
            Read more
            <ChevronRight className="h-4 w-4 ml-1" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default HealthTipCard;
