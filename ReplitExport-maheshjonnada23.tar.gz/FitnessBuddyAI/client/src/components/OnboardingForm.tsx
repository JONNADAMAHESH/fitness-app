import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Shield, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { fitnessLevels, fitnessGoals, bodyParts } from "@/lib/utils";

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  age: z.string().refine((val) => !isNaN(parseInt(val)) && parseInt(val) >= 18 && parseInt(val) <= 90, {
    message: "Age must be between 18 and 90"
  }),
  height: z.string().refine((val) => !isNaN(parseInt(val)) && parseInt(val) > 100 && parseInt(val) < 250, {
    message: "Height must be in cm (e.g., 175)"
  }),
  weight: z.string().refine((val) => !isNaN(parseInt(val)) && parseInt(val) > 30 && parseInt(val) < 250, {
    message: "Weight must be in kg (e.g., 70)"
  }),
  fitnessLevel: z.string({
    required_error: "Please select your fitness level",
  }),
  fitnessGoals: z.array(z.string()).min(1, { message: "Select at least one fitness goal" }),
  targetBodyParts: z.array(z.string()).min(1, { message: "Select at least one body part to focus on" }),
});

type OnboardingFormProps = {
  onComplete: () => void;
};

const OnboardingForm = ({ onComplete }: OnboardingFormProps) => {
  const [step, setStep] = useState(1);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      age: "",
      height: "",
      weight: "",
      fitnessLevel: "",
      fitnessGoals: [],
      targetBodyParts: [],
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    console.log(values);
    // Here you would normally submit the form to your API
    // For now we'll just complete the onboarding
    onComplete();
  };

  const goToNextStep = () => {
    switch (step) {
      case 1:
        const basicInfoValid = form.trigger(["name", "age", "height", "weight"]);
        if (basicInfoValid) {
          setStep(2);
        }
        break;
      case 2:
        const fitnessInfoValid = form.trigger(["fitnessLevel", "fitnessGoals"]);
        if (fitnessInfoValid) {
          setStep(3);
        }
        break;
      case 3:
        form.handleSubmit(onSubmit)();
        break;
    }
  };

  const goToPreviousStep = () => {
    setStep(Math.max(1, step - 1));
  };

  return (
    <div className="bg-gray-50 min-h-screen flex flex-col">
      <div className="bg-white shadow-sm py-4">
        <div className="container mx-auto flex items-center justify-center">
          <Shield className="h-8 w-8 text-primary mr-2" />
          <h1 className="text-xl font-bold text-primary">FitLife AI</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 flex-grow flex flex-col items-center justify-center">
        <div className="bg-white rounded-xl shadow-sm p-6 w-full max-w-md">
          <h2 className="text-2xl font-bold mb-2 text-center">Welcome to FitLife AI</h2>
          <p className="text-gray-500 text-center mb-6">Let's customize your fitness journey</p>
          
          <div className="flex justify-between mb-8">
            {[1, 2, 3].map(i => (
              <div 
                key={i} 
                className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${
                  i === step 
                    ? "border-primary text-primary" 
                    : i < step 
                      ? "border-primary bg-primary text-white" 
                      : "border-gray-300 text-gray-300"
                }`}
              >
                {i < step ? "✓" : i}
              </div>
            ))}
          </div>

          <Form {...form}>
            <form className="space-y-4">
              {step === 1 && (
                <>
                  <h3 className="font-semibold text-lg">Basic Information</h3>
                  
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl>
                          <Input placeholder="30" type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="height"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Height (cm)</FormLabel>
                          <FormControl>
                            <Input placeholder="175" type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="weight"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Weight (kg)</FormLabel>
                          <FormControl>
                            <Input placeholder="70" type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </>
              )}

              {step === 2 && (
                <>
                  <h3 className="font-semibold text-lg">Fitness Profile</h3>
                  
                  <FormField
                    control={form.control}
                    name="fitnessLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fitness Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your fitness level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {fitnessLevels.map((level) => (
                              <SelectItem key={level.value} value={level.value}>
                                {level.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="fitnessGoals"
                    render={() => (
                      <FormItem>
                        <div className="mb-2">
                          <FormLabel>Fitness Goals</FormLabel>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {fitnessGoals.map((goal) => (
                            <FormField
                              key={goal.value}
                              control={form.control}
                              name="fitnessGoals"
                              render={({ field }) => {
                                return (
                                  <FormItem
                                    key={goal.value}
                                    className="flex flex-row items-start space-x-2 space-y-0"
                                  >
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value?.includes(goal.value)}
                                        onCheckedChange={(checked) => {
                                          return checked
                                            ? field.onChange([...field.value, goal.value])
                                            : field.onChange(
                                                field.value?.filter(
                                                  (value) => value !== goal.value
                                                )
                                              );
                                        }}
                                      />
                                    </FormControl>
                                    <FormLabel className="font-normal">
                                      {goal.label}
                                    </FormLabel>
                                  </FormItem>
                                );
                              }}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}

              {step === 3 && (
                <>
                  <h3 className="font-semibold text-lg">Target Body Parts</h3>
                  <p className="text-gray-500 text-sm mb-4">Select the body parts you want to focus on</p>
                  
                  <FormField
                    control={form.control}
                    name="targetBodyParts"
                    render={() => (
                      <FormItem>
                        <div className="grid grid-cols-2 gap-2">
                          {bodyParts.map((bodyPart) => (
                            <FormField
                              key={bodyPart}
                              control={form.control}
                              name="targetBodyParts"
                              render={({ field }) => {
                                return (
                                  <FormItem
                                    key={bodyPart}
                                    className="flex flex-row items-start space-x-2 space-y-0"
                                  >
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value?.includes(bodyPart)}
                                        onCheckedChange={(checked) => {
                                          return checked
                                            ? field.onChange([...field.value, bodyPart])
                                            : field.onChange(
                                                field.value?.filter(
                                                  (value) => value !== bodyPart
                                                )
                                              );
                                        }}
                                      />
                                    </FormControl>
                                    <FormLabel className="capitalize font-normal">
                                      {bodyPart}
                                    </FormLabel>
                                  </FormItem>
                                );
                              }}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}
            </form>
          </Form>

          <div className="flex justify-between mt-8">
            {step > 1 && (
              <Button variant="outline" onClick={goToPreviousStep}>
                Back
              </Button>
            )}
            <div className={step === 1 ? "w-full" : ""}>
              <Button className="w-full" onClick={goToNextStep}>
                {step < 3 ? (
                  <>
                    Next
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                ) : (
                  "Create My Plan"
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingForm;
