import { ChevronRight } from "lucide-react";
import { Link } from "wouter";

type FeatureCardProps = {
  imageUrl: string;
  title: string;
  description: string;
  linkText: string;
  linkUrl: string;
};

const FeatureCard = ({
  imageUrl,
  title,
  description,
  linkText,
  linkUrl,
}: FeatureCardProps) => {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="h-36 relative">
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2">{title}</h3>
        <p className="text-gray-500 text-sm">{description}</p>
        <Link href={linkUrl}>
          <div className="mt-4 text-primary font-medium text-sm flex items-center cursor-pointer">
            {linkText}
            <ChevronRight className="h-4 w-4 ml-1" />
          </div>
        </Link>
      </div>
    </div>
  );
};

export default FeatureCard;
