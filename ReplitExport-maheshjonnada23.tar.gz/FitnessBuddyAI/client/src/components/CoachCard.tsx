import { Button } from "@/components/ui/button";

type CoachCardProps = {
  name: string;
  specialization: string;
  imageUrl: string;
  nextSession: string;
  onSchedule: () => void;
  onMessage: () => void;
};

const CoachCard = ({
  name,
  specialization,
  imageUrl,
  nextSession,
  onSchedule,
  onMessage,
}: CoachCardProps) => {
  return (
    <div className="bg-white rounded-xl shadow-sm p-5">
      <div className="flex items-center mb-5">
        <div className="relative mr-4">
          <img
            src={imageUrl}
            alt={`${name} profile`}
            className="w-16 h-16 rounded-full object-cover"
          />
          <div className="absolute -bottom-1 -right-1 bg-green-500 w-4 h-4 rounded-full border-2 border-white"></div>
        </div>
        <div>
          <h3 className="font-semibold text-lg">{name}</h3>
          <p className="text-gray-500 text-sm">{specialization}</p>
        </div>
      </div>

      <p className="text-gray-900 mb-5">
        Next online session: <span className="font-medium">{nextSession}</span>
      </p>

      <div className="flex space-x-3">
        <Button className="flex-1" onClick={onSchedule}>
          Schedule Session
        </Button>
        <Button
          variant="outline"
          className="flex-1 border-primary text-primary hover:bg-primary/5"
          onClick={onMessage}
        >
          Message
        </Button>
      </div>
    </div>
  );
};

export default CoachCard;
