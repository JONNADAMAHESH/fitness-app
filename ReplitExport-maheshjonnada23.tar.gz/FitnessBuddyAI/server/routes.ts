import { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import {
  insertUserSchema,
  insertWorkoutSchema,
  insertExerciseSchema,
  insertNutritionPlanSchema,
  insertYogaRoutineSchema,
  insertSleepDataSchema,
  insertStepDataSchema,
  insertHealthTipSchema,
  insertCoachSchema,
  fitnessPlanSchema
} from "@shared/schema";
import { aiRouter } from "./ai/ai-routes";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  // Register AI routes
  app.use("/api/ai", aiRouter);
  // User routes
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const userData = req.body;
      const user = await storage.updateUser(id, userData);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  // Workout routes
  app.get("/api/workouts", async (_req: Request, res: Response) => {
    try {
      const workouts = await storage.getWorkouts();
      res.json(workouts);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/workouts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const workout = await storage.getWorkout(id);
      if (!workout) {
        return res.status(404).json({ message: "Workout not found" });
      }
      res.json(workout);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/workouts/age-group/:ageGroup", async (req: Request, res: Response) => {
    try {
      const { ageGroup } = req.params;
      const workouts = await storage.getWorkoutsByAgeGroup(ageGroup);
      res.json(workouts);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/workouts/body-part/:bodyPart", async (req: Request, res: Response) => {
    try {
      const { bodyPart } = req.params;
      const workouts = await storage.getWorkoutsByBodyPart(bodyPart);
      res.json(workouts);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/workouts/difficulty/:difficulty", async (req: Request, res: Response) => {
    try {
      const { difficulty } = req.params;
      const workouts = await storage.getWorkoutsByDifficulty(difficulty);
      res.json(workouts);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/workouts", async (req: Request, res: Response) => {
    try {
      const workoutData = insertWorkoutSchema.parse(req.body);
      const workout = await storage.createWorkout(workoutData);
      res.status(201).json(workout);
    } catch (error) {
      res.status(400).json({ message: "Invalid workout data", error });
    }
  });

  app.post("/api/workouts/ai-plan", async (req: Request, res: Response) => {
    try {
      const fitnessPlan = fitnessPlanSchema.parse(req.body);
      const workouts = await storage.generateAIWorkoutPlan(fitnessPlan);
      res.json(workouts);
    } catch (error) {
      res.status(400).json({ message: "Invalid fitness plan data", error });
    }
  });

  // Exercise routes
  app.get("/api/exercises", async (_req: Request, res: Response) => {
    try {
      const exercises = await storage.getExercises();
      res.json(exercises);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/exercises/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const exercise = await storage.getExercise(id);
      if (!exercise) {
        return res.status(404).json({ message: "Exercise not found" });
      }
      res.json(exercise);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/exercises/body-part/:bodyPart", async (req: Request, res: Response) => {
    try {
      const { bodyPart } = req.params;
      const exercises = await storage.getExercisesByBodyPart(bodyPart);
      res.json(exercises);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/exercises/age-group/:ageGroup", async (req: Request, res: Response) => {
    try {
      const { ageGroup } = req.params;
      const exercises = await storage.getExercisesByAgeGroup(ageGroup);
      res.json(exercises);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/exercises", async (req: Request, res: Response) => {
    try {
      const exerciseData = insertExerciseSchema.parse(req.body);
      const exercise = await storage.createExercise(exerciseData);
      res.status(201).json(exercise);
    } catch (error) {
      res.status(400).json({ message: "Invalid exercise data", error });
    }
  });

  // Nutrition plan routes
  app.get("/api/nutrition-plans", async (_req: Request, res: Response) => {
    try {
      const nutritionPlans = await storage.getNutritionPlans();
      res.json(nutritionPlans);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/nutrition-plans/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const nutritionPlan = await storage.getNutritionPlan(id);
      if (!nutritionPlan) {
        return res.status(404).json({ message: "Nutrition plan not found" });
      }
      res.json(nutritionPlan);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/nutrition-plans/goal/:goal", async (req: Request, res: Response) => {
    try {
      const { goal } = req.params;
      const nutritionPlans = await storage.getNutritionPlansByGoal(goal);
      res.json(nutritionPlans);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/nutrition-plans/age-group/:ageGroup", async (req: Request, res: Response) => {
    try {
      const { ageGroup } = req.params;
      const nutritionPlans = await storage.getNutritionPlansByAgeGroup(ageGroup);
      res.json(nutritionPlans);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/nutrition-plans", async (req: Request, res: Response) => {
    try {
      const nutritionPlanData = insertNutritionPlanSchema.parse(req.body);
      const nutritionPlan = await storage.createNutritionPlan(nutritionPlanData);
      res.status(201).json(nutritionPlan);
    } catch (error) {
      res.status(400).json({ message: "Invalid nutrition plan data", error });
    }
  });

  // Yoga routine routes
  app.get("/api/yoga-routines", async (_req: Request, res: Response) => {
    try {
      const yogaRoutines = await storage.getYogaRoutines();
      res.json(yogaRoutines);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/yoga-routines/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const yogaRoutine = await storage.getYogaRoutine(id);
      if (!yogaRoutine) {
        return res.status(404).json({ message: "Yoga routine not found" });
      }
      res.json(yogaRoutine);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/yoga-routines/difficulty/:difficulty", async (req: Request, res: Response) => {
    try {
      const { difficulty } = req.params;
      const yogaRoutines = await storage.getYogaRoutinesByDifficulty(difficulty);
      res.json(yogaRoutines);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/yoga-routines", async (req: Request, res: Response) => {
    try {
      const yogaRoutineData = insertYogaRoutineSchema.parse(req.body);
      const yogaRoutine = await storage.createYogaRoutine(yogaRoutineData);
      res.status(201).json(yogaRoutine);
    } catch (error) {
      res.status(400).json({ message: "Invalid yoga routine data", error });
    }
  });

  // Sleep data routes
  app.get("/api/sleep-data/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const sleepData = await storage.getSleepData(userId);
      res.json(sleepData);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/sleep-data/:userId/date/:date", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const date = new Date(req.params.date);
      const sleepData = await storage.getSleepDataByDate(userId, date);
      if (!sleepData) {
        return res.status(404).json({ message: "Sleep data not found" });
      }
      res.json(sleepData);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/sleep-data", async (req: Request, res: Response) => {
    try {
      const sleepDataData = insertSleepDataSchema.parse(req.body);
      const sleepData = await storage.createSleepData(sleepDataData);
      res.status(201).json(sleepData);
    } catch (error) {
      res.status(400).json({ message: "Invalid sleep data", error });
    }
  });

  // Step data routes
  app.get("/api/step-data/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const stepData = await storage.getStepData(userId);
      res.json(stepData);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/step-data/:userId/date/:date", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const date = new Date(req.params.date);
      const stepData = await storage.getStepDataByDate(userId, date);
      if (!stepData) {
        return res.status(404).json({ message: "Step data not found" });
      }
      res.json(stepData);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/step-data", async (req: Request, res: Response) => {
    try {
      const stepDataData = insertStepDataSchema.parse(req.body);
      const stepData = await storage.createStepData(stepDataData);
      res.status(201).json(stepData);
    } catch (error) {
      res.status(400).json({ message: "Invalid step data", error });
    }
  });

  // Health tip routes
  app.get("/api/health-tips", async (_req: Request, res: Response) => {
    try {
      const healthTips = await storage.getHealthTips();
      res.json(healthTips);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/health-tips/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const healthTip = await storage.getHealthTip(id);
      if (!healthTip) {
        return res.status(404).json({ message: "Health tip not found" });
      }
      res.json(healthTip);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/health-tips/category/:category", async (req: Request, res: Response) => {
    try {
      const { category } = req.params;
      const healthTips = await storage.getHealthTipsByCategory(category);
      res.json(healthTips);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/health-tips/age-group/:ageGroup", async (req: Request, res: Response) => {
    try {
      const { ageGroup } = req.params;
      const healthTips = await storage.getHealthTipsByAgeGroup(ageGroup);
      res.json(healthTips);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/health-tips", async (req: Request, res: Response) => {
    try {
      const healthTipData = insertHealthTipSchema.parse(req.body);
      const healthTip = await storage.createHealthTip(healthTipData);
      res.status(201).json(healthTip);
    } catch (error) {
      res.status(400).json({ message: "Invalid health tip data", error });
    }
  });

  // Coach routes
  app.get("/api/coaches", async (_req: Request, res: Response) => {
    try {
      const coaches = await storage.getCoaches();
      res.json(coaches);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/coaches/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const coach = await storage.getCoach(id);
      if (!coach) {
        return res.status(404).json({ message: "Coach not found" });
      }
      res.json(coach);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/coaches/specialization/:specialization", async (req: Request, res: Response) => {
    try {
      const { specialization } = req.params;
      const coaches = await storage.getCoachesBySpecialization(specialization);
      res.json(coaches);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/coaches", async (req: Request, res: Response) => {
    try {
      const coachData = insertCoachSchema.parse(req.body);
      const coach = await storage.createCoach(coachData);
      res.status(201).json(coach);
    } catch (error) {
      res.status(400).json({ message: "Invalid coach data", error });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
