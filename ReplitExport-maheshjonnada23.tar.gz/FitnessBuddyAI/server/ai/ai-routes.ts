import { Router, Request, Response } from "express";
import * as OpenAIService from "./openai-service";
import { fitnessPlanSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export const aiRouter = Router();

// Test OpenAI connection
aiRouter.get("/test", async (_req: Request, res: Response) => {
  try {
    // Check if OPENAI_API_KEY is set
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ 
        status: "error", 
        message: "OpenAI API key is not configured. Please set the OPENAI_API_KEY environment variable."
      });
    }
    
    res.status(200).json({ 
      status: "success", 
      message: "OpenAI API key is configured properly. AI features should work correctly."
    });
  } catch (error) {
    console.error("Error testing OpenAI connection:", error);
    res.status(500).json({ 
      status: "error", 
      message: "There was an error testing the OpenAI connection."
    });
  }
});

// Generate AI workout plan
aiRouter.post("/workout-plan", async (req: Request, res: Response) => {
  try {
    const fitnessPlan = fitnessPlanSchema.parse(req.body);
    const workoutPlan = await OpenAIService.generateWorkoutPlan(fitnessPlan);
    res.status(200).json(workoutPlan);
  } catch (error) {
    console.error("Error generating workout plan:", error);
    if (error instanceof ZodError) {
      const validationError = fromZodError(error);
      return res.status(400).json({ message: validationError.message });
    }
    res.status(500).json({ message: "Failed to generate workout plan" });
  }
});

// Analyze exercise form
aiRouter.post("/analyze-form", async (req: Request, res: Response) => {
  try {
    const { exerciseName, formDescription, userDetails } = req.body;
    
    if (!exerciseName || !formDescription || !userDetails) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    
    const formAnalysis = await OpenAIService.analyzeExerciseForm(
      exerciseName,
      formDescription,
      userDetails
    );
    
    res.status(200).json(formAnalysis);
  } catch (error) {
    console.error("Error analyzing exercise form:", error);
    res.status(500).json({ message: "Failed to analyze exercise form" });
  }
});

// Generate nutrition plan
aiRouter.post("/nutrition-plan", async (req: Request, res: Response) => {
  try {
    const { age, weight, height, gender, fitnessGoals, activityLevel, dietaryRestrictions, includeSupplements } = req.body;
    
    if (!age || !weight || !height || !fitnessGoals || !activityLevel) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    
    const nutritionPlan = await OpenAIService.generateNutritionPlan({
      age,
      weight,
      height,
      gender,
      fitnessGoals,
      activityLevel,
      dietaryRestrictions,
      includeSupplements: !!includeSupplements
    });
    
    res.status(200).json(nutritionPlan);
  } catch (error) {
    console.error("Error generating nutrition plan:", error);
    res.status(500).json({ message: "Failed to generate nutrition plan" });
  }
});

// Generate health insights
aiRouter.post("/health-insights", async (req: Request, res: Response) => {
  try {
    const { age, weight, height, gender, sleepData, activityData, vitalSigns } = req.body;
    
    if (!age || !weight || !height || !sleepData || !activityData) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    
    const healthInsights = await OpenAIService.generateHealthInsights({
      age,
      weight,
      height,
      gender,
      sleepData,
      activityData,
      vitalSigns
    });
    
    res.status(200).json(healthInsights);
  } catch (error) {
    console.error("Error generating health insights:", error);
    res.status(500).json({ message: "Failed to generate health insights" });
  }
});

// Generate coach message
aiRouter.post("/coach-message", async (req: Request, res: Response) => {
  try {
    const { name, recentWorkouts, fitnessGoals, currentStreak, recentProgress, upcomingWorkouts } = req.body;
    
    if (!name || !recentWorkouts || !fitnessGoals || currentStreak === undefined) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    
    const coachMessage = await OpenAIService.generateCoachMessage({
      name,
      recentWorkouts,
      fitnessGoals,
      currentStreak,
      recentProgress,
      upcomingWorkouts
    });
    
    res.status(200).json({ message: coachMessage });
  } catch (error) {
    console.error("Error generating coach message:", error);
    res.status(500).json({ message: "Failed to generate coach message" });
  }
});