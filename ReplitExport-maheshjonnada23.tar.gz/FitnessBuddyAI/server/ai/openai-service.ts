import OpenAI from "openai";
import { FitnessPlan } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

// Check if OpenAI API key is configured
if (!process.env.OPENAI_API_KEY) {
  console.error("OpenAI API key is not set. Please set the OPENAI_API_KEY environment variable.");
}

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface WorkoutExercise {
  name: string;
  sets: number;
  reps: number;
  restTime: number;
  instructions: string;
}

export interface AIWorkoutPlan {
  name: string;
  description: string;
  difficulty: string;
  targetBodyParts: string[];
  exercises: WorkoutExercise[];
  duration: number;
  calories: number;
  ageGroup: string;
}

export interface AIFormAnalysis {
  score: number; // 1-10
  feedback: string;
  improvements: string[];
  risksAndWarnings: string[];
  nextStepsSuggestions: string[];
}

export interface AINutritionPlan {
  name: string;
  description: string;
  goal: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  meals: {
    name: string;
    foods: {
      name: string;
      calories: number;
      protein: number;
      carbs: number;
      fat: number;
    }[];
  }[];
  supplements?: {
    name: string;
    dosage: string;
    timing: string;
    benefits: string[];
  }[];
  ageGroup: string;
}

export interface AIHealth {
  predictions: {
    metric: string;
    current: number;
    projected: number;
    timeframe: string;
    confidence: number;
  }[];
  recommendations: string[];
  risks: string[];
  lifestyle: {
    category: string;
    score: number;
    improvement: string;
  }[];
}

// Generate personalized workout plans based on user fitness plan
export async function generateWorkoutPlan(fitnessPlan: FitnessPlan): Promise<AIWorkoutPlan> {
  const { fitnessLevel, age, bodyParts, goals, height, weight } = fitnessPlan;
  
  const prompt = `Create a personalized workout plan with the following parameters:
- Fitness Level: ${fitnessLevel}
- Age: ${age}
- Target Body Parts: ${bodyParts.join(', ')}
- Fitness Goals: ${goals}
- Height: ${height || 'Not specified'} cm
- Weight: ${weight || 'Not specified'} kg

The workout plan should include:
1. A name for the workout plan
2. A description
3. Difficulty level
4. Target body parts
5. List of exercises with sets, reps, rest time, and brief instructions
6. Estimated duration in minutes
7. Estimated calories burned
8. Age group ("18-35" or "35-90")

Format the response as a JSON object with the following structure:
{
  "name": string,
  "description": string,
  "difficulty": string,
  "targetBodyParts": string[],
  "exercises": [
    {
      "name": string,
      "sets": number,
      "reps": number,
      "restTime": number,
      "instructions": string
    }
  ],
  "duration": number,
  "calories": number,
  "ageGroup": string
}`;

  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { 
          role: "system", 
          content: "You are an expert fitness trainer specializing in creating personalized workout plans. Provide detailed, safe, and effective workout plans based on the user's specifications."
        },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI API");
    }

    const result = JSON.parse(content);
    return result as AIWorkoutPlan;
  } catch (error) {
    console.error("Error generating workout plan:", error);
    throw new Error("Failed to generate workout plan");
  }
}

// Analyze exercise form from a description
export async function analyzeExerciseForm(
  exerciseName: string,
  formDescription: string,
  userDetails: { age: number; fitnessLevel: string; injuries?: string[] }
): Promise<AIFormAnalysis> {
  const prompt = `Analyze the following exercise form description for ${exerciseName}:
  
"${formDescription}"

User details:
- Age: ${userDetails.age}
- Fitness Level: ${userDetails.fitnessLevel}
${userDetails.injuries ? `- Existing injuries or conditions: ${userDetails.injuries.join(', ')}` : ''}

Provide a comprehensive analysis including:
1. A score from 1-10 (where 10 is perfect form)
2. Detailed feedback on the form
3. Specific improvements needed
4. Any risks or warnings based on the form described
5. Suggestions for next steps

Format the response as a JSON object with the following structure:
{
  "score": number,
  "feedback": string,
  "improvements": string[],
  "risksAndWarnings": string[],
  "nextStepsSuggestions": string[]
}`;

  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { 
          role: "system", 
          content: "You are an expert fitness trainer and exercise physiologist specializing in form analysis and correction. You provide detailed analysis of exercise form with a focus on safety and effectiveness."
        },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI API");
    }
    
    const result = JSON.parse(content);
    return result as AIFormAnalysis;
  } catch (error) {
    console.error("Error analyzing exercise form:", error);
    throw new Error("Failed to analyze exercise form");
  }
}

// Generate personalized nutrition plan
export async function generateNutritionPlan(
  userDetails: {
    age: number;
    weight: number;
    height: number;
    gender?: string;
    fitnessGoals: string;
    activityLevel: string;
    dietaryRestrictions?: string[];
    includeSupplements: boolean;
  }
): Promise<AINutritionPlan> {
  const { 
    age, weight, height, gender, fitnessGoals, 
    activityLevel, dietaryRestrictions, includeSupplements 
  } = userDetails;
  
  const prompt = `Create a personalized nutrition plan with the following parameters:
- Age: ${age}
- Weight: ${weight} kg
- Height: ${height} cm
- Gender: ${gender || 'Not specified'}
- Fitness Goals: ${fitnessGoals}
- Activity Level: ${activityLevel}
- Dietary Restrictions: ${dietaryRestrictions?.join(', ') || 'None'}
- Include Supplements: ${includeSupplements ? 'Yes' : 'No'}

The nutrition plan should include:
1. A name for the nutrition plan
2. A description
3. Goal (weight_loss, muscle_gain, endurance, flexibility, overall_fitness)
4. Daily calorie target
5. Macronutrient breakdown (protein, carbs, fat)
6. Meal plan with foods and their nutritional content
7. ${includeSupplements ? 'Recommended supplements with dosage, timing, and benefits' : ''}
8. Age group ("all", "18-35", or "35-90")

Format the response as a JSON object.`;

  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { 
          role: "system", 
          content: "You are an expert nutritionist specializing in creating personalized nutrition plans for fitness goals. Provide detailed, balanced, and effective nutrition plans based on the user's specifications."
        },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI API");
    }
    
    const result = JSON.parse(content);
    return result as AINutritionPlan;
  } catch (error) {
    console.error("Error generating nutrition plan:", error);
    throw new Error("Failed to generate nutrition plan");
  }
}

// Generate health insights and predictions based on user data
export async function generateHealthInsights(
  userData: {
    age: number;
    weight: number;
    height: number;
    gender?: string;
    sleepData: { date: string; duration: number; quality: number }[];
    activityData: { date: string; steps: number; activeMinutes: number }[];
    vitalSigns?: { heartRate?: number; bloodPressure?: string; restingHeartRate?: number };
  }
): Promise<AIHealth> {
  const prompt = `Analyze the following health data and provide insights:
  
User details:
- Age: ${userData.age}
- Weight: ${userData.weight} kg
- Height: ${userData.height} cm
- Gender: ${userData.gender || 'Not specified'}

Sleep data for the past ${userData.sleepData.length} days:
${userData.sleepData.map(entry => `- Date: ${entry.date}, Duration: ${entry.duration} hours, Quality: ${entry.quality}/10`).join('\n')}

Activity data for the past ${userData.activityData.length} days:
${userData.activityData.map(entry => `- Date: ${entry.date}, Steps: ${entry.steps}, Active Minutes: ${entry.activeMinutes}`).join('\n')}

${userData.vitalSigns ? `Vital signs:
- Heart Rate: ${userData.vitalSigns.heartRate || 'Not provided'}
- Blood Pressure: ${userData.vitalSigns.bloodPressure || 'Not provided'}
- Resting Heart Rate: ${userData.vitalSigns.restingHeartRate || 'Not provided'}` : ''}

Provide comprehensive health insights including:
1. Predictions for key health metrics
2. Personalized recommendations
3. Potential health risks
4. Lifestyle assessment by category (sleep, activity, nutrition)

Format the response as a JSON object.`;

  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { 
          role: "system", 
          content: "You are an AI health analysis system that provides personalized health insights based on user data. You analyze patterns, identify potential issues, and provide actionable recommendations. Remember to maintain a balanced perspective and avoid alarmist language."
        },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI API");
    }
    
    const result = JSON.parse(content);
    return result as AIHealth;
  } catch (error) {
    console.error("Error generating health insights:", error);
    throw new Error("Failed to generate health insights");
  }
}

// Generate AI fitness coach messages
export async function generateCoachMessage(
  context: {
    name: string;
    recentWorkouts: { date: string; name: string; completed: boolean }[];
    fitnessGoals: string;
    currentStreak: number;
    recentProgress?: { metric: string; change: number; timeframe: string }[];
    upcomingWorkouts?: { date: string; name: string }[];
  }
): Promise<string> {
  const prompt = `Generate a motivational and personalized fitness coach message for ${context.name} with the following context:

Recent workouts:
${context.recentWorkouts.map(w => `- ${w.date}: ${w.name} (${w.completed ? 'Completed' : 'Missed'})`).join('\n')}

Fitness goals: ${context.fitnessGoals}
Current streak: ${context.currentStreak} days

${context.recentProgress ? `Recent progress:
${context.recentProgress.map(p => `- ${p.metric}: ${p.change > 0 ? '+' : ''}${p.change} over ${p.timeframe}`).join('\n')}` : ''}

${context.upcomingWorkouts ? `Upcoming workouts:
${context.upcomingWorkouts.map(w => `- ${w.date}: ${w.name}`).join('\n')}` : ''}

The message should be motivational, personalized, and include specific references to the user's progress, goals, and workout history. Keep it concise (about 100-150 words) but impactful.`;

  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { 
          role: "system", 
          content: "You are an expert fitness coach known for your motivational style and personalized approach. You've helped thousands of people achieve their fitness goals through positive reinforcement and actionable advice."
        },
        { role: "user", content: prompt }
      ]
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI API");
    }
    
    return content.trim();
  } catch (error) {
    console.error("Error generating coach message:", error);
    throw new Error("Failed to generate coach message");
  }
}