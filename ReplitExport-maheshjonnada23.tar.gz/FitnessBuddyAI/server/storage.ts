import {
  users, workouts, exercises, nutritionPlans, yogaRoutines, sleepData, stepData, healthTips, coaches,
  type User, type Workout, type Exercise, type NutritionPlan, type YogaRoutine,
  type SleepData, type StepData, type HealthTip, type Coach,
  type InsertUser, type InsertWorkout, type InsertExercise, type InsertNutritionPlan,
  type InsertYogaRoutine, type InsertSleepData, type InsertStepData, type InsertHealthTip, 
  type InsertCoach, type FitnessPlan
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Workout operations
  getWorkouts(): Promise<Workout[]>;
  getWorkout(id: number): Promise<Workout | undefined>;
  getWorkoutsByAgeGroup(ageGroup: string): Promise<Workout[]>;
  getWorkoutsByBodyPart(bodyPart: string): Promise<Workout[]>;
  getWorkoutsByDifficulty(difficulty: string): Promise<Workout[]>;
  createWorkout(workout: InsertWorkout): Promise<Workout>;
  generateAIWorkoutPlan(fitnessPlan: FitnessPlan): Promise<Workout[]>;

  // Exercise operations
  getExercises(): Promise<Exercise[]>;
  getExercise(id: number): Promise<Exercise | undefined>;
  getExercisesByBodyPart(bodyPart: string): Promise<Exercise[]>;
  getExercisesByAgeGroup(ageGroup: string): Promise<Exercise[]>;
  createExercise(exercise: InsertExercise): Promise<Exercise>;

  // Nutrition operations
  getNutritionPlans(): Promise<NutritionPlan[]>;
  getNutritionPlan(id: number): Promise<NutritionPlan | undefined>;
  getNutritionPlansByGoal(goal: string): Promise<NutritionPlan[]>;
  getNutritionPlansByAgeGroup(ageGroup: string): Promise<NutritionPlan[]>;
  createNutritionPlan(nutritionPlan: InsertNutritionPlan): Promise<NutritionPlan>;

  // Yoga operations
  getYogaRoutines(): Promise<YogaRoutine[]>;
  getYogaRoutine(id: number): Promise<YogaRoutine | undefined>;
  getYogaRoutinesByDifficulty(difficulty: string): Promise<YogaRoutine[]>;
  createYogaRoutine(yogaRoutine: InsertYogaRoutine): Promise<YogaRoutine>;

  // Sleep operations
  getSleepData(userId: number): Promise<SleepData[]>;
  getSleepDataByDate(userId: number, date: Date): Promise<SleepData | undefined>;
  createSleepData(sleepData: InsertSleepData): Promise<SleepData>;

  // Step operations
  getStepData(userId: number): Promise<StepData[]>;
  getStepDataByDate(userId: number, date: Date): Promise<StepData | undefined>;
  createStepData(stepData: InsertStepData): Promise<StepData>;

  // Health tip operations
  getHealthTips(): Promise<HealthTip[]>;
  getHealthTip(id: number): Promise<HealthTip | undefined>;
  getHealthTipsByCategory(category: string): Promise<HealthTip[]>;
  getHealthTipsByAgeGroup(ageGroup: string): Promise<HealthTip[]>;
  createHealthTip(healthTip: InsertHealthTip): Promise<HealthTip>;

  // Coach operations
  getCoaches(): Promise<Coach[]>;
  getCoach(id: number): Promise<Coach | undefined>;
  getCoachesBySpecialization(specialization: string): Promise<Coach[]>;
  createCoach(coach: InsertCoach): Promise<Coach>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private workouts: Map<number, Workout>;
  private exercises: Map<number, Exercise>;
  private nutritionPlans: Map<number, NutritionPlan>;
  private yogaRoutines: Map<number, YogaRoutine>;
  private sleepData: Map<number, SleepData>;
  private stepData: Map<number, StepData>;
  private healthTips: Map<number, HealthTip>;
  private coaches: Map<number, Coach>;
  
  private currentUserId: number;
  private currentWorkoutId: number;
  private currentExerciseId: number;
  private currentNutritionPlanId: number;
  private currentYogaRoutineId: number;
  private currentSleepDataId: number;
  private currentStepDataId: number;
  private currentHealthTipId: number;
  private currentCoachId: number;

  constructor() {
    this.users = new Map();
    this.workouts = new Map();
    this.exercises = new Map();
    this.nutritionPlans = new Map();
    this.yogaRoutines = new Map();
    this.sleepData = new Map();
    this.stepData = new Map();
    this.healthTips = new Map();
    this.coaches = new Map();
    
    this.currentUserId = 1;
    this.currentWorkoutId = 1;
    this.currentExerciseId = 1;
    this.currentNutritionPlanId = 1;
    this.currentYogaRoutineId = 1;
    this.currentSleepDataId = 1;
    this.currentStepDataId = 1;
    this.currentHealthTipId = 1;
    this.currentCoachId = 1;
    
    this.initDemoData();
  }

  private initDemoData() {
    // Add demo workouts
    this.createWorkout({
      name: "Upper Body Focus",
      description: "A comprehensive workout targeting chest, shoulders, back, and arms",
      difficulty: "intermediate",
      duration: 45,
      calories: 350,
      targetBodyParts: ["chest", "shoulders", "back", "biceps", "triceps"],
      exercises: [
        { name: "Chest Press", sets: 3, reps: 12, restTime: 60 },
        { name: "Barbell Rows", sets: 3, reps: 10, restTime: 60 },
        { name: "Shoulder Press", sets: 3, reps: 12, restTime: 60 },
        { name: "Bicep Curls", sets: 3, reps: 15, restTime: 45 }
      ],
      ageGroup: "18-35"
    });
    
    // Add demo exercises
    this.createExercise({
      name: "Chest Press",
      description: "Lie on a flat bench with a barbell or dumbbells, and press the weight up",
      bodyPart: "chest",
      difficulty: "intermediate",
      sets: 3,
      reps: 12,
      restTime: 60,
      instructionsSteps: [
        "Lie on a flat bench with feet flat on the floor",
        "Grip the barbell with hands slightly wider than shoulder-width",
        "Lower the weight to your chest with control",
        "Press the weight straight up and lock out your elbows at the top"
      ],
      ageGroup: "18-35",
      imageUrl: "",
      videoUrl: ""
    });
    
    // Add demo yoga routines
    this.createYogaRoutine({
      name: "Morning Refresh",
      description: "Energizing yoga routine to start your day",
      difficulty: "beginner",
      duration: 20,
      poses: [
        { name: "Mountain Pose", duration: 30 },
        { name: "Forward Fold", duration: 30 },
        { name: "Downward Dog", duration: 45 },
        { name: "Warrior I", duration: 60 },
        { name: "Warrior II", duration: 60 }
      ],
      benefits: ["Improves flexibility", "Reduces stress", "Increases energy"]
    });
    
    // Add demo health tips
    this.createHealthTip({
      title: "Vitamin D: The Sunshine Nutrient",
      content: "Learn why Vitamin D is crucial for bone health, immune function, and overall wellbeing - especially for adults over 35.",
      category: "nutrition",
      ageGroup: "35-90"
    });
    
    this.createHealthTip({
      title: "The Importance of Sleep for Recovery",
      content: "Discover why quality sleep is essential for muscle recovery, hormone regulation, and maintaining a healthy weight.",
      category: "sleep",
      ageGroup: "all"
    });
    
    // Add demo coaches
    this.createCoach({
      name: "Coach Sarah",
      specialization: "Personal Training, Nutrition",
      experience: 7,
      bio: "Certified Personal Trainer with 7 years of experience specializing in strength training and nutrition guidance.",
      availability: {
        monday: ["9:00", "10:00", "11:00", "16:00", "17:00"],
        tuesday: ["9:00", "10:00", "11:00", "16:00", "17:00"],
        wednesday: ["9:00", "10:00", "11:00", "16:00", "17:00"],
        thursday: ["9:00", "10:00", "11:00", "16:00", "17:00"],
        friday: ["9:00", "10:00", "11:00", "16:00", "17:00"]
      },
      imageUrl: ""
    });
    
    // Add demo nutrition plans
    this.createNutritionPlan({
      name: "Weight Loss Plan",
      description: "A balanced diet plan designed for sustainable weight loss",
      goal: "weight_loss",
      calories: 1800,
      protein: 130,
      carbs: 180,
      fat: 60,
      meals: [
        {
          name: "Breakfast",
          foods: [
            { name: "Oatmeal with berries", calories: 300, protein: 10, carbs: 45, fat: 5 },
            { name: "Greek yogurt", calories: 100, protein: 15, carbs: 5, fat: 0 }
          ]
        },
        {
          name: "Lunch",
          foods: [
            { name: "Grilled chicken salad", calories: 400, protein: 35, carbs: 25, fat: 15 }
          ]
        },
        {
          name: "Dinner",
          foods: [
            { name: "Baked salmon", calories: 350, protein: 30, carbs: 0, fat: 22 },
            { name: "Steamed vegetables", calories: 100, protein: 5, carbs: 20, fat: 0 },
            { name: "Brown rice", calories: 150, protein: 5, carbs: 30, fat: 1 }
          ]
        },
        {
          name: "Snacks",
          foods: [
            { name: "Apple with almond butter", calories: 200, protein: 5, carbs: 25, fat: 10 },
            { name: "Protein shake", calories: 200, protein: 25, carbs: 10, fat: 3 }
          ]
        }
      ],
      ageGroup: "all"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userUpdate: Partial<User>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;

    const updatedUser = { ...existingUser, ...userUpdate };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Workout operations
  async getWorkouts(): Promise<Workout[]> {
    return Array.from(this.workouts.values());
  }

  async getWorkout(id: number): Promise<Workout | undefined> {
    return this.workouts.get(id);
  }

  async getWorkoutsByAgeGroup(ageGroup: string): Promise<Workout[]> {
    return Array.from(this.workouts.values()).filter(
      workout => workout.ageGroup === ageGroup || workout.ageGroup === "all"
    );
  }

  async getWorkoutsByBodyPart(bodyPart: string): Promise<Workout[]> {
    return Array.from(this.workouts.values()).filter(
      workout => workout.targetBodyParts.includes(bodyPart)
    );
  }

  async getWorkoutsByDifficulty(difficulty: string): Promise<Workout[]> {
    return Array.from(this.workouts.values()).filter(
      workout => workout.difficulty === difficulty
    );
  }

  async createWorkout(insertWorkout: InsertWorkout): Promise<Workout> {
    const id = this.currentWorkoutId++;
    const createdAt = new Date();
    const workout: Workout = { ...insertWorkout, id, createdAt };
    this.workouts.set(id, workout);
    return workout;
  }

  async generateAIWorkoutPlan(fitnessPlan: FitnessPlan): Promise<Workout[]> {
    // This would normally call an AI service
    // For now, we'll mock a simple algorithm that returns workouts matching the user's criteria
    const { fitnessLevel, age, bodyParts, goals } = fitnessPlan;
    const ageGroup = age < 35 ? "18-35" : "35-90";
    
    // Filter workouts by age group and fitness level
    const matchingWorkouts = Array.from(this.workouts.values()).filter(workout => 
      (workout.ageGroup === ageGroup || workout.ageGroup === "all") && 
      workout.difficulty === fitnessLevel
    );
    
    // Further filter by body parts if there are matches
    let filteredWorkouts = matchingWorkouts.length > 0 ? matchingWorkouts : Array.from(this.workouts.values());
    if (bodyParts.length > 0) {
      filteredWorkouts = filteredWorkouts.filter(workout => 
        bodyParts.some(part => workout.targetBodyParts.includes(part))
      );
    }
    
    // If no workouts match the criteria, return a generic one
    if (filteredWorkouts.length === 0) {
      return [Array.from(this.workouts.values())[0]];
    }
    
    return filteredWorkouts;
  }

  // Exercise operations
  async getExercises(): Promise<Exercise[]> {
    return Array.from(this.exercises.values());
  }

  async getExercise(id: number): Promise<Exercise | undefined> {
    return this.exercises.get(id);
  }

  async getExercisesByBodyPart(bodyPart: string): Promise<Exercise[]> {
    return Array.from(this.exercises.values()).filter(
      exercise => exercise.bodyPart === bodyPart
    );
  }

  async getExercisesByAgeGroup(ageGroup: string): Promise<Exercise[]> {
    return Array.from(this.exercises.values()).filter(
      exercise => exercise.ageGroup === ageGroup || exercise.ageGroup === "all"
    );
  }

  async createExercise(insertExercise: InsertExercise): Promise<Exercise> {
    const id = this.currentExerciseId++;
    const exercise: Exercise = { ...insertExercise, id };
    this.exercises.set(id, exercise);
    return exercise;
  }

  // Nutrition operations
  async getNutritionPlans(): Promise<NutritionPlan[]> {
    return Array.from(this.nutritionPlans.values());
  }

  async getNutritionPlan(id: number): Promise<NutritionPlan | undefined> {
    return this.nutritionPlans.get(id);
  }

  async getNutritionPlansByGoal(goal: string): Promise<NutritionPlan[]> {
    return Array.from(this.nutritionPlans.values()).filter(
      plan => plan.goal === goal
    );
  }

  async getNutritionPlansByAgeGroup(ageGroup: string): Promise<NutritionPlan[]> {
    return Array.from(this.nutritionPlans.values()).filter(
      plan => plan.ageGroup === ageGroup || plan.ageGroup === "all"
    );
  }

  async createNutritionPlan(insertNutritionPlan: InsertNutritionPlan): Promise<NutritionPlan> {
    const id = this.currentNutritionPlanId++;
    const nutritionPlan: NutritionPlan = { ...insertNutritionPlan, id };
    this.nutritionPlans.set(id, nutritionPlan);
    return nutritionPlan;
  }

  // Yoga operations
  async getYogaRoutines(): Promise<YogaRoutine[]> {
    return Array.from(this.yogaRoutines.values());
  }

  async getYogaRoutine(id: number): Promise<YogaRoutine | undefined> {
    return this.yogaRoutines.get(id);
  }

  async getYogaRoutinesByDifficulty(difficulty: string): Promise<YogaRoutine[]> {
    return Array.from(this.yogaRoutines.values()).filter(
      routine => routine.difficulty === difficulty
    );
  }

  async createYogaRoutine(insertYogaRoutine: InsertYogaRoutine): Promise<YogaRoutine> {
    const id = this.currentYogaRoutineId++;
    const yogaRoutine: YogaRoutine = { ...insertYogaRoutine, id };
    this.yogaRoutines.set(id, yogaRoutine);
    return yogaRoutine;
  }

  // Sleep operations
  async getSleepData(userId: number): Promise<SleepData[]> {
    return Array.from(this.sleepData.values()).filter(
      data => data.userId === userId
    );
  }

  async getSleepDataByDate(userId: number, date: Date): Promise<SleepData | undefined> {
    return Array.from(this.sleepData.values()).find(
      data => data.userId === userId && data.date.toDateString() === date.toDateString()
    );
  }

  async createSleepData(insertSleepData: InsertSleepData): Promise<SleepData> {
    const id = this.currentSleepDataId++;
    const sleepData: SleepData = { ...insertSleepData, id };
    this.sleepData.set(id, sleepData);
    return sleepData;
  }

  // Step operations
  async getStepData(userId: number): Promise<StepData[]> {
    return Array.from(this.stepData.values()).filter(
      data => data.userId === userId
    );
  }

  async getStepDataByDate(userId: number, date: Date): Promise<StepData | undefined> {
    return Array.from(this.stepData.values()).find(
      data => data.userId === userId && data.date.toDateString() === date.toDateString()
    );
  }

  async createStepData(insertStepData: InsertStepData): Promise<StepData> {
    const id = this.currentStepDataId++;
    const stepData: StepData = { ...insertStepData, id };
    this.stepData.set(id, stepData);
    return stepData;
  }

  // Health tip operations
  async getHealthTips(): Promise<HealthTip[]> {
    return Array.from(this.healthTips.values());
  }

  async getHealthTip(id: number): Promise<HealthTip | undefined> {
    return this.healthTips.get(id);
  }

  async getHealthTipsByCategory(category: string): Promise<HealthTip[]> {
    return Array.from(this.healthTips.values()).filter(
      tip => tip.category === category
    );
  }

  async getHealthTipsByAgeGroup(ageGroup: string): Promise<HealthTip[]> {
    return Array.from(this.healthTips.values()).filter(
      tip => tip.ageGroup === ageGroup || tip.ageGroup === "all"
    );
  }

  async createHealthTip(insertHealthTip: InsertHealthTip): Promise<HealthTip> {
    const id = this.currentHealthTipId++;
    const healthTip: HealthTip = { ...insertHealthTip, id };
    this.healthTips.set(id, healthTip);
    return healthTip;
  }

  // Coach operations
  async getCoaches(): Promise<Coach[]> {
    return Array.from(this.coaches.values());
  }

  async getCoach(id: number): Promise<Coach | undefined> {
    return this.coaches.get(id);
  }

  async getCoachesBySpecialization(specialization: string): Promise<Coach[]> {
    return Array.from(this.coaches.values()).filter(
      coach => coach.specialization.includes(specialization)
    );
  }

  async createCoach(insertCoach: InsertCoach): Promise<Coach> {
    const id = this.currentCoachId++;
    const coach: Coach = { ...insertCoach, id };
    this.coaches.set(id, coach);
    return coach;
  }
}

export const storage = new MemStorage();
